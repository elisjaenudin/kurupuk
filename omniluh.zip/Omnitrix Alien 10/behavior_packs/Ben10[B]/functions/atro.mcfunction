event entity @s minecraft:atro
clear @s ben:menu
give @s ben:off