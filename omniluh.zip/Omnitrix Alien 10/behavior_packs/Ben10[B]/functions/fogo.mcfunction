event entity @s minecraft:fogo
clear @s ben:menu
give @s ben:off