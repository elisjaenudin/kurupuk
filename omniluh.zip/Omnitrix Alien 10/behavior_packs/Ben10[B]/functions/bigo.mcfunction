event entity @s minecraft:bigo
clear @s ben:menu
give @s ben:off