event entity @s minecraft:echo
clear @s ben:menu
give @s ben:off