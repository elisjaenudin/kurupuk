effect @s[family=gt] slowness 3 2 true
effect @s[family=gt] jump_boost 3 3 true
effect @s[family=gt] resistance 3 2 true

effect @s[family=hm] slowness 3 2 true
effect @s[family=hm] jump_boost 3 5 true
effect @s[family=hm] resistance 3 2 truehm

effect @s[family=eyes] jump_boost 3 5 true
effect @s[family=eyes] resistance 3 2 true

effect @s[family=ditto] jump_boost 3 5 true
effect @s[family=ditto] resistance 3 2 true
effect @s[family=ditto] speed 3 1 true

effect @s[family=echo] jump_boost 3 5 true
effect @s[family=echo] resistance 3 2 true

effect @s[family=kh] jump_boost 3 5 true
effect @s[family=kh] resistance 3 2 true
effect @s[family=kh] speed 3 2 true

effect @s[family=fogo] jump_boost 3 5 true
effect @s[family=fogo] resistance 3 2 true
effect @s[family=fogo] fire_resistance 3 5 true

effect @s[family=pick] jump_boost 3 5 true
effect @s[family=pick] resistance 3 2 true
effect @s[family=pick] slowness 3 2 true

execute @s[family=b] ~~~ title @s actionbar §agosmosauro

execute @s[family=b2] ~~~ title @s actionbar §aquatrosauro