event entity @s minecraft:4hm
clear @s ben:menu
give @s ben:off1