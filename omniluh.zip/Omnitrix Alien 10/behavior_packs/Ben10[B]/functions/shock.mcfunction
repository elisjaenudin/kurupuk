event entity @s minecraft:shock
give @s ben10:p_shock
clear @s ben:menu
give @s ben:off