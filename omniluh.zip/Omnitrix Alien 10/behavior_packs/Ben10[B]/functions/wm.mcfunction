event entity @s minecraft:wm
clear @s ben:menu
give @s ben:off