event entity @s minecraft:gt
clear @s ben:menu
give @s ben:off