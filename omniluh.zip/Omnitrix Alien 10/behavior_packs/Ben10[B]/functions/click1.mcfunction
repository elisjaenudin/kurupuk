

event entity @s[family=bio] minecraft:b
event entity @s[family=b] minecraft:b2
event entity @s[family=b2] minecraft:bio