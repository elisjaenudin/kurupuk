event entity @s minecraft:x
clear @s ben:menu
give @s ben:off