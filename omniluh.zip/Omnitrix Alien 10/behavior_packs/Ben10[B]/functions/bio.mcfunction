event entity @s minecraft:bio
give @s ben:menu1
clear @s ben:bio