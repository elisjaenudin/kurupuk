clear @s ben:off1
event entity @s minecraft:bio
give @s ben:menu1
effect @s clear