event entity @s minecraft:hm
clear @s ben:menu
give @s ben:off