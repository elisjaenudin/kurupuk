event entity @s minecraft:xlr8
clear @s ben:menu
give @s ben:off