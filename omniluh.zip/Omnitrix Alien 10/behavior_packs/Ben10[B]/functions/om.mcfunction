event entity @s minecraft:omnitrix
give @s ben:menu
clear @s ben:omnitrix