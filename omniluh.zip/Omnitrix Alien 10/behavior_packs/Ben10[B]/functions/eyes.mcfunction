event entity @s minecraft:eyes
clear @s ben:menu
give @s ben:off