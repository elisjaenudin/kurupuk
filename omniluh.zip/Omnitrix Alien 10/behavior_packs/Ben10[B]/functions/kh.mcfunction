event entity @s minecraft:kh
clear @s ben:menu
give @s ben:off