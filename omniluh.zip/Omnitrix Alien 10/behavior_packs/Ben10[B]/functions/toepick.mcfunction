event entity @s minecraft:pick
clear @s ben:menu
give @s ben:off