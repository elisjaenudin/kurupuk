event entity @s minecraft:ditto
clear @s ben:menu
give @s ben:off