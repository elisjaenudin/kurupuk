event entity @s minecraft:cro
clear @s ben:menu
give @s ben:off