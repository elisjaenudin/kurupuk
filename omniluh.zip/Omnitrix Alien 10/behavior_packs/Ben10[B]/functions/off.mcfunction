clear @s ben:off
event entity @s minecraft:omnitrix
give @s ben:menu
effect @s clear