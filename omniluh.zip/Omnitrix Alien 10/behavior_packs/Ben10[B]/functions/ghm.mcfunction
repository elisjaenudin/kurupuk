event entity @s minecraft:ghm
clear @s ben:menu
give @s ben:off1