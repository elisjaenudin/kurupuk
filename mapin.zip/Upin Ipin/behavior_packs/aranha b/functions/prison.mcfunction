setblock ~1~~ web
setblock ~-1~~ web
setblock ~~~1 web
setblock ~~~-1 web
setblock ~1~1~ web
setblock ~-1~1~ web
setblock ~~1~1 web
setblock ~~1~-1 web
