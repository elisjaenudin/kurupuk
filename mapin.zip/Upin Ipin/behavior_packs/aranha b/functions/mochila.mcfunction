replaceitem entity @s slot.armor.head 1 rafael:mochila
