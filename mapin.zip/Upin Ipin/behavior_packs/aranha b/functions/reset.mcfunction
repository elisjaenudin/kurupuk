kill @e[type=rafael:spiron]
