clear @s rafael:aranha1
clear @s rafael:aranha2
clear @s rafael:aranha3
cear @s rafael:mochila
effect @s clear
clear @s chainmail_boots