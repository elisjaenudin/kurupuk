effect @s strength 9999999 6 true
effect @s speed 9999999 6 true
effect @s jump_boost 9999999 5 true
effect @s regeneration 9999999 15 true
effect @s resistance 9999999 7 true
effect @s invisibility 9999999 99 true
effect @s jump_boost 9999999 5 true
effect @s slow_falling 9999999 1
effect @s fatal_poison 1 1 true
replaceitem entity @s slot.armor.head 1 rafael:aranha1
