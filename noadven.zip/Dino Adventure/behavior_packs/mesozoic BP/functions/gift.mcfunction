execute @a[tag=wolf_king_gift] ~~~ give @s jat:sword_of_power
execute @a[tag=wolf_king_gift] ~~~ give @s jat:nucleus_blood 2
execute @a[tag=wolf_king_gift] ~~~ tag @s remove wolf_king_gift