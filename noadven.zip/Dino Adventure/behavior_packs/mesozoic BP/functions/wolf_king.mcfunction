execute @e[tag=wolf_king, tag=!loaded] ~ ~ ~ structure load mystructure:wolf_king_palace 20000 100 20000
execute @e[tag=wolf_king] ~ ~ ~ effect @s slow_falling 100 255 true
execute @e[tag=wolf_king] ~ ~ ~ tp @s 20029 300 20007
execute @e[tag=wolf_king] ~ ~ ~ tag @s add loaded
execute @e[tag=wolf_king] ~ ~ ~ tag @s remove wolf_king