tag @s add target

scoreboard players set @s[tag=target] h 0
execute @p[r=6] ~ ~ ~ execute @s[rym=-157.5,ry=-112.5] ~ ~ ~ scoreboard players set @e[tag=target] h 1
execute @p[r=6] ~ ~ ~ execute @s[rym=-112.5,ry=-67.5] ~ ~ ~ scoreboard players set @e[tag=target] h 2
execute @p[r=6] ~ ~ ~ execute @s[rym=-67.5,ry=-22.5] ~ ~ ~ scoreboard players set @e[tag=target] h 3
execute @p[r=6] ~ ~ ~ execute @s[rym=-22.5,ry=22.5] ~ ~ ~ scoreboard players set @e[tag=target] h 4
execute @p[r=6] ~ ~ ~ execute @s[rym=22.5,ry=67.5] ~ ~ ~ scoreboard players set @e[tag=target] h 5
execute @p[r=6] ~ ~ ~ execute @s[rym=67.5,ry=112.5] ~ ~ ~ scoreboard players set @e[tag=target] h 6
execute @p[r=6] ~ ~ ~ execute @s[rym=112.5,ry=157.5] ~ ~ ~ scoreboard players set @e[tag=target] h 7

tp @s[family=!face_away_on_spawn,tag=target,scores={h=0}] ~ ~.101 ~ 0 ~
tp @s[family=!face_away_on_spawn,tag=target,scores={h=1}] ~ ~.101 ~ 45 ~
tp @s[family=!face_away_on_spawn,tag=target,scores={h=2}] ~ ~.101 ~ 90 ~
tp @s[family=!face_away_on_spawn,tag=target,scores={h=3}] ~ ~.101 ~ 135 ~
tp @s[family=!face_away_on_spawn,tag=target,scores={h=4}] ~ ~.101 ~ 180 ~
tp @s[family=!face_away_on_spawn,tag=target,scores={h=5}] ~ ~.101 ~ -135 ~
tp @s[family=!face_away_on_spawn,tag=target,scores={h=6}] ~ ~.101 ~ -90 ~
tp @s[family=!face_away_on_spawn,tag=target,scores={h=7}] ~ ~.101 ~ -45 ~

tp @s[family=face_away_on_spawn,tag=target,scores={h=0}] ~ ~.101 ~ -180 ~
tp @s[family=face_away_on_spawn,tag=target,scores={h=1}] ~ ~.101 ~ -135 ~
tp @s[family=face_away_on_spawn,tag=target,scores={h=2}] ~ ~.101 ~ -90 ~
tp @s[family=face_away_on_spawn,tag=target,scores={h=3}] ~ ~.101 ~ -45 ~
tp @s[family=face_away_on_spawn,tag=target,scores={h=4}] ~ ~.101 ~ 0 ~
tp @s[family=face_away_on_spawn,tag=target,scores={h=5}] ~ ~.101 ~ 45 ~
tp @s[family=face_away_on_spawn,tag=target,scores={h=6}] ~ ~.101 ~ 90 ~
tp @s[family=face_away_on_spawn,tag=target,scores={h=7}] ~ ~.101 ~ 135 ~

scoreboard players set @s[tag=target] i 0
scoreboard players add @s[tag=target] j 0

#reset#
tag @s[r=5,tag=target] remove target

playsound spark.fm2.place @a[r=16] ~ ~ ~ 1 1 1
