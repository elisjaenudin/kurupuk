#orientation#
# scoreboard objectives add oriented dummy // replaced by tag
scoreboard objectives add h dummy

#rotate#
scoreboard objectives add i dummy