#include "ShaderConstants.fxh"
#include "util.fxh"
#include "yeshader-config.hlsl"

struct PS_Input
{
	float4 position : SV_Position;

#ifndef BYPASS_PIXEL_SHADER
	lpfloat4 color : COLOR;
	snorm float2 uv0 : TEXCOORD_0_FB_MSAA;
	snorm float2 uv1 : TEXCOORD_1_FB_MSAA;
#endif

#ifdef FOG
	float4 fogColor : FOG_COLOR;
#endif

	float waterFlag : waterFlag;
};

struct PS_Output
{
	float4 color : SV_Target;
};

ROOT_SIGNATURE
void main(in PS_Input PSInput, out PS_Output PSOutput)
{

#if defined(YE_SHADOWS)
	const bool genShadows = true;
#else
	const bool genShadows = false;
#endif // defined(YE_SHADOWS)

#if defined(YE_COLORED_LIGHTS)
	const bool genLightColours = true;
#else
	const bool genLightColours = false;
#endif // defined(YE_COLORED_LIGHTS)

float indoor = smoothstep(0.865, 0.875, PSInput.uv1.y);
float sunLevel = genShadows ? lerp(0.75 /* Shadow depth */, 1.0, indoor) : 1.0;
float dayLight = smoothstep(0.4, 1.0, TEXTURE_1.Sample(TextureSampler1, float2(0, 1)).r);
float lightLevel = genLightColours ? lerp(pow(PSInput.uv1.x, 2.0), 0.0, dayLight * PSInput.uv1.y) : 0.0;

#ifdef BYPASS_PIXEL_SHADER
    PSOutput.color = float4(0.0f, 0.0f, 0.0f, 0.0f);
    return;
#else

#if USE_TEXEL_AA
	float4 diffuse = texture2D_AA(TEXTURE_0, TextureSampler0, PSInput.uv0 );
#else
	float4 diffuse = TEXTURE_0.Sample(TextureSampler0, PSInput.uv0);
#endif

#ifdef SEASONS_FAR
	diffuse.a = 1.0f;
#endif

#if USE_ALPHA_TEST
	#ifdef ALPHA_TO_COVERAGE
		#define ALPHA_THRESHOLD 0.05
	#else
		#define ALPHA_THRESHOLD 0.5
	#endif
	if(diffuse.a < ALPHA_THRESHOLD)
		discard;
#endif

float4 inColor = PSInput.color;

#if defined(BLEND)
	diffuse.a *= inColor.a;
#endif

#if !defined(ALWAYS_LIT)
	diffuse *= TEXTURE_1.Sample(TextureSampler1, float2(PSInput.uv1.x, PSInput.uv1.y * sunLevel));
#endif

#ifndef SEASONS
	#if !USE_ALPHA_TEST && !defined(BLEND)
		diffuse.a = inColor.a;
	#endif	

	diffuse.rgb *= inColor.rgb;
#else
	float2 uv = inColor.xy;
	diffuse.rgb *= lerp(1.0f, TEXTURE_2.Sample(TextureSampler2, uv).rgb*2.0f, inColor.b);
	diffuse.rgb *= inColor.aaa;
	diffuse.a = 1.0f;
#endif

	if(PSInput.waterFlag > 0.5) {
		diffuse *= 0.75; // Darken water colour
	}

	diffuse.rgb *= lerp(1.0, float3(2.0, 1.0, 0.0), lightLevel);

#ifdef FOG
	diffuse.rgb = lerp( diffuse.rgb, PSInput.fogColor.rgb, PSInput.fogColor.a );
#endif

	PSOutput.color = diffuse;

#ifdef VR_MODE
	// On Rift, the transition from 0 brightness to the lowest 8 bit value is abrupt, so clamp to 
	// the lowest 8 bit value.
	PSOutput.color = max(PSOutput.color, 1 / 255.0f);
#endif

#endif // BYPASS_PIXEL_SHADER
}