#if !defined(YE_CONFIG_INCLUDED)
#define YE_CONFIG_INCLUDED

// Generate shadows
#define YE_SHADOWS 0.75

// Generate coloured lights
#define YE_COLORED_LIGHTS

// Enable waves of plants and the water
#define YE_WAVES

#endif //!defined(YE_CONFIG_INCLUDED)