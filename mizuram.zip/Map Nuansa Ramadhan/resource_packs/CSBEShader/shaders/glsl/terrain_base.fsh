// __multiversion__
// This signals the loading code to prepend either #version 100 or #version 300 es as apropriate.

#include "fragmentVersionCentroid.h"

#if __VERSION__ >= 300
	#ifndef BYPASS_PIXEL_SHADER
		#if defined(TEXEL_AA) && defined(TEXEL_AA_FEATURE)
			_centroid in highp vec2 uv0;
			_centroid in highp vec2 uv1;
		#else
			_centroid in vec2 uv0;
			_centroid in vec2 uv1;
		#endif
	#endif
#else
	#ifndef BYPASS_PIXEL_SHADER
		varying vec2 uv0;
		varying vec2 uv1;
	#endif
#endif

varying vec4 color;
varying float waterFlag;

#ifdef FOG
varying vec4 fogColor;
#endif

#include "uniformShaderConstants.h"
#include "util.h"
#include "yeshader-config.glsl"

LAYOUT_BINDING(0) uniform sampler2D TEXTURE_0;
LAYOUT_BINDING(1) uniform sampler2D TEXTURE_1;
LAYOUT_BINDING(2) uniform sampler2D TEXTURE_2;

void main()
{

#if defined(YE_SHADOWS)
	const bool genShadows = true;
#else
	const bool genShadows = false;
#endif // defined(YE_SHADOWS)

#if defined(YE_COLORED_LIGHTS)
	const bool genLightColours = true;
#else
	const bool genLightColours = false;
#endif // defined(YE_COLORED_LIGHTS)

float indoor = smoothstep(0.865, 0.875, uv1.y);
float sunLevel = genShadows ? mix(0.75 /* Shadow depth */, 1.0, indoor) : 1.0;
float dayLight = smoothstep(0.4, 1.0, texture2D(TEXTURE_1, vec2(0, 1)).r);
float lightLevel = genLightColours ? mix(pow(uv1.x, 2.0), 0.0, dayLight * uv1.y) : 0.0;

#ifdef BYPASS_PIXEL_SHADER
	gl_FragColor = vec4(0, 0, 0, 0);
	return;
#else 

#if USE_TEXEL_AA
	vec4 diffuse = texture2D_AA(TEXTURE_0, uv0);
#else
	vec4 diffuse = texture2D(TEXTURE_0, uv0);
#endif
	
#ifdef SEASONS_FAR
	diffuse.a = 1.0;
#endif

#if USE_ALPHA_TEST
	#ifdef ALPHA_TO_COVERAGE
	#define ALPHA_THRESHOLD 0.05
	#else
	#define ALPHA_THRESHOLD 0.5
	#endif
	if(diffuse.a < ALPHA_THRESHOLD)
		discard;
#endif
	
vec4 inColor = color;

#if defined(BLEND)
	diffuse.a *= inColor.a;
#endif

#if !defined(ALWAYS_LIT)
	diffuse *= texture2D( TEXTURE_1, vec2(uv1.x, uv1.y * sunLevel) );
#endif

#ifndef SEASONS
	#if !USE_ALPHA_TEST && !defined(BLEND)
		diffuse.a = inColor.a;
	#endif
	
	diffuse.rgb *= inColor.rgb;
#else
	vec2 uv = inColor.xy;
	diffuse.rgb *= mix(vec3(1.0,1.0,1.0), texture2D( TEXTURE_2, uv).rgb*2.0, inColor.b);
	diffuse.rgb *= inColor.aaa;
	diffuse.a = 1.0;
#endif

	if(waterFlag > 0.5) {
		diffuse *= 0.75; // Darken water colour
	}

	diffuse.rgb *= mix(vec3(1.0), vec3(2.0, 1.0, 0.0), lightLevel);

#ifdef FOG
	diffuse.rgb = mix( diffuse.rgb, fogColor.rgb, fogColor.a );
#endif

	gl_FragColor = diffuse;
	
#endif // BYPASS_PIXEL_SHADER
}
