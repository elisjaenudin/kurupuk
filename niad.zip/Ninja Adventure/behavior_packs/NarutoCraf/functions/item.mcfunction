replaceitem entity @s[tag=!ccc] slot.hotbar 6 mello:missao_d 1 0 {"minecraft:keep_on_death":{},"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s[tag=!ccc] slot.hotbar 3 mello:uchiha 1 0 {"minecraft:keep_on_death":{},"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[tag=!ccc] slot.hotbar 4 mello:hyuuga 1 0 {"minecraft:keep_on_death":{},"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[tag=!ccc] slot.hotbar 5 mello:uzumaki 1 0 {"minecraft:keep_on_death":{},"item_lock":{"mode":"lock_in_slot"}}

replaceitem entity @s[tag=!ccc] slot.hotbar 0 mello:arma_b 1 0 {"minecraft:keep_on_death":{},"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[tag=!ccc] slot.hotbar 1 mello:poder_b 1 0 {"minecraft:keep_on_death":{},"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s[tag=!ccc] slot.hotbar 2 mello:modo_b 1 0 {"minecraft:keep_on_death":{},"item_lock":{"mode":"lock_in_slot"}}

tag @s [tag=!ccc] add ccc

