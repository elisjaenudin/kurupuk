execute as @a[tag=!ddd] run function dash
scoreboard players remove @a[scores={dash=1..}] dash 1