import * as mc from '@minecraft/server';

mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (player.hasTag("dash_rasengan")) { dash_rasengan(player); }
  }
});

function dash_rasengan(player) {
  let
    velo = player.getVelocity(),
    rot = player.getRotation();
  let rot_math = Math.floor((Math.atan2(velo.z, velo.x) * 180 / Math.PI - 90));
  if (rot_math < -180) { rot_math = rot_math + 360; }
  let rot_calc = Math.abs(rot_math - Math.floor((rot.y)));
  rot_calc = Math.min(rot_calc, (360 - rot_calc));
  let
  dash_rasengan = (rot_calc > 120) ? "animation." : "animation.";
  const
    z = (rot.z + 90) * Math.PI / 180,
    x = (rot.x + 90) * Math.PI / 180,
    y = (rot.y + 90) * Math.PI / 180;
  player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 2, 0.2);
  player.playAnimation(dash_rasengan, { controller: "dash_rasengan_controller" });
  player.removeTag("dash_rasengan");
}