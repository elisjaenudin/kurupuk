import { world } from "@minecraft/server";

world.afterEvents.playerSpawn.subscribe(data => {
  try {
    const player = data.player;
    player.runCommandAsync("tag @s remove meteoro_tenseigan");
    player.runCommandAsync("tag @s remove kamui");
    player.runCommandAsync("tag @s remove jogan_raio");
    player.runCommandAsync("tag @s remove jogan_portal");
  }catch (a){}
});