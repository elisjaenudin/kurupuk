import * as mc from '@minecraft/server';

mc.world.afterEvents.entityHurt.subscribe(data => {
    const
        hurt = data.hurtEntity,
        damaging = data.damageSource.damagingEntity,
        damage = data.damage,
        cause = data.damageSource.cause,
        hand = damaging.getComponent('equippable')?.getEquipment('Head');
    if (!(hurt && damaging)) return;
    if (damaging.typeId == "minecraft:player" && hand && hand.typeId == "mello:jogan" && damaging.isOnGround) {
        hurt.getComponent("minecraft:health")?.setCurrentValue(hurt.getComponent("minecraft:health")?.currentValue - Math.floor(damage / 2));
        hurt.runCommandAsync("particle minecraft:critical_hit_emitter ~~2~");
    }
});