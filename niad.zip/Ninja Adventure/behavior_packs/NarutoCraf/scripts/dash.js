import * as mc from '@minecraft/server';

mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (player.hasTag("dash")) { dash(player); }
  }
});
mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (player.hasTag("dash_2")) { dash_2(player); }
  }
});

function dash(player) {
  let
    velo = player.getVelocity(),
    rot = player.getRotation();
  let rot_math = Math.floor((Math.atan2(velo.z, velo.x) * 180 / Math.PI - 90));
  if (rot_math < -180) { rot_math = rot_math + 360; }
  let rot_calc = Math.abs(rot_math - Math.floor((rot.y)));
  rot_calc = Math.min(rot_calc, (360 - rot_calc));
  let
  dash = (rot_calc > 120) ? "animation.dash.back" : "animation.dash.front";
  const
    z = (rot.z + 90) * Math.PI / 180,
    x = (rot.x + 90) * Math.PI / 180,
    y = (rot.y + 90) * Math.PI / 180;
  player.applyKnockback(velo.x, velo.z, 3, 0.3);
  player.playAnimation(dash, { controller: "dash_controller" });
  player.removeTag("dash");
}

function dash_2(player) {
  let
    velo = player.getVelocity(),
    rot = player.getRotation();
  let rot_math = Math.floor((Math.atan2(velo.z, velo.x) * 180 / Math.PI - 90));
  if (rot_math < -180) { rot_math = rot_math + 360; }
  let rot_calc = Math.abs(rot_math - Math.floor((rot.y)));
  rot_calc = Math.min(rot_calc, (360 - rot_calc));
  let
  dash_2 = (rot_calc > 120) ? "animation." : "animation.";
  const
    z = (rot.z + 90) * Math.PI / 180,
    x = (rot.x + 90) * Math.PI / 180,
    y = (rot.y + 90) * Math.PI / 180;
  player.applyKnockback(velo.x, velo.z, 3, 0.3);
  player.playAnimation(dash_2, { controller: "dash_2_controller" });
  player.removeTag("dash_2");
}