//import
import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

//itemUse
world.beforeEvents.itemUse.subscribe((data) => {
  const player = data.source;
  switch (data.itemStack.typeId) {
    case "mello:menu":
    case "mello:menu_2":
      system.runTimeout(() => { menu(player); }, 1);
      break;
  }
});

//creation
export function menu(player) {
  const form = new ActionFormData();

  // Textos dos botões
  let sharingan = true ? "§7bloqueado \n§bComplete os requisitos para acessar.\n§frequisitos:\n§a■ 50 xp" : "Clique para usar o Sharingan";
  if (player.hasTag("add1")) sharingan = "Clique para usar o Sharingan";
  else if (player.hasTag("add2")) sharingan = "Clique para usar o Rinnegan";
  else if (player.hasTag("add3")) sharingan = "Clique para usar o Tenseigan";

  const byakugan = !player.hasTag("add2") ? "§7bloqueado \n§bComplete os requisitos para acessar.\n§frequisitos:\n§a■ 50 xp" : "Clique para usar o Byakugan";




  form.title("ui.menu.title");
  form.button(`${sharingan}`);
  form.button(`${byakugan}`);




  form.show(player).then((response) => {
    switch (response.selection) {
      case 0:
        // Botão Sharingan
        if (player.hasTag("add1")) {
          player.runCommand('/summon pig');
        } else if (player.hasTag("add2")) {
          player.runCommand('/summon cat');
        } else if (player.hasTag("add3")) {
          player.runCommand('/summon cow');
        } else {
          player.sendMessage("§cVocê não tem nenhuma tag necessária para usar o Sharingan.");
        }
        break;




      case 1:
        // Botão Byakugan
        if (player.hasTag("add2")) {
          player.runCommand('/summon cat');
        } else {
          player.sendMessage("§cVocê ainda não desbloqueou o Byakugan.");
        }
        break;
    }
  });
}
