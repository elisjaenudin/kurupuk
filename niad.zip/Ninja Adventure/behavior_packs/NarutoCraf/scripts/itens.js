import * as mc from "@minecraft/server";

// Ações por item
const itemActions = {
  "mello:kunai_minato": (player) => {
    spawnProjectile("mello:kunai_minato_projetil", player);
    spawnProjectile("mello:kunai_minato_projetil", player, 2);
  },

  "mello:meteoro_tenseigan": (player) => {
    runCommand("tag @s add meteoro_tenseigan", player);
    runCommand("summon mello:meteoro_tenseigan ~20~~20", player);               // Longe
    runCommand("summon mello:meteoro_tenseigan ~4~~3", player, 0.3);            // Próximo
    runCommand("summon mello:meteoro_tenseigan ~-20~~10", player, 0.6);         // Longe
    runCommand("summon mello:meteoro_tenseigan ~-3~~2", player, 0.9);           // Próximo
    runCommand("summon mello:meteoro_tenseigan ~15~~15", player, 1.2);          // Longe
    runCommand("summon mello:meteoro_tenseigan ~2~~-4", player, 1.5);           // Próximo
    runCommand("summon mello:meteoro_tenseigan ~-18~~-12", player, 1.8);        // Longe
    runCommand("summon mello:meteoro_tenseigan ~-4~~-3", player, 2.1);          // Próximo
    runCommand("summon mello:meteoro_tenseigan ~10~~-20", player, 2.4);         // Longe
    runCommand("summon mello:meteoro_tenseigan ~3~~-1", player, 2.7);           // Próximo
    runCommand("summon mello:meteoro_tenseigan ~-14~~22", player, 3.0);         // Longe
    runCommand("summon mello:meteoro_tenseigan ~25~~0", player, 3.3);           // Longe (mantido)
    runCommand("summon mello:meteoro_tenseigan ~0~~25", player, 3.6);           // Longe
    runCommand("summon mello:meteoro_tenseigan ~-25~~5", player, 3.9);          // Longe
    runCommand("summon mello:meteoro_tenseigan ~5~~-25", player, 4.2);
    runCommand("tag @s remove meteoro_tenseigan", player, 7);
  },

  "mello:jogan_raio": (player) => {
    runCommand("tag @s add jogan_raio", player);
    runCommand("playanimation @s animation.jogan_raio", player, 0.1);
    runCommand("execute positioned ^^^2 run tag @e[r=1,tag=!jogan_raio] add prisao_raio", player, 0.1);
    runCommand("execute positioned ^^^3 run tag @e[r=1,tag=!jogan_raio] add prisao_raio", player, 0.1);
    runCommand("execute positioned ^^^4 run tag @e[r=2,tag=!jogan_raio] add prisao_raio", player, 0.1);
    runCommand("execute positioned ^^^5 run tag @e[r=2,tag=!jogan_raio] add prisao_raio", player, 0.1);

    runCommand("execute positioned ^^^2 run playanimation @e[r=1,tag=!jogan_raio] animation.prisao_raio", player, 0.1);
    runCommand("execute positioned ^^^3 run playanimation @e[r=1,tag=!jogan_raio] animation.prisao_raio", player, 0.1);
    runCommand("execute positioned ^^^4 run playanimation @e[r=2,tag=!jogan_raio] animation.prisao_raio", player, 0.1);
    runCommand("execute positioned ^^^5 run playanimation @e[r=2,tag=!jogan_raio] animation.prisao_raio", player, 0.1);

    runCommand("execute positioned ^^^2 run damage @e[r=1,tag=!jogan_raio] 10 entity_attack entity @s", player, 0.1);
    runCommand("execute positioned ^^^3 run damage @e[r=1,tag=!jogan_raio] 10 entity_attack entity @s", player, 0.1);
    runCommand("execute positioned ^^^4 run damage @e[r=2,tag=!jogan_raio] 10 entity_attack entity @s", player, 0.1);
    runCommand("execute positioned ^^^5 run damage @e[r=2,tag=!jogan_raio] 10 entity_attack entity @s", player, 0.1);

    runCommand("execute positioned ^^^2 run inputpermission set @a[r=1,tag=!jogan_raio] movement disabled", player, 0.1);
    runCommand("execute positioned ^^^3 run inputpermission set @a[r=1,tag=!jogan_raio] movement disabled", player, 0.1);
    runCommand("execute positioned ^^^4 run inputpermission set @a[r=2,tag=!jogan_raio] movement disabled", player, 0.1);
    runCommand("execute positioned ^^^5 run inputpermission set @a[r=2,tag=!jogan_raio] movement disabled", player, 0.1);
    runCommand("tag @s remove jogan_raio", player, 0.2);
    runCommand("playanimation @s animation.cancelar", player, 0.5);
  },
  "mello:celulas_hyuuga": (player) => {
    runCommand("replaceitem entity @s[tag=uzumaki,lm=100,l=24791] slot.weapon.mainhand 0 mello:jogan_item 1 0 {\"item_lock\":{\"mode\":\"lock_in_inventory\"},\"keep_on_death\":{}}", player);
  },
};

// Evento principal
mc.world.afterEvents.itemStopUse.subscribe(event => {
  const player = event.source;
  const item = event.itemStack;
  if (!player || !item) return;

  const action = itemActions[item.typeId];
  if (action) action(player);
});

// Função para lançar projétil
function spawnProjectile(entityId, player, delay = 0) {
  mc.system.runTimeout(() => {
    const dir = player.getViewDirection();
    const origin = player.getHeadLocation();

    const pos = {
      x: origin.x + dir.x,
      y: origin.y + dir.y,
      z: origin.z + dir.z
    };

    const projectile = player.dimension.spawnEntity(entityId, pos);
    const comp = projectile?.getComponent("projectile");

    if (comp) {
      comp.owner = player;
      comp.shoot({
        x: dir.x * 1.5,
        y: dir.y * 1.5,
        z: dir.z * 1.5
      });
    }
  }, delay * 20);
}

// Função para rodar comando com delay opcional
function runCommand(command, player, delay = 0) {
  mc.system.runTimeout(() => {
    player.runCommandAsync(command);
  }, delay * 20);
}
