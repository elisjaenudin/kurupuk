import * as mc from '@minecraft/server';

mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (player.hasTag("dash_leao_gemeos")) { dash_leao_gemeos(player); }
  }
});

function dash_leao_gemeos(player) {
  let
    velo = player.getVelocity(),
    rot = player.getRotation();
  let rot_math = Math.floor((Math.atan2(velo.z, velo.x) * 180 / Math.PI - 90));
  if (rot_math < -180) { rot_math = rot_math + 360; }
  let rot_calc = Math.abs(rot_math - Math.floor((rot.y)));
  rot_calc = Math.min(rot_calc, (360 - rot_calc));
  let
  dash_leao_gemeos = (rot_calc > 120) ? "animation.leao_gemeos" : "animation.leao_gemeos";
  const
    z = (rot.z + 90) * Math.PI / 180,
    x = (rot.x + 90) * Math.PI / 180,
    y = (rot.y + 90) * Math.PI / 180;
  player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 5, 0.2);
  player.playAnimation(dash_leao_gemeos, { controller: "dash_leao_gemeos_controller" });
  player.removeTag("dash_leao_gemeos");
}