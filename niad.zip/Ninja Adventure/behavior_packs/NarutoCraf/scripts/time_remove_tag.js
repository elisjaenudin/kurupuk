import { system, world } from "@minecraft/server";

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    if (player.hasTag("prisao_raio")) {
      player.removeTag("prisao_raio");
      system.runTimeout(() => {
        try {
          player.runCommandAsync("inputpermission set @s movement enabled");
        } catch (e) {
          console.warn(`Erro ao executar comando: ${e}`);
        }
      }, 40);
    };
    if (player.hasTag("add")) {
      player.removeTag("add");
      system.runTimeout(() => {
        try {
          player.runCommandAsync("say Soldado é vayyyy!");
        } catch (e) {
          console.warn(`Erro ao executar comando: ${e}`);
        }
      }, 40);
    }
  }
});