replaceitem entity @s slot.armor.head 1 rombesm:slendrina_morph
replaceitem entity @s slot.weapon.mainhand 0 air