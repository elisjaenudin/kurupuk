effect @e[hasitem={item=rombesm:slenderman_morph,location=slot.armor.head}] invisibility 1 0 true
effect @e[hasitem={item=rombesm:slenderman_morph,location=slot.armor.head}] regeneration 1 8 true