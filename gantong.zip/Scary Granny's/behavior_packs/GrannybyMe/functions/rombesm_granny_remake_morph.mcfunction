replaceitem entity @s slot.armor.head 1 rombesm:granny_remake_morph
replaceitem entity @s slot.weapon.mainhand 0 air