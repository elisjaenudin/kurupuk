replaceitem entity @s slot.armor.head 1 air
replaceitem entity @s slot.armor.legs 1 air
give @s driver:gamer_driver
give @s gashat:bangbang_shooting_gashat
clear @s weapons:gashacon_magnum
clear @s weapons:gashacon_magnum2
clear @s gun:gun
clear @s off:off_snipe
clear @s lvl:snipe