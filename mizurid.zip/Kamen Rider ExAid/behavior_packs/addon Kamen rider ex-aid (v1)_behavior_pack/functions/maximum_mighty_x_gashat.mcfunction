summon animasi:exaid_lvl99
tp @e[type=animasi:exaid_lvl99] @s
give @s hensin:exaid_lvl99 1 0 {"item_lock":{"mode":"lock_in_inventory"}}