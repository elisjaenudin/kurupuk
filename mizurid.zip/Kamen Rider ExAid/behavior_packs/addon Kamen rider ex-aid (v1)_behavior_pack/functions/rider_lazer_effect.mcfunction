effect @e[hasitem={item=rider:lazer,location=slot.armor.head}] invisibility 1 0 true
