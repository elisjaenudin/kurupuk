replaceitem entity @s slot.armor.head 1 rider:brave_taddle_fantasy
replaceitem entity @s slot.weapon.mainhand 0 air