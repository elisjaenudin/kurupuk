summon animasi:juju_burger
tp @e[type=animasi:juju_burger] @s
give @s hensin:exaid_lvl4 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:exaid_lvl4