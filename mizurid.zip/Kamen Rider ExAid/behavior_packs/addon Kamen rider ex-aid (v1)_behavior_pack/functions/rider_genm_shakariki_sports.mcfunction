replaceitem entity @s slot.armor.head 1 rider:genm_shakariki_sports
replaceitem entity @s slot.weapon.mainhand 0 air