replaceitem entity @s slot.armor.head 1 rider:snipe_jet_combat
replaceitem entity @s slot.weapon.mainhand 0 air