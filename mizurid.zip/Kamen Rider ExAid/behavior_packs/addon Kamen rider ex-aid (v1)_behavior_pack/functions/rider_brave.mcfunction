replaceitem entity @s slot.armor.head 1 rider:brave
replaceitem entity @s slot.weapon.mainhand 0 air