effect @e[hasitem={item=rider:snipe_lvl2,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:snipe_lvl2,location=slot.armor.head}] strength 1 0 true
