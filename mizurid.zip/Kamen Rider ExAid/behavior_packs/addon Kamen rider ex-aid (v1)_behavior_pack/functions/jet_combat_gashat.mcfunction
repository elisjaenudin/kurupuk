summon animasi:snipe_lvl3
tp @e[type=animasi:snipe_lvl3] @s
give @s lvl:snipe_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:snipe