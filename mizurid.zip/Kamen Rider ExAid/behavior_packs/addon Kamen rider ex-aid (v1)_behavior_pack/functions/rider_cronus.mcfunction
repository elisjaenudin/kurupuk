replaceitem entity @s slot.armor.head 1 rider:cronus
replaceitem entity @s slot.weapon.mainhand 0 air