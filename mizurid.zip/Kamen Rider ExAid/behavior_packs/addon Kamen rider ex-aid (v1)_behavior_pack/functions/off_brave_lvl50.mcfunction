replaceitem entity @s slot.armor.head 1 air
give @s driver:gamer_driver
give @s gashat:taddle_fantasy_gashat
clear @s weapons:gashacon_sword_fire
clear @s weapons:gashacon_sword_ice
clear @s off:off_brave_lvl50