effect @e[hasitem={item=rider:exaid_gekitotsu_robots,location=slot.armor.head}] fire_resistance 1 0 true
effect @e[hasitem={item=rider:exaid_gekitotsu_robots,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:exaid_gekitotsu_robots,location=slot.armor.head}] strength 1 0 true
