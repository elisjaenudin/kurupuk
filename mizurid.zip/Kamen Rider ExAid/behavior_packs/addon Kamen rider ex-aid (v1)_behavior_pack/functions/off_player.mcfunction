replaceitem entity @s slot.armor.head 1 air
give @s gashat:chronicle_gashat_player
clear @s off:off_player