summon animasi:laze_lvl3
tp @e[type=animasi:laze_lvl3] @s
give @s lvl:lazer_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:lazer