replaceitem entity @s slot.armor.head 1 rider:exaid_dragonic_knight_hunter_z
replaceitem entity @s slot.weapon.mainhand 0 air