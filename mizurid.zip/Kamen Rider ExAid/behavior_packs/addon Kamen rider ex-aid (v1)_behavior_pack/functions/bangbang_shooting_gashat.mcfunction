summon animasi:snipe
tp @e[type=animasi:snipe] @s
give @s hensin:snipe 1 0 {"item_lock":{"mode":"lock_in_inventory"}}