summon ridermods:exaid_lvl10
tp @e[type=ridermods:exaid_lvl10] @s
replaceitem entity @s slot.armor.head 1 rider:exaid_lvl10 1 0 {"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s slot.armor.legs 1 air
give @s weapons:gashacon_key_slasher
clear @s hensin:exaid_lvl10
effect @s clear