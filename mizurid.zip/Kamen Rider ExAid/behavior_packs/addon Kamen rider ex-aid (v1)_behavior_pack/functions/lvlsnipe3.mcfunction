summon animasi:jet_combat
tp @e[type=animasi:jet_combat] @s
give @s hensin:snipe_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:snipe_lvl3