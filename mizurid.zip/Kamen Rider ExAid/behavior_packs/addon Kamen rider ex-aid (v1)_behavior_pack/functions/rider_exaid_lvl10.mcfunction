replaceitem entity @s slot.armor.head 1 rider:exaid_lvl10
replaceitem entity @s slot.weapon.mainhand 0 air