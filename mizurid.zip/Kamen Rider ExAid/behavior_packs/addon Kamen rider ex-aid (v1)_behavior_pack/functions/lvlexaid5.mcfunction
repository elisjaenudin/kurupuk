summon animasi:dragonic_knight_hunter_z
tp @e[type=animasi:dragonic_knight_hunter_z] @s
give @s hensin:exaid_lvl5 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:exaid_lvl5