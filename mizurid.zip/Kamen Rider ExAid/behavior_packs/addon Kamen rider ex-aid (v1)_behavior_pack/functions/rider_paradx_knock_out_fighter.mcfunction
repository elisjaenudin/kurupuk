replaceitem entity @s slot.armor.head 1 rider:paradx_knock_out_fighter
replaceitem entity @s slot.weapon.mainhand 0 air