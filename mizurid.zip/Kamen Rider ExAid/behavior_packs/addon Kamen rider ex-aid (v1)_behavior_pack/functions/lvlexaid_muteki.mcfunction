summon animasi:exaid_lvlmuteki1
summon animasi:exaid_lvlmuteki
summon animasi:muteki
tp @e[type=animasi:exaid_lvlmuteki1] @s
tp @e[type=animasi:exaid_lvlmuteki] @s
tp @e[type=animasi:muteki] @s
replaceitem entity @s slot.armor.legs 1 air
replaceitem entity @s slot.armor.head 1 player:player 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s lvl:exaid_muteki 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:exaid_muteki