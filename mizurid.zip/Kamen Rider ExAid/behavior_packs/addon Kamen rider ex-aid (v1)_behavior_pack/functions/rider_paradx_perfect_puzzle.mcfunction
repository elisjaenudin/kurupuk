replaceitem entity @s slot.armor.head 1 rider:paradx_perfect_puzzle
replaceitem entity @s slot.weapon.mainhand 0 air