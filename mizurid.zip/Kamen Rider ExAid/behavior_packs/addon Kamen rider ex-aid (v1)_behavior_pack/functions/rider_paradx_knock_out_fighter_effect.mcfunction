effect @e[hasitem={item=rider:paradx_knock_out_fighter,location=slot.armor.head}] fire_resistance 1 0 true
effect @e[hasitem={item=rider:paradx_knock_out_fighter,location=slot.armor.head}] regeneration 1 1 true
effect @e[hasitem={item=rider:paradx_knock_out_fighter,location=slot.armor.head}] resistance 1 4 true
effect @e[hasitem={item=rider:paradx_knock_out_fighter,location=slot.armor.head}] strength 1 0 true
