replaceitem entity @s slot.armor.legs 1 driver:buggle_driver_zwei1
replaceitem entity @s slot.weapon.mainhand 0 air