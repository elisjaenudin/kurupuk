effect @e[hasitem={item=rider:paradx_perfect_puzzle,location=slot.armor.head}] jump_boost 1 9 true
effect @e[hasitem={item=rider:paradx_perfect_puzzle,location=slot.armor.head}] regeneration 1 4 true
effect @e[hasitem={item=rider:paradx_perfect_puzzle,location=slot.armor.head}] resistance 1 4 true
effect @e[hasitem={item=rider:paradx_perfect_puzzle,location=slot.armor.head}] strength 1 0 true
