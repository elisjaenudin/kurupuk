effect @e[hasitem={item=rider:genm_zombie,location=slot.armor.head}] bad_omen 1 0 true
effect @e[hasitem={item=rider:genm_zombie,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:genm_zombie,location=slot.armor.head}] resistance 1 2 true
effect @e[hasitem={item=rider:genm_zombie,location=slot.armor.head}] strength 1 0 true
