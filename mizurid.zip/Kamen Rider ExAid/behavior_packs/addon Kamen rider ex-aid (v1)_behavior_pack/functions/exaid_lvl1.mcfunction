kill @e[type=animasi:exaid]
replaceitem entity @s slot.armor.head 1 rider:exaid 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s lvl:exaid 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s weapons:gashacon_breaker
give @s off:off_exaid 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:exaid