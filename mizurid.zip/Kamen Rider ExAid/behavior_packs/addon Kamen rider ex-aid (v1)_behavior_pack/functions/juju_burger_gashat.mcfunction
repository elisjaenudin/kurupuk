summon animasi:exaid_lvl4
tp @e[type=animasi:exaid_lvl4] @s
give @s lvl:exaid_lvl4 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:exaid