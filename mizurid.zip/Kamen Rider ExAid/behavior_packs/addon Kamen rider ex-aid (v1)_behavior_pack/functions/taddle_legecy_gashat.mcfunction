summon animasi:brave_lvl100
tp @e[type=animasi:brave_lvl100] @s
give @s lvl:brave_lvl100 1 0 {"item_lock":{"mode":"lock_in_inventory"}}