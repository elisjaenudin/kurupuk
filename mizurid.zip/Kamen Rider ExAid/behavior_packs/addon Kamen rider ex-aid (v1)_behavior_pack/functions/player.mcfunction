replaceitem entity @s slot.armor.head 1 rider:player 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_player 1 0 {"item_lock":{"mode":"lock_in_inventory"}}