give @s driver:gamer_driver
give @s gashat:mighty_action_x_gashat
clear @s koper:koper