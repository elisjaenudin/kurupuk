replaceitem entity @s slot.armor.head 1 rider:exaid_gekitotsu_robots
replaceitem entity @s slot.weapon.mainhand 0 air