kill @e[type=animasi:lazer]
replaceitem entity @s slot.armor.head 1 rider:lazer 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s lvl:lazer 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s off:off_lazer 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:lazer