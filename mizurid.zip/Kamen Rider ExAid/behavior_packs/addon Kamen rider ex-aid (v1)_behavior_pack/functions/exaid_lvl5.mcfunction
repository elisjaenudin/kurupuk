kill @e[type=animasi:dragonic_knight_hunter_z]
kill @e[type=animasi:exaid_lvl5]
replaceitem entity @s slot.armor.head 1 rider:exaid_dragonic_knight_hunter_z 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_exaid_lvl5 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:exaid_lvl5
clear @s off:off_exaid
effect @s clear