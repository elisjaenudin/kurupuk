effect @e[hasitem={item=rider:cronus,location=slot.armor.head}] jump_boost 1 9 true
effect @e[hasitem={item=rider:cronus,location=slot.armor.head}] regeneration 1 1 true
effect @e[hasitem={item=rider:cronus,location=slot.armor.head}] resistance 1 1 true
effect @e[hasitem={item=rider:cronus,location=slot.armor.head}] strength 1 4 true
effect @e[hasitem={item=rider:cronus,location=slot.armor.head}] weakness 1 0 true
