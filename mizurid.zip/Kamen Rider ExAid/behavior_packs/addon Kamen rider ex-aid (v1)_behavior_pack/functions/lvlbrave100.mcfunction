summon animasi:taddle_legecy
tp @e[type=animasi:taddle_legecy] @s
give @s hensin:brave_lvl100 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:brave_lvl100