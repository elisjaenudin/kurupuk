kill @e[type=animasi:poppy]
replaceitem entity @s slot.armor.head 1 rider:poppy 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_poppy 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:poppy