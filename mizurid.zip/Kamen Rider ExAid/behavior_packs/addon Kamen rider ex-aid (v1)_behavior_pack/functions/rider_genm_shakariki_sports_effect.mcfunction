effect @e[hasitem={item=rider:genm_shakariki_sports,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:genm_shakariki_sports,location=slot.armor.head}] strength 1 0 true
effect @e[hasitem={item=rider:genm_shakariki_sports,location=slot.armor.head}] weakness 1 0 true
