summon animasi:poppy
tp @e[type=animasi:poppy] @s
give @s hensin:poppy 1 0 {"item_lock":{"mode":"lock_in_inventory"}}