effect @e[hasitem={item=rider:exaid_dragonic_knight_hunter_z,location=slot.armor.head}] fire_resistance 1 0 true
effect @e[hasitem={item=rider:exaid_dragonic_knight_hunter_z,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:exaid_dragonic_knight_hunter_z,location=slot.armor.head}] resistance 1 0 true
effect @e[hasitem={item=rider:exaid_dragonic_knight_hunter_z,location=slot.armor.head}] speed 1 0 true
effect @e[hasitem={item=rider:exaid_dragonic_knight_hunter_z,location=slot.armor.head}] strength 1 0 true
