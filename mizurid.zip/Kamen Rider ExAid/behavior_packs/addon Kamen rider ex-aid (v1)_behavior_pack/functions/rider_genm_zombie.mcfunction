replaceitem entity @s slot.armor.head 1 rider:genm_zombie
replaceitem entity @s slot.weapon.mainhand 0 air