effect @e[hasitem={item=rider:exaid_mighty_brother,location=slot.armor.head}] invisibility 1 0 true
effect @e[hasitem={item=rider:exaid_mighty_brother,location=slot.armor.head}] resistance 1 0 true
