kill @e[type=animasi:taddle_fantasy]
kill @e[type=animasi:brave_lvl50]
replaceitem entity @s slot.armor.head 1 rider:brave_taddle_fantasy 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_brave_lvl50 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
give @s weapons:gashacon_sword_ice
clear @s hensin:brave_lvl50
effect @s clear