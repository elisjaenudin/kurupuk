effect @e[hasitem={item=rider:lazer_girigiri_chambara,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:lazer_girigiri_chambara,location=slot.armor.head}] slow_falling 1 0 true
effect @e[hasitem={item=rider:lazer_girigiri_chambara,location=slot.armor.head}] strength 1 0 true
