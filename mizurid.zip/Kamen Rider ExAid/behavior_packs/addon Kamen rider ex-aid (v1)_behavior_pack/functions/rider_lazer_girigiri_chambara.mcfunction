replaceitem entity @s slot.armor.head 1 rider:lazer_girigiri_chambara
replaceitem entity @s slot.weapon.mainhand 0 air