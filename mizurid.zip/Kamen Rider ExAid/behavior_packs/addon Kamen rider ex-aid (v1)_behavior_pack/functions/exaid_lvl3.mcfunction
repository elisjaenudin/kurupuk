kill @e[type=animasi:gekitotsu_robots]
kill @e[type=animasi:exaid_lvl3]
replaceitem entity @s slot.armor.head 1 rider:exaid_gekitotsu_robots 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_exaid_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:exaid_lvl3
clear @s off:off_exaid
effect @s clear