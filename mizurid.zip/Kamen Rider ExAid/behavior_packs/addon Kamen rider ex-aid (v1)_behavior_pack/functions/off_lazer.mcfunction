kill @e[type=ridermods:lazer_lvl2]
replaceitem entity @s slot.armor.head 1 air
replaceitem entity @s slot.armor.legs 1 air
give @s driver:gamer_driver
give @s gashat:bakusou_bike_gashat
clear @s off:off_lazer
clear @s lvl:lazer