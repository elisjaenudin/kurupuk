replaceitem entity @s slot.armor.head 1 air
give @s driver:gamer_driver
give @s gashat:mighty_action_x_gashat
give @s gashat:gekitotsu_robots_gashat
clear @s weapons:gashacon_breaker
clear @s weapons:gashacon_breaker2
clear @s off:off_exaid_lvl3