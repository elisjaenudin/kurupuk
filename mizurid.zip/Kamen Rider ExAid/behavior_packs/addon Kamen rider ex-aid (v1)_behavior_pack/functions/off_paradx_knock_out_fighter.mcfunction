replaceitem entity @s slot.armor.head 1 air
give @s gashat:knock_out_fighter_gashat
clear @s off:off_paradx_knock_out_fighter