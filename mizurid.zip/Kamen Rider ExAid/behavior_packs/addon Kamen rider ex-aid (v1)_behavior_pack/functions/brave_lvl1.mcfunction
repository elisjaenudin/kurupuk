kill @e[type=animasi:brave]
replaceitem entity @s slot.armor.head 1 rider:brave 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s lvl:brave 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s off:off_brave 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s weapons:gashacon_sword_ice
clear @s hensin:brave