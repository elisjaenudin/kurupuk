effect @e[hasitem={item=rider:paradx_lvl99,location=slot.armor.head}] fire_resistance 1 0 true
effect @e[hasitem={item=rider:paradx_lvl99,location=slot.armor.head}] jump_boost 1 9 true
effect @e[hasitem={item=rider:paradx_lvl99,location=slot.armor.head}] regeneration 1 1 true
effect @e[hasitem={item=rider:paradx_lvl99,location=slot.armor.head}] resistance 1 1 true
effect @e[hasitem={item=rider:paradx_lvl99,location=slot.armor.head}] strength 1 0 true
