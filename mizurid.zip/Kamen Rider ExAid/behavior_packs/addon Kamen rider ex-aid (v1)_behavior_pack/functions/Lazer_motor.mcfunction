summon motor:lazer
give @s off:off_motor