replaceitem entity @s slot.armor.head 1 air 
give @s driver:gamer_driver
give @s gashat:perfect_puzzle_gashat_lvl99
clear @s weapons:gashacon_paranragun
clear @s weapons:gashacon_paranragun2
clear @s gun:gun
clear @s off:off_paradx_lvl99