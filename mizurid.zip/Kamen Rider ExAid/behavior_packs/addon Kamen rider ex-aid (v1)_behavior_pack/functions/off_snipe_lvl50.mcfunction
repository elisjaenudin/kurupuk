replaceitem entity @s slot.armor.head 1 air
give @s driver:gamer_driver
give @s gashat:bangbang_simulations_gashat
clear @s gun:gun
clear @s off:off_snipe_lvl50