kill @e[type=animasi:genm]
replaceitem entity @s slot.armor.head 1 rider:genm 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s lvl:genm 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s off:off_genm 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:genm