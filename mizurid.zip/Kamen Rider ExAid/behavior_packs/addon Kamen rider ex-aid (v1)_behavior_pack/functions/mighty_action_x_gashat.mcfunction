summon animasi:exaid
tp @e[type=animasi:exaid] @s
give @s hensin:exaid 1 0 {"item_lock":{"mode":"lock_in_inventory"}}