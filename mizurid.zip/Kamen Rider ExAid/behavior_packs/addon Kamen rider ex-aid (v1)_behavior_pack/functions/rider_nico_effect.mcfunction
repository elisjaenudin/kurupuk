effect @e[hasitem={item=rider:nico,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:nico,location=slot.armor.head}] resistance 1 0 true
effect @e[hasitem={item=rider:nico,location=slot.armor.head}] strength 1 0 true
