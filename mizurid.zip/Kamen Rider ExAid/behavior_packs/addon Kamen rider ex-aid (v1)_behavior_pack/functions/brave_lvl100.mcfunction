kill @e[type=animasi:taddle_legecy]
kill @e[type=animasi:brave_lvl100]
replaceitem entity @s slot.armor.head 1 rider:brave_taddle_legecy 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_brave_lvl100 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
give @s weapons:gashacon_sword_ice
clear @s hensin:brave_lvl100
effect @s clear