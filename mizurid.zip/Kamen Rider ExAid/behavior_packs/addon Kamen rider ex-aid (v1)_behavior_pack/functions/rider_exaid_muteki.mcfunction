replaceitem entity @s slot.armor.head 1 rider:exaid_muteki
replaceitem entity @s slot.weapon.mainhand 0 air