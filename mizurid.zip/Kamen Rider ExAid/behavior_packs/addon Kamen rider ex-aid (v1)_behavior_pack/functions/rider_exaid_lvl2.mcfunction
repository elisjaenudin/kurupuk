replaceitem entity @s slot.armor.head 1 rider:exaid_lvl2
replaceitem entity @s slot.weapon.mainhand 0 air