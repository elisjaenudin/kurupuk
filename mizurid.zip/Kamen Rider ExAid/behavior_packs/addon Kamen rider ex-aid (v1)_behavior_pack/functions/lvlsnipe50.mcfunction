summon animasi:bangbang_simulations
tp @e[type=animasi:bangbang_simulations] @s
give @s hensin:snipe_lvl50 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:snipe_lvl50