playsound sound_paradx_lvl99_shot @s[r=20]
summon animasi:paradx_lvl99
tp @e[type=animasi:paradx_lvl99] @s
give @s hensin:paradx_lvl99 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s gashat:perfect_puzzle_gashat_lvl99