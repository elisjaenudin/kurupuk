replaceitem entity @s slot.armor.head 1 rider:exaid_juju_burger
replaceitem entity @s slot.weapon.mainhand 0 air