summon animasi:girigiri_chambara
tp @e[type=animasi:girigiri_chambara] @s
give @s hensin:lazer_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:lazer_lvl3