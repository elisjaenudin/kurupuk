replaceitem entity @s slot.armor.head 1 rider:lazer_turbo
replaceitem entity @s slot.weapon.mainhand 0 air