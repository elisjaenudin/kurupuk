kill @e[type=animasi:bangbang_simulations]
kill @e[type=animasi:snipe_lvl50]
replaceitem entity @s slot.armor.head 1 rider:snipe_bangbang_simulations 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_snipe_lvl50 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
give @s gun:gun 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:snipe_lvl50
effect @s clear