summon animasi:lazer
tp @e[type=animasi:lazer] @s
give @s hensin:lazer 1 0 {"item_lock":{"mode":"lock_in_inventory"}}