replaceitem entity @s slot.armor.head 1 rider:player
replaceitem entity @s slot.weapon.mainhand 0 air