replaceitem entity @s slot.armor.head 1 rider:lazer_lvl2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
summon ridermods:lazer_lvl2
tp @e[type=ridermods:lazer_lvl2] @s
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:lazer_lvl2
effect @s clear