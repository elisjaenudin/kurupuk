playsound sound_genm_lvl2_shot @s[r=20]
playanimation @s animation.animasi_genm_lvl2.custom.new_1
give @s hensin:genm_lvl2 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:genm