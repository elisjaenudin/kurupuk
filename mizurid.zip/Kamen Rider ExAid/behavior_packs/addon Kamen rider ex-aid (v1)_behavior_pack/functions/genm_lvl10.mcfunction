kill @e[type=animasi:genm_zombie]
replaceitem entity @s slot.armor.head 1 rider:genm_zombie 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_genm_lvl10 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s weapons:gashacon_sparrow
clear @s hensin:genm_zombie