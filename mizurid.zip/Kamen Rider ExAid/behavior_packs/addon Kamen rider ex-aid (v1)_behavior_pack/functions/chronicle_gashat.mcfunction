summon animasi:cronus
tp @e[type=animasi:cronus] @s
give @s hensin:cronus 1 0 {"item_lock":{"mode":"lock_in_inventory"}}