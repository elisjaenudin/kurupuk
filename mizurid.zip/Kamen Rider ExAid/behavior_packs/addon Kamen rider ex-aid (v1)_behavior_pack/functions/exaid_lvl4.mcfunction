kill @e[type=animasi:juju_burger]
kill @e[type=animasi:exaid_lvl4]
replaceitem entity @s slot.armor.head 1 rider:exaid_juju_burger 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_exaid_lvl4 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:exaid_lvl4
clear @s off:off_exaid
effect @s clear