effect @e[hasitem={item=player:player,location=slot.armor.head}] invisibility 1 0 true
