replaceitem entity @s slot.armor.head 1 rider:exaid_mighty_brother
replaceitem entity @s slot.weapon.mainhand 0 air