replaceitem entity @s slot.armor.head 1 rider:genm_lvl2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:genm_lvl2
effect @s clear