summon animasi:paradx_knock_out_fighter
tp @e[type=animasi:paradx_knock_out_fighter] @s
give @s hensin:paradx_knock_out_fighter 1 0 {"item_lock":{"mode":"lock_in_inventory"}}