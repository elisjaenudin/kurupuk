summon animasi:genm
tp @e[type=animasi:genm] @s
give @s hensin:genm 1 0 {"item_lock":{"mode":"lock_in_inventory"}}