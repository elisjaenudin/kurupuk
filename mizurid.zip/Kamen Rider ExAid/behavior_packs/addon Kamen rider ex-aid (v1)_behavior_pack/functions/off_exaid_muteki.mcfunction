kill @e[type=ridermods:exaid_lvl10]
replaceitem entity @s slot.armor.head 1 air
give @s driver:gamer_driver
give @s gashat:maximum_mighty_x_gashat
give @s gashat:hyper_muteki_gashat
clear @s weapons:gashacon_key_slasher
clear @s off:off_exaid_muteki