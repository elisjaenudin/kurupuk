replaceitem entity @s slot.armor.head 1 air
replaceitem entity @s slot.armor.legs 1 air
give @s driver:gamer_driver
give @s gashat:mighty_action_x_gashat
clear @s weapons:gashacon_breaker
clear @s weapons:gashacon_breaker2
clear @s off:off_exaid
clear @s lvl:exaid