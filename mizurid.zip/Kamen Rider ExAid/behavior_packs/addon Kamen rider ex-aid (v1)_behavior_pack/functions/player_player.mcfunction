replaceitem entity @s slot.armor.head 1 player:player
replaceitem entity @s slot.weapon.mainhand 0 air