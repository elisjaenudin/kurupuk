kill @e[type=ridermods:exaid_lvl10]
replaceitem entity @s slot.armor.head 1 air
give @s driver:gamer_driver
give @s gashat:mighty_brother_xx_gashat
clear @s off:off_exaid_lvl20
clear @s lvl:exaid_lvl10
clear @s weapons:gashacon_key_slasher