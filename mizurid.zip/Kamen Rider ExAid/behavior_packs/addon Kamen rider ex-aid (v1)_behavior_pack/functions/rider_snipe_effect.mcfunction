effect @e[hasitem={item=rider:snipe,location=slot.armor.head}] invisibility 1 0 true
