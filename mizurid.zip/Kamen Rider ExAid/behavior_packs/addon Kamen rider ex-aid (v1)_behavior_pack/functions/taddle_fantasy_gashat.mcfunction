summon animasi:brave_lvl50
tp @e[type=animasi:brave_lvl50] @s
give @s lvl:brave_lvl50 1 0 {"item_lock":{"mode":"lock_in_inventory"}}