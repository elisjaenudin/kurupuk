effect @e[hasitem={item=rider:exaid_lvl2,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:exaid_lvl2,location=slot.armor.head}] strength 1 0 true
