kill @e[type=animasi:paradx_lvl99]
replaceitem entity @s slot.armor.head 1 rider:paradx_lvl99 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_paradx_lvl99 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s weapons:gashacon_paranragun
give @s gun:gun 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:paradx_lvl99