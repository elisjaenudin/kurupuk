summon animasi:doremifa_beat
tp @e[type=animasi:doremifa_beat] @s
give @s hensin:brave_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:brave_lvl3