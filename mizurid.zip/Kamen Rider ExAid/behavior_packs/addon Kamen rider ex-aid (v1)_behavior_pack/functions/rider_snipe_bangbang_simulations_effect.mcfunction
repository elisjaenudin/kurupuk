effect @e[hasitem={item=rider:snipe_bangbang_simulations,location=slot.armor.head}] bad_omen 1 0 true
effect @e[hasitem={item=rider:snipe_bangbang_simulations,location=slot.armor.head}] jump_boost 1 9 true
effect @e[hasitem={item=rider:snipe_bangbang_simulations,location=slot.armor.head}] regeneration 1 4 true
effect @e[hasitem={item=rider:snipe_bangbang_simulations,location=slot.armor.head}] strength 1 0 true
effect @e[hasitem={item=rider:snipe_bangbang_simulations,location=slot.armor.head}] water_breathing 1 1 true
