effect @e[hasitem={item=rider:brave,location=slot.armor.head}] invisibility 1 0 true
