replaceitem entity @s slot.armor.head 1 rider:paradx_lvl99
replaceitem entity @s slot.weapon.mainhand 0 air