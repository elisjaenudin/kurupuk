playsound sound_exaid_lvl10_shot @s[r=20]
playanimation @s animation.animasi_exaid_lvl10.custom.new_1
give @s hensin:exaid_lvl10 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:exaid_lvl10