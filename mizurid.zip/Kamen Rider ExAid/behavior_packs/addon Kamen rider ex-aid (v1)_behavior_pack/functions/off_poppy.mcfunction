replaceitem entity @s slot.armor.head 1 air
replaceitem entity @s slot.armor.legs 1 air
give @s driver:buggle_driver_zwei
give @s gashat:tokimeki_crisis_gashat
clear @s off:off_poppy