replaceitem entity @s slot.armor.head 1 air
replaceitem entity @s slot.armor.legs 1 air
give @s driver:gamer_driver
give @s gashat:proto_mighty_action_x_gashat
clear @s off:off_genm
clear @s lvl:genm