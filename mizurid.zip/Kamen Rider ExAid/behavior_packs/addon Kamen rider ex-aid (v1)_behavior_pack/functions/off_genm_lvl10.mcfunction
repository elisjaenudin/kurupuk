replaceitem entity @s slot.armor.head 1 air
replaceitem entity @s slot.armor.legs 1 air
give @s driver:buggle_driver
give @s gashat:dangerous_zombie_gashat
clear @s weapons:gashacon_sparrow
clear @s weapons:gashacon_sparrow2
clear @s off:off_genm_lvl10