replaceitem entity @s slot.armor.head 1 rider:snipe_bangbang_simulations
replaceitem entity @s slot.weapon.mainhand 0 air