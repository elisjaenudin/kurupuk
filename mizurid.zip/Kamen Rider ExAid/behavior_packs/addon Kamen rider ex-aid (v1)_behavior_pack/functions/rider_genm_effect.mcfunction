effect @e[hasitem={item=rider:genm,location=slot.armor.head}] invisibility 1 0 true
