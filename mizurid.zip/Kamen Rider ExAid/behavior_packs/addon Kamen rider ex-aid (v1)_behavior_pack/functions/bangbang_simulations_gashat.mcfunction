summon animasi:snipe_lvl50
tp @e[type=animasi:snipe_lvl50] @s
give @s lvl:snipe_lvl50 1 0 {"item_lock":{"mode":"lock_in_inventory"}}