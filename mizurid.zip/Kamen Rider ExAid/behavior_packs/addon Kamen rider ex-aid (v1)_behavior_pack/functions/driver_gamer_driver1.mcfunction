replaceitem entity @s slot.armor.legs 1 driver:gamer_driver1
replaceitem entity @s slot.weapon.mainhand 0 air