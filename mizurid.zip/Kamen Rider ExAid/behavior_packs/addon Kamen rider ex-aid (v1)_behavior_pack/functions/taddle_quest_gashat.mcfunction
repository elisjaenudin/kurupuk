summon animasi:brave
tp @e[type=animasi:brave] @s
give @s hensin:brave 1 0 {"item_lock":{"mode":"lock_in_inventory"}}