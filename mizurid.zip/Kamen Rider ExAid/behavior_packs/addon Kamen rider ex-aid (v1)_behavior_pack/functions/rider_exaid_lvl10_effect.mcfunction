effect @e[hasitem={item=rider:exaid_lvl10,location=slot.armor.head}] regeneration 1 1 true
effect @e[hasitem={item=rider:exaid_lvl10,location=slot.armor.head}] resistance 1 1 true
effect @e[hasitem={item=rider:exaid_lvl10,location=slot.armor.head}] strength 1 0 true
