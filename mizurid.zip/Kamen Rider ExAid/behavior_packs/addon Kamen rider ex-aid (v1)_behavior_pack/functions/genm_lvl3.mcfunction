kill @e[type=animasi:shakariki_sports]
kill @e[type=animasi:genm_lvl3]
replaceitem entity @s slot.armor.head 1 rider:genm_shakariki_sports 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_qgenm_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:genm_lvl3
clear @s off:off_genm
effect @s clear