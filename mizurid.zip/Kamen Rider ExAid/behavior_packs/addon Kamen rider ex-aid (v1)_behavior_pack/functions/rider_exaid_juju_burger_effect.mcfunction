effect @e[hasitem={item=rider:exaid_juju_burger,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:exaid_juju_burger,location=slot.armor.head}] speed 1 0 true
effect @e[hasitem={item=rider:exaid_juju_burger,location=slot.armor.head}] strength 1 0 true
