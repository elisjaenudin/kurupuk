summon animasi:genm_lvl3
tp @e[type=animasi:genm_lvl3] @s
give @s lvl:genm_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:genm