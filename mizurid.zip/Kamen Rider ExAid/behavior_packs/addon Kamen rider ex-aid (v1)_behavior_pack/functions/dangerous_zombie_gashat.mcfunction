summon animasi:genm_zombie
tp @e[type=animasi:genm_zombie] @s
give @s hensin:genm_zombie 1 0 {"item_lock":{"mode":"lock_in_inventory"}}