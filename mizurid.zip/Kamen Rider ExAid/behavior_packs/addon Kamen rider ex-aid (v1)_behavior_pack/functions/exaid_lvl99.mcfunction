kill @e[type=animasi:maximun]
kill @e[type=animasi:maximun_lvl99]
kill @e[type=animasi:exaid_lvl99]
replaceitem entity @s slot.armor.head 1 rider:exaid_maximum 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_exaid_lvl99 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s weapons:gashacon_key_slasher
clear @s hensin:exaid_maximun
effect @s clear