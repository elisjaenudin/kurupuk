summon animasi:gekitotsu_robots
tp @e[type=animasi:gekitotsu_robots] @s
give @s hensin:exaid_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:exaid_lvl3