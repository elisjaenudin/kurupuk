kill @e[type=animasi:jet_combat]
kill @e[type=animasi:snipe_lvl3]
replaceitem entity @s slot.armor.head 1 rider:snipe_jet_combat 1 0 {"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @s slot.armor.chest 1 Elytra 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_snipe_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:snipe_lvl3
clear @s off:off_snipe
effect @s clear