kill @e[type=animasi:exaid_lvlmuteki1]
kill @e[type=animasi:exaid_lvlmuteki]
kill @e[type=animasi:muteki]
kill @e[type=animasi:exaid_muteki]
replaceitem entity @s slot.armor.head 1 rider:exaid_muteki 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_exaid_muteki 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:exaid_muteki
effect @s clear
clear @s off:off_exaid_lvl99