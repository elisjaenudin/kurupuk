summon animasi:maximun
summon animasi:maximun_lvl99
tp @e[type=animasi:maximun] @s
tp @e[type=animasi:maximun_lvl99] @s
replaceitem entity @s slot.armor.legs 1 air
replaceitem entity @s slot.armor.head 1 player:player 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s hensin:exaid_maximun 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:exaid_lvl99