summon animasi:paradx_perfect_puzzle
tp @e[type=animasi:paradx_perfect_puzzle] @s
give @s hensin:paradx_perfect_puzzle 1 0 {"item_lock":{"mode":"lock_in_inventory"}}