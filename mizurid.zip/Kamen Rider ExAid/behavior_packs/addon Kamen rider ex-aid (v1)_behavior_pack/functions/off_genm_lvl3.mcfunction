replaceitem entity @s slot.armor.head 1 air
give @s driver:gamer_driver
give @s gashat:proto_mighty_action_x_gashat
give @s gashat:shakariki_sports_gashat
clear @s off:off_qgenm_lvl3