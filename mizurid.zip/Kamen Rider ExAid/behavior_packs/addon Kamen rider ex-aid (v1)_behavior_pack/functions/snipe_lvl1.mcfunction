kill @e[type=animasi:snipe]
replaceitem entity @s slot.armor.head 1 rider:snipe 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s lvl:snipe 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s off:off_snipe 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s weapons:gashacon_magnum
give @s gun:gun 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:snipe