effect @e[hasitem={item=rider:exaid_maximum,location=slot.armor.head}] regeneration 1 1 true
effect @e[hasitem={item=rider:exaid_maximum,location=slot.armor.head}] resistance 1 1 true
effect @e[hasitem={item=rider:exaid_maximum,location=slot.armor.head}] slowness 1 0 true
effect @e[hasitem={item=rider:exaid_maximum,location=slot.armor.head}] strength 1 0 true
effect @e[hasitem={item=rider:exaid_maximum,location=slot.armor.head}] weakness 1 1 true
