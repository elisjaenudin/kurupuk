kill @e[type=animasi:cronus]
replaceitem entity @s slot.armor.head 1 rider:cronus 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_cronus 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:cronus