effect @e[hasitem={item=rider:lazer_turbo,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:lazer_turbo,location=slot.armor.head}] resistance 1 0 true
effect @e[hasitem={item=rider:lazer_turbo,location=slot.armor.head}] speed 1 0 true
effect @e[hasitem={item=rider:lazer_turbo,location=slot.armor.head}] strength 1 0 true
