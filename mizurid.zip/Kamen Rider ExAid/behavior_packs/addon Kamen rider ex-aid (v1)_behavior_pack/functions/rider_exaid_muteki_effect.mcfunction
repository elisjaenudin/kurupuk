effect @e[hasitem={item=rider:exaid_muteki,location=slot.armor.head}] village_hero 1 3 true
effect @e[hasitem={item=rider:exaid_muteki,location=slot.armor.head}] jump_boost 1 5 true
effect @e[hasitem={item=rider:exaid_muteki,location=slot.armor.head}] night_vision 1 0 true
effect @e[hasitem={item=rider:exaid_muteki,location=slot.armor.head}] regeneration 1 4 true
effect @e[hasitem={item=rider:exaid_muteki,location=slot.armor.head}] resistance 1 1 true
effect @e[hasitem={item=rider:exaid_muteki,location=slot.armor.head}] strength 1 0 true
effect @e[hasitem={item=rider:exaid_muteki,location=slot.armor.head}] weakness 1 1 true
