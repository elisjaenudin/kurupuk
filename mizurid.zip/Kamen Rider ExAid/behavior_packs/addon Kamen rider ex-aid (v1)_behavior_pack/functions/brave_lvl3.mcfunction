kill @e[type=animasi:doremifa_beat]
kill @e[type=animasi:brave_lvl3]
replaceitem entity @s slot.armor.head 1 rider:brave_doremifa_beat 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_brave_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
clear @s hensin:brave_lvl3
clear @s off:off_brave
effect @s clear