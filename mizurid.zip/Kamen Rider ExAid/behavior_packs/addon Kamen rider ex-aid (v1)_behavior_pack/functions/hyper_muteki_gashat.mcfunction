summon animasi:exaid_muteki
tp @e[type=animasi:exaid_muteki] @s
give @s hensin:exaid_muteki 1 0 {"item_lock":{"mode":"lock_in_inventory"}}