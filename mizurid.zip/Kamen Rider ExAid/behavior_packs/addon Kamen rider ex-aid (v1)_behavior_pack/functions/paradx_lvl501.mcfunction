kill @e[type=animasi:paradx_knock_out_fighter]
replaceitem entity @s slot.armor.head 1 rider:paradx_knock_out_fighter 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_paradx_knock_out_fighter 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:paradx_knock_out_fighter
clear @s off:off_paradx_perfect_puzzle