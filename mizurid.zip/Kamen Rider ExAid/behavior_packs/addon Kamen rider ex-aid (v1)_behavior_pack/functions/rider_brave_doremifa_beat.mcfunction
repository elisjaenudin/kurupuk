replaceitem entity @s slot.armor.head 1 rider:brave_doremifa_beat
replaceitem entity @s slot.weapon.mainhand 0 air