kill @e[type=animasi:exaid_lvl20]
replaceitem entity @s slot.armor.head 1 rider:exaid_mighty_brother 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s lvl:exaid_lvl10 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s off:off_exaid_lvl20 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:exaid_lvl20