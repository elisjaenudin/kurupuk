summon animasi:taddle_fantasy
tp @e[type=animasi:taddle_fantasy] @s
give @s hensin:brave_lvl50 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:brave_lvl50