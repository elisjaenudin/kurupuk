summon animasi:shakariki_sports
tp @e[type=animasi:shakariki_sports] @s
give @s hensin:genm_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s lvl:genm_lvl3