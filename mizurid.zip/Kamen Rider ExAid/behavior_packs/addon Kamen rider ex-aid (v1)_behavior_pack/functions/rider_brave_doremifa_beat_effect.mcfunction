effect @e[hasitem={item=rider:brave_doremifa_beat,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:brave_doremifa_beat,location=slot.armor.head}] strength 1 0 true
effect @e[hasitem={item=rider:brave_doremifa_beat,location=slot.armor.head}] water_breathing 1 0 true
