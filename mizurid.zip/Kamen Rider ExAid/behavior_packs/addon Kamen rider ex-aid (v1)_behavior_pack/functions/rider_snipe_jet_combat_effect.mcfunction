effect @e[hasitem={item=rider:snipe_jet_combat,location=slot.armor.head}] jump_boost 1 0 true
effect @e[hasitem={item=rider:snipe_jet_combat,location=slot.armor.head}] regeneration 1 0 true
effect @e[hasitem={item=rider:snipe_jet_combat,location=slot.armor.head}] strength 1 0 true
