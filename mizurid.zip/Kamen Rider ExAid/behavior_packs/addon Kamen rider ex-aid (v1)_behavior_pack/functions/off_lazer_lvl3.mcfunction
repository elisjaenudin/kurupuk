kill @e[type=ridermods:lazer_lvl2]
replaceitem entity @s slot.armor.head 1 air
give @s driver:gamer_driver
give @s gashat:bakusou_bike_gashat
give @s gashat:girigiri_chambara_gashat
clear @s weapons:gashacon_sparrow
clear @s weapons:gashacon_sparrow2
clear @s gun:gun
clear @s off:off_lazer_lvl3