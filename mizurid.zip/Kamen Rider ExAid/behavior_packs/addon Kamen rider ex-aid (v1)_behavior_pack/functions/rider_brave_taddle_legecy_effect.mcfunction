effect @e[hasitem={item=rider:brave_taddle_legecy,location=slot.armor.head}] jump_boost 1 9 true
effect @e[hasitem={item=rider:brave_taddle_legecy,location=slot.armor.head}] regeneration 1 4 true
effect @e[hasitem={item=rider:brave_taddle_legecy,location=slot.armor.head}] slow_falling 1 0 true
effect @e[hasitem={item=rider:brave_taddle_legecy,location=slot.armor.head}] strength 1 0 true
