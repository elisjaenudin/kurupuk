replaceitem entity @s slot.armor.head 1 air
give @s gashat:perfect_puzzle_gashat
clear @s off:off_paradx_perfect_puzzle