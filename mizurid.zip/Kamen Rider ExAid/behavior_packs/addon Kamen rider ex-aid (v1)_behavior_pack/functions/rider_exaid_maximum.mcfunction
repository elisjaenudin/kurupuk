replaceitem entity @s slot.armor.head 1 rider:exaid_maximum
replaceitem entity @s slot.weapon.mainhand 0 air