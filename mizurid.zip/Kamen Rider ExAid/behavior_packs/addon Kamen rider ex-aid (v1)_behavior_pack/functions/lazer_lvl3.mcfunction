kill @e[type=animasi:girigiri_chambara]
kill @e[type=animasi:laze_lvl3]
kill @e[type=ridermods:lazer_lvl2]
replaceitem entity @s slot.armor.head 1 rider:lazer_girigiri_chambara 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_lazer_lvl3 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
replaceitem entity @s slot.armor.legs 1 air
give @s weapons:gashacon_sparrow
give @s gun:gun 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
clear @s hensin:lazer_lvl3
clear @s off:off_lazer
effect @s clear