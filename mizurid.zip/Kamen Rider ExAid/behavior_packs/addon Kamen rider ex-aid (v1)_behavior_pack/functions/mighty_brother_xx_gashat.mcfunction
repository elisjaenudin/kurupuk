summon animasi:exaid_lvl20
tp @e[type=animasi:exaid_lvl20] @s
give @s hensin:exaid_lvl20 1 0 {"item_lock":{"mode":"lock_in_inventory"}}