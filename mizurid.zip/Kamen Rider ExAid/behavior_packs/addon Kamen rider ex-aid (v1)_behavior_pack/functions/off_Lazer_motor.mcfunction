kill @e[type=motor:lazer]
clear @s off:off_motor