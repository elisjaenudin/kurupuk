kill @e[type=animasi:lazer]
replaceitem entity @s slot.armor.head 1 rider:lazer_turbo 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s off:off_lazer_turbo 1 0 {"item_lock":{"mode":"lock_in_inventory"}}
give @s weapons:gashacon_sparrow
give @s motor:bakusou_bike_gashat
clear @s hensin:lazer_turbo