summon animasi:lazer
tp @e[type=animasi:lazer] @s
give @s hensin:lazer_turbo 1 0 {"item_lock":{"mode":"lock_in_inventory"}}