effect @e[hasitem={item=rider:exaid,location=slot.armor.head}] invisibility 1 0 true
