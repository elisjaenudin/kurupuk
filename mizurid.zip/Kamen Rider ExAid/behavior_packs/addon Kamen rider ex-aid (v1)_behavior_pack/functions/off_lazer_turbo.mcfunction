replaceitem entity @s slot.armor.head 1 air
replaceitem entity @s slot.armor.legs 1 air
give @s driver:gamer_driver
give @s gashat:bakusou_bike_gashat_turbo
give @s weapons:gashacon_sparrow
clear @s weapons:gashacon_sparrow
clear @s weapons:gashacon_sparrow
clear @s motor:bakusou_bike_gashat
clear @s off:off_lazer_turbo