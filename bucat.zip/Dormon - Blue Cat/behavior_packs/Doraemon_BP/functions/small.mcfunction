execute @s ^^^5 scoreboard players add @e[r = 4.5, scores={size=-21..25}] size -1
execute @s ^^^5 execute  @e[r = 4.5, scores={size=-21..25}] ~~~ say small
function size