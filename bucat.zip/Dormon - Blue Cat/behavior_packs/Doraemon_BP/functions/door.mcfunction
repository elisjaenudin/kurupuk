
scoreboard objectives add door dummy door
scoreboard objectives add door1 dummy door1

scoreboard players add @s door 0
execute @s[scores={door=0}] ~ ~ ~ scoreboard players add * door 1
execute @s[scores={door=0}] ~ ~ ~ scoreboard players set @a[tag=!door] door 0
execute @s[scores={door=0}] ~ ~ ~ scoreboard players set @s door 1
tag @s add door

execute @e[type=dor:where_door,scores={door=!0}] ~ ~ ~ scoreboard players operation @s door1 = @s door
execute @s ~ ~ ~ summon dor:where_door ~ ~ ~
execute @s ~ ~ ~ scoreboard players operation @e[type=dor:where_door,c=1] door = @s door
execute @s[tag=door3] ~ ~ ~ scoreboard players operation @e[type=dor:where_door,scores={door=!0}] door1 -= @s door
execute @s[tag=door3] ~ ~ ~ kill @e[type=dor:where_door,scores={door1=0},tag=door1]
execute @s[tag=door3] ~ ~ ~ tag @s add door1_fake1
execute @s[tag=door3] ~ ~ ~ tag @e[type=dor:where_door,c=1] add door1
execute @s[tag=door3] ~ ~ ~ tag @s remove door3
execute @s[tag=door2] ~ ~ ~ scoreboard players operation @e[type=dor:where_door,scores={door=!0}] door1 -= @s door
execute @s[tag=door2] ~ ~ ~ kill @e[type=dor:where_door,scores={door1=0},tag=door]
execute @s[tag=door2] ~ ~ ~ tag @s add door3
execute @s[tag=door2] ~ ~ ~ tag @e[type=dor:where_door,c=1] add door
execute @s[tag=door2] ~ ~ ~ tag @s remove door2
execute @s[tag=!door1,tag=!door2,tag=!door3] ~ ~ ~ tag @e[type=dor:where_door,c=1] add door
execute @s[tag=door1,tag=!door2,tag=!door3] ~ ~ ~ tag @e[type=dor:where_door,c=1] add door1
execute @s[tag=!door1,tag=!door2,tag=!door3] ~ ~ ~ tag @s add door1_fake
execute @s[tag=door1,tag=!door2,tag=!door3] ~ ~ ~ tag @s add door1_fake1
execute @s ~ ~ ~ tp @e[type=dor:door_where,r=1,c=1] ^ ^ ^-0.1 facing @s

tag @s[tag=door1_fake] add door1
tag @s[tag=door1_fake1] add door2
tag @s[tag=door1_fake] remove door1_fake
tag @s[tag=door1_fake1] remove door1_fake1