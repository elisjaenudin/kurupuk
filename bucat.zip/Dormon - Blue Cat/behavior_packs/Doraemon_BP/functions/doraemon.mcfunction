
tag @e[tag=door_teleport] remove door_teleport
tag @e[tag=door_join] remove door_join
execute @e[type=dor:where_door,scores={door=!0}] ~ ~ ~ scoreboard players operation @s door1 = @s door
execute @e[type=dor:where_door] ~ ~ ~ execute @e[type=!dor:where_door,r=1.5,c=1] ~ ~ ~ tag @e[type=dor:where_door,r=1.5] add door_join
execute @e[type=dor:where_door,tag=door_join] ~ ~ ~ scoreboard players operation @e[tag=!door_join,type=dor:where_door] door1 -= @s door
execute @e[type=dor:where_door,tag=door_join] ~ ~ ~ execute @e[type=!dor:where_door,r=1.5] ~ ~ ~ tag @s add door_teleport
execute @e[type=dor:where_door,tag=door_join] ~ ~ ~ execute @e[type=dor:where_door,scores={door1=0}] ~ ~ ~ tp @e[tag=door_teleport,type=!dor:where_door] ^ ^ ^2