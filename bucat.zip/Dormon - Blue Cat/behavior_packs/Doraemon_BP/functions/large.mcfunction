execute @s ^^^5 scoreboard players add @e[r = 4.5,scores={size=-22..24}] size 1
execute @s ^^^5 execute  @e[r = 4.5, scores={size=-22..25}] ~~~ say large
function size