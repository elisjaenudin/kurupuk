kill @e[type=mebesm:box,c=1]
scoreboard players set @p ScJ 0