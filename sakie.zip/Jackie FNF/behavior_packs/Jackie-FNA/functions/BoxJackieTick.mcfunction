playsound open @a[r=15]
gamerule sendcommandfeedback false
scoreboard objectives add ScJ dummy
scoreboard players add @a[r=10, m=survival] ScJ 1
execute as @a[r=10,m=survival,scores={ScJ=10..}] run function BoxJackieSumm