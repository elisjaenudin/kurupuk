summon mebesm:box ~ ~ ~ ~
playsound start @a[r=15]