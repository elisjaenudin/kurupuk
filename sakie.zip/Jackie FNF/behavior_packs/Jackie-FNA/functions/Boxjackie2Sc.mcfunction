gamerule sendcommandfeedback false
scoreboard objectives add Scarr dummy
scoreboard players add @a[r=5, m=survival] Scarr 1
execute as @a[r=6, m=survival, scores={Scarr=7..}] run function Boxjackie2Scar