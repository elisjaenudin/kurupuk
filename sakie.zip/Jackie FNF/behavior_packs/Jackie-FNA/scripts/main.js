import { world, system, Player } from '@minecraft/server';
import { MessageFormData } from '@minecraft/server-ui';

// Функция, которая будет вызываться при ударе игроком
function onJackieBoxHitByPlayer(playerHitting) {
    // Получаем имя игрока, который ударил
    const playerName = playerHitting.name;

    // Пример 1: Отправка сообщения в чат
    world.sendMessage(`§aJackie Box: §eМеня ударил игрок §b${playerName}!`);

    // Пример 2: Воспроизведение звука для всех игроков
    // world.playSound("random.orb", playerHitting.location); // Звук при поднятии опыта

    // Пример 3: Показать UI форму игроку, который ударил
    // if (playerHitting instanceof Player) {
    //     const form = new MessageFormData()
    //         .title("Jackie Box")
    //         .body(`Привет, ${playerName}! Ты ударил Jackie Box!`)
    //         .button1("Спасибо!")
    //         .button2("ОК");

    //     form.show(playerHitting).then(response => {
    //         if (response.selection === 0) { // Нажал "Спасибо!"
    //             playerHitting.sendMessage("Ты нажал Спасибо!");
    //         } else { // Нажал "ОК"
    //             playerHitting.sendMessage("Ты нажал ОК!");
    //         }
    //     }).catch(error => {
    //         console.error("Ошибка при показе формы:", error);
    //     });
    // }

    // Пример 4: Выполнение игровой команды (например, дать предмет или эффект)
    // playerHitting.runCommandAsync(`give "${playerName}" diamond 1`);
    // playerHitting.runCommandAsync(`effect "${playerName}" regeneration 5 1`);
}

// Зарегистрируем слушателя событий для каждого тика системы
system.runInterval(() => {
    // Получаем все сущности в мире
    for (const entity of world.getDimension("overworld").getEntities()) {
        // Проверяем, является ли сущность нашим Jackie Box
        if (entity.typeId === "mebesm:jackie_box") {
            // Проверяем, есть ли у сущности свойство 'currentHitByPlayer'
            // Это пользовательское свойство, которое мы установим через JSON
            if (entity.hasComponent("minecraft:variant")) { // Используем существующий компонент для проверки состояния
                const variantComponent = entity.getComponent("minecraft:variant");
                if (variantComponent.value === 1) { // Если вариант 1, значит, его ударили
                    // Предполагаем, что у вас есть способ передать игрока, который ударил.
                    // В JavaScript API для Bedrock пока нет прямого события "entity damaged by player",
                    // которое передавало бы EntityDamageByEntityEvent и давало бы доступ к источнику урона.
                    // Поэтому нам нужно будет "фиктивно" вызвать функцию.
                    // В реальном сценарии, если бы API позволял, мы бы использовали
                    // world.afterEvents.entityHit, но он не дает информации о том, кто ударил.

                    // Для целей этого примера, мы просто выведем, что Jackie Box был ударен.
                    // Если вам нужно точно знать, КТО ударил, это требует более сложного обходного пути
                    // с использованием командных блоков или других entity-based компонентов,
                    // которые могут хранить UUID игрока.

                    // Временное решение: просто выведем сообщение, что он был ударен.
                    // Вам нужно будет убедиться, что событие в JSON вызывает этот "удар".
                    // В вашем JSON `on:hurt_by_player` вызывает функцию `BoxJackie`.
                    // Чтобы связать это со скриптом, нам нужно, чтобы `BoxJackie` вызывала скрипт.

                    // Поскольку в JavaScript мы не можем напрямую перехватить событие из JSON Behavior Pack,
                    // как "on:hurt_by_player" без использования "execute_on_first_subarea",
                    // мы сделаем это через команду.

                    // ************ ВАЖНОЕ ЗАМЕЧАНИЕ ************
                    // JavaScript API не может напрямую слушать события, определенные в JSON "events"
                    // (например, "on:hurt_by_player").
                    // Для связи JSON событий с JavaScript, вы обычно:
                    // 1. Используете world.afterEvents.entityHit (для ударов)
                    // 2. Или заставляете JSON-событие запускать команду, которую скрипт затем слушает.
                    //    Например, JSON: "command": ["tag @s JackieBoxHit", "run JackieBoxScriptFunction"]
                    //    Скрипт: world.afterEvents.chatSend.subscribe(...) или world.beforeEvents.chatSend.subscribe(...)
                    //    Это немного громоздко.

                    // Лучший способ для ударов: world.afterEvents.entityHit

                    // Удаляем этот подход, так как он неэффективен для определения "кто ударил"
                    // и не соответствует напрямую вашей JSON-структуре событий.
                }
            }
        }
    }
});

// ************ ПРАВИЛЬНЫЙ ПОДХОД ДЛЯ ОБРАБОТКИ УДАРОВ В JS ************

// world.afterEvents.entityHit.subscribe - Это событие срабатывает, когда одна сущность бьет другую.
// Оно предоставит вам информацию о том, КТО ударил и ЧТО было ударено.
world.afterEvents.entityHit.subscribe(event => {
    const { hitEntity, damagingEntity } = event;

    // Проверяем, что удар был по нашему Jackie Box
    if (hitEntity && hitEntity.typeId === "mebesm:jackie_box") {
        // Проверяем, что ударившая сущность - игрок
        if (damagingEntity instanceof Player) {
            onJackieBoxHitByPlayer(damagingEntity); // Вызываем вашу функцию
        }
    }
});

// Если вам нужно, чтобы периодическая функция тоже была в JS:
// system.runInterval(() => {
//     world.sendMessage("§aJackie Box: §fПериодическое действие в JS!");
// }, 20 * 4); // Каждые 4 секунды (20 тиков в секунде * 4 секунды)