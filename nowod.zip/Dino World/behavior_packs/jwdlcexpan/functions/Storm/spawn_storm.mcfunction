#lever location 91 73 -274
#set lever in weather station off
setblock 91 74 -274 lever 3

#set rain, set countdown to a time
weather rain 1000000
scoreboard players set @e[tag=storm_zone_math] storm_time 400

scoreboard players set @e[tag=storm_zone_math] zone1loaded 1