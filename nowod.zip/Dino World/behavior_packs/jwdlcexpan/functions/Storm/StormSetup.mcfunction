#Storm Setup
scoreboard objectives add storm_time dummy

scoreboard players set @e[tag=storm_zone_math] storm_time 0
scoreboard players set @e[tag=storm_zone_math] storm_active 0