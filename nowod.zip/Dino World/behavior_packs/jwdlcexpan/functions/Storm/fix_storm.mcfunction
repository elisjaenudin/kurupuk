#if we aren't active, turn off the redstone block for this command block (which is also reset in this case)
execute @e[tag=storm_zone_math,scores={storm_active=0}] ~ ~ ~ /setblock 348 1 -469 air

#turn off solution check
execute @e[tag=storm_zone_math,scores={storm_active=0}] ~ ~ ~ /setblock 348 1 -472 air
#------------------------------------------end inactive precautions-------------------------

#create ticking zone for zone 1
execute @e[tag=storm_zone_math,scores={zone1loaded=0,storm_active=1}] ~ ~ ~ /tickingarea add circle 91 73 -274 1 stormzone
execute @e[tag=storm_zone_math,scores={zone1loaded=0,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] zone1loaded 1

#turn on lever and weather
execute @e[tag=storm_zone_math,scores={zone1loaded=1, storm_active=1}] ~ ~ ~ detect 91 72 -274 concrete 7 /scoreboard players set @e[tag=storm_zone_math] zone1loaded 2
execute @e[tag=storm_zone_math,scores={zone1loaded=2, storm_active=1}] ~ ~ ~ /weather clear 1000000
execute @e[tag=storm_zone_math,scores={zone1loaded=2, storm_active=1}] ~ ~ ~ /setblock 91 74 -274 lever 11

#remove indicator
clone 367 1 -434 374 15 -441 78 140 -265 replace force

#fix message
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.stormfix.subtitle"}]}
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a


#turn off solution check
execute @e[tag=storm_zone_math,scores={zone1loaded=2, storm_active=1}] ~ ~ ~ /setblock 348 1 -472 air

#stop this block
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1}] ~ ~ ~ /setblock 348 1 -469 air

#stop ticking area
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1}] ~ ~ ~ /tickingarea remove stormzone

#remove this from total disaster count
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1}] ~ ~ ~ /setblock 348 1 -466 redstone_block

#reset zone 1 loaded 
execute @e[tag=storm_zone_math,scores={zone1loaded=2,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] zone1loaded 0

#mark storm inactive
execute @e[tag=storm_zone_math,scores={zone1loaded=0,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] storm_active 0
execute @e[tag=storm_zone_math,scores={zone1loaded=0,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] storm_active 0

#remove entity from the map
kill @e[tag=dis_storm]