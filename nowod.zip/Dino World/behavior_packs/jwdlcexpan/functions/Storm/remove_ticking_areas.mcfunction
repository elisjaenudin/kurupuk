tickingarea remove stormzone

#turn off this block
setblock 348 1 -466 air