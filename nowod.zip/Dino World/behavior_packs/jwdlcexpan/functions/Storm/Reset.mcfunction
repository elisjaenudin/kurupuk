#reset function
#say storm reset

#suppress the messaging for fixing disasters
scoreboard players set @e[tag=storm_zone_math] no_fix_msg 1

#trigger series of delayed command blocks to undo the disasters in a staged order
setblock 348 1 -469 redstone_block
setblock 348 1 -463 redstone_block
