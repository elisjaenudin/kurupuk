#reset function
scoreboard players set @e[tag=storm_zone_math] storm_time 0
scoreboard players set @e[tag=storm_zone_math] storm_active 0
scoreboard players set @e[tag=storm_zone_math] zonePicked 0

#un-suppress the messaging for fixing disasters
scoreboard players set @e[tag=storm_zone_math] no_fix_msg 0

#turn this off
setblock 348 1 -463 air