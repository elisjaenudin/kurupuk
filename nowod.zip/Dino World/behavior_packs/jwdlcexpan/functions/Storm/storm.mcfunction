#debug 
#execute @e[tag=storm_zone_math,scores={debug=1}] ~ ~ ~ /say Storm!

#prevent redstone retriggering zone selection
execute @e[tag=storm_zone_math,scores={storm_active=0}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=storm_zone_math,scores={zone1loaded=0,storm_active=0}] ~ ~ ~ /setblock 348 1 -479 air

#===start the storm===
execute @e[tag=storm_zone_math,scores={zone1loaded=0,storm_active=0}] ~ ~ ~ detect 91 72 -274 concrete 7 /function Storm/spawn_storm
#====================

#message Storm Disaster
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.stormevent.chat"}]}

#start check for solution
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=0}] ~ ~ ~ /setblock 348 1 -472 redstone_block

#stop this block
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=0}] ~ ~ ~ /setblock 348 1 -476 air

#----------------turn off ticking area
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=0}] ~ ~ ~ /tickingarea remove stormzone

#add this to total disaster count
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=0}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] storm_active 1
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=0}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] storm_active 1

#reset zone1loaded
execute @e[tag=storm_zone_math,scores={zone1loaded=1,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] zone1loaded 0