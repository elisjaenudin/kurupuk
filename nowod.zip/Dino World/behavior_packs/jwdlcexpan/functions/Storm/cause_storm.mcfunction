#create the ticking zone
tickingarea add circle 91 73 -274 1 stormzone

#turn off the block for storm
setblock 348 1 -479 air

#activate the redstone block for causing storm
setblock 348 1 -476 redstone_block

#reset zone1loaded
scoreboard players set @e[tag=storm_zone_math] zone1loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=storm_zone_math] zonePicked 1

#add entity from the map
summon jw:disaster 346.3 57 -441
execute @e[type=jw:disaster,x=346.3,y=57,z=-441,r=1] 346.3 57 -441 tag @s add dis_storm

#add indicator
clone 365 1 -425 372 15 -432 78 140 -265 replace force

#play disaster sound
playsound stinger.disaster.01 @a