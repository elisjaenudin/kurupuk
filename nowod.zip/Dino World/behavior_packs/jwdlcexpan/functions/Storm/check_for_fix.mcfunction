
#----------check for lever being flipped
#turn on fix if lever has been turned back on
execute @e[tag=storm_zone_math] ~ ~ ~ detect 91 74 -274 lever 11 /setblock 348 1 -469 redstone_block

scoreboard players remove @e[tag=storm_zone_math,scores={storm_time=0..}] storm_time 1
execute @e[tag=storm_zone_math,scores={storm_time=0}] ~ ~ ~ /weather thunder 1000000