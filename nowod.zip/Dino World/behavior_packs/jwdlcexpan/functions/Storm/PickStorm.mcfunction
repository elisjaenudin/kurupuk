#debug
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Storm


#otherwise if the storm is not active, then start it
execute @e[tag=storm_zone_math,scores={storm_active=0,zonePicked=0}] ~ ~ ~ /function Storm/cause_storm


#if storm is already active, call a different disaster
execute @e[tag=storm_zone_math,scores={storm_active=1,zonePicked=0}] ~ ~ ~ /function Storm/CheckActive