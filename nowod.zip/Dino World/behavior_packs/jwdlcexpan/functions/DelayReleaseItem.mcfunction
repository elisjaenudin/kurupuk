setblock 360 1 -483 air

give @a spawn_egg 1 46