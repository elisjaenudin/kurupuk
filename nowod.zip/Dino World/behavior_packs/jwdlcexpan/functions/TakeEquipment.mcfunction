#===========Take Equipment===============

clear @a jw:wrench 0 1
clear @a crossbow 0 1
clear @a arrow 0 64
clear @a diamond_sword 0 1
clear @a spawn_egg 34 1