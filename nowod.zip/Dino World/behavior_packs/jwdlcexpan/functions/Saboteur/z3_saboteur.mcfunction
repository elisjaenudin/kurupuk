#debug
#execute @e[tag=sabo_zone_math,scores={debug=1}] ~ ~ ~ /say Listen all y'all, it's a Zone 3 Sabotage!

#prevent redstone retriggering zone selection
execute @e[tag=sabo_zone_math,scores={z3_sabo_active=0}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=sabo_zone_math,scores={zone3loaded=0,z3_sabo_active=0}] ~ ~ ~ /setblock 364 1 -479 air

#===set one loose===
execute @e[tag=sabo_zone_math,scores={zone3loaded=0,z3_sabo_active=0}] ~ ~ ~ detect 680 34 -812 prismarine 1 /function Saboteur/spawn/Zone3_saboteurs
#===================

#message sector 3 disaster
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.sabo3event.chat"}]}

#start check for solution
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=0}] ~ ~ ~ /setblock 364 1 -448 redstone_block

#stop this block
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=0}] ~ ~ ~ /setblock 364 1 -451 air

#----------------turn off ticking area
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=0}] ~ ~ ~ /tickingarea remove sabozone3

#add this to total disaster count
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=0}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] z3_sabo_active 1	

#reset zone3loaded
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zone3loaded 0