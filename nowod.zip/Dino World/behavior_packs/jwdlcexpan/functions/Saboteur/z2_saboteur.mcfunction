#debug
#execute @e[tag=sabo_zone_math,scores={debug=1}] ~ ~ ~ /say Listen all y'all, it's a Zone 2 Sabotage!

#prevent redstone retriggering zone selection
execute @e[tag=sabo_zone_math,scores={z2_sabo_active=0}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=sabo_zone_math,scores={zone2loaded=0,z2_sabo_active=0}] ~ ~ ~ /setblock 364 1 -479 air

#===set one loose===
execute @e[tag=sabo_zone_math,scores={zone2loaded=0,z2_sabo_active=0}] ~ ~ ~ detect 37 12 -4 sand 0 /function Saboteur/spawn/Zone2_saboteurs
#===================

#message sector 2 disaster
execute @e[tag=sabo_zone_math,scores={zone2loaded=1,z2_sabo_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.sabo2event.chat"}]}

#start check for solution
execute @e[tag=sabo_zone_math,scores={zone2loaded=1,z2_sabo_active=0}] ~ ~ ~ /setblock 364 1 -460 redstone_block

#stop this block
execute @e[tag=sabo_zone_math,scores={zone2loaded=1,z2_sabo_active=0}] ~ ~ ~ /setblock 364 1 -463 air

#----------------turn off ticking area
execute @e[tag=sabo_zone_math,scores={zone2loaded=1,z2_sabo_active=0}] ~ ~ ~ /tickingarea remove sabozone2

#add this to total disaster count
execute @e[tag=sabo_zone_math,scores={zone2loaded=1,z2_sabo_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=sabo_zone_math,scores={zone2loaded=1,z2_sabo_active=0}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] z2_sabo_active 1	

#reset zone2loaded
execute @e[tag=sabo_zone_math,scores={zone2loaded=1,z2_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zone2loaded 0