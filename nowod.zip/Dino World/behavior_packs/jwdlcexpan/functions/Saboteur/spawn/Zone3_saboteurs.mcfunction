#=========================== Zone 3 saboteur escape =================

#saboteur spawn
summon jurassic_world:saboteur 680 35 -812
execute @e[type=jurassic_world:saboteur,x=680,y=35,z=-812,r=2] 680 35 -812 tag @e[type=jurassic_world:saboteur] add zone3_saboteur
summon jurassic_world:saboteur 665 35 -798
execute @e[type=jurassic_world:saboteur,x=665,y=35,z=-798,r=2] 665 35 -798 tag @e[type=jurassic_world:saboteur] add zone3_saboteur
summon jurassic_world:saboteur 687 35 -796
execute @e[type=jurassic_world:saboteur,x=687,y=35,z=-796,r=2] 687 35 -796 tag @e[type=jurassic_world:saboteur] add zone3_saboteur
summon jurassic_world:saboteur 677 35 -821
execute @e[type=jurassic_world:saboteur,x=677,y=35,z=-821,r=2] 677 35 -821 tag @e[type=jurassic_world:saboteur] add zone3_saboteur

#add entity from the map
summon jw:disaster 351 61.4 -441
execute @e[type=jw:disaster,x=351,y=61.4,z=-441,r=1] 351 61.4 -441 tag @s add dis_sab_z3

scoreboard players set @e[tag=sabo_zone_math] z3_sabos_left 4

scoreboard players set @e[tag=sabo_zone_math] zone3loaded 1