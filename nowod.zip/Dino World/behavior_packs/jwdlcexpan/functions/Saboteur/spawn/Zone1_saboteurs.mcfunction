#=========================== Zone 1 saboteur escape =================

#saboteur spawn
summon jurassic_world:saboteur 646 14 27
execute @e[type=jurassic_world:saboteur,x=646,y=14,z=27,r=2] 646 14 27 tag @e[type=jurassic_world:saboteur] add zone1_saboteur
summon jurassic_world:saboteur 639 14 17
execute @e[type=jurassic_world:saboteur,x=639,y=14,z=17,r=2] 639 14 17 tag @e[type=jurassic_world:saboteur] add zone1_saboteur
summon jurassic_world:saboteur 655 14 26
execute @e[type=jurassic_world:saboteur,x=655,y=14,z=26,r=2] 655 14 26 tag @e[type=jurassic_world:saboteur] add zone1_saboteur
summon jurassic_world:saboteur 636 14 3
execute @e[type=jurassic_world:saboteur,x=636,y=14,z=3,r=2] 636 14 3 tag @e[type=jurassic_world:saboteur] add zone1_saboteur

#add entity from the map
summon jw:disaster 350 55 -441
execute @e[type=jw:disaster,x=350,y=55,z=-441,r=1] 350 55 -441 tag @s add dis_sab_z1

scoreboard players set @e[tag=sabo_zone_math] z1_sabos_left 4

scoreboard players set @e[tag=sabo_zone_math] zone1loaded 1