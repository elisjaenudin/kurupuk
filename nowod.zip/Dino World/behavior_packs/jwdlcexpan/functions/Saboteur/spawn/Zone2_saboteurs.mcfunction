#=========================== Zone 2 saboteur escape =================

#saboteur spawn
summon jurassic_world:saboteur 37 13 -4
execute @e[type=jurassic_world:saboteur,x=37,y=13,z=-4,r=2] 37 13 -4 tag @e[type=jurassic_world:saboteur] add zone2_saboteur
summon jurassic_world:saboteur 40 13 -17
execute @e[type=jurassic_world:saboteur,x=40,y=13,z=-17,r=2] 40 13 -17 tag @e[type=jurassic_world:saboteur] add zone2_saboteur
summon jurassic_world:saboteur 50 13 -10
execute @e[type=jurassic_world:saboteur,x=50,y=13,z=-10,r=2] 50 13 -10 tag @e[type=jurassic_world:saboteur] add zone2_saboteur
summon jurassic_world:saboteur 44 13 2
execute @e[type=jurassic_world:saboteur,x=44,y=13,z=2,r=2] 44 13 2 tag @e[type=jurassic_world:saboteur] add zone2_saboteur

#add entity from the map
summon jw:disaster 345 55 -441
execute @e[type=jw:disaster,x=345,y=55,z=-441,r=1] 345 55 -441 tag @s add dis_sab_z2

scoreboard players set @e[tag=sabo_zone_math] z2_sabos_left 4

scoreboard players set @e[tag=sabo_zone_math] zone2loaded 1