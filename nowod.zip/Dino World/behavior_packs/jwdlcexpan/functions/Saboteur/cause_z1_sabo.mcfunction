#create the ticking zone
tickingarea add circle 646 14 27 4 sabozone1

#turn off block for finding saboteur zone to happen
setblock 364 1 -479 air

#activate the redstone block for spawning saboteurs
setblock 364 1 -476 redstone_block

#reset zone1loaded
scoreboard players set @e[tag=sabo_zone_math] zone1loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=sabo_zone_math] zonePicked 1

#add indicator
clone 365 1 -425 372 15 -432 638 140 13 replace force

#play disaster sound
playsound stinger.disaster.01 @a