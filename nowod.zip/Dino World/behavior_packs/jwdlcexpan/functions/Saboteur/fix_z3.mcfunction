#===Fix it===
#if we aren't active, turn off the redstone block for this command block
execute @e[tag=sabo_zone_math,scores={z3_sabo_active=0}] ~ ~ ~ /setblock 364 1 -445 air

#turn off reset block
execute @e[tag=sabo_zone_math,scores={z3_sabo_active=0}] ~ ~ ~ /setblock 362 1 -445 air

#turn off solution check
execute @e[tag=sabo_zone_math,scores={z3_sabo_active=0}] ~ ~ ~ /setblock 364 1 -448 air
#-------------------------------------------end inactive precautions ----------------------------

#create ticking zone for zone 1
execute @e[tag=sabo_zone_math,scores={zone3loaded=0,z3_sabo_active=1}] ~ ~ ~ /tickingarea add circle 680 35 -812 4 sabozone3
execute @e[tag=sabo_zone_math,scores={zone3loaded=0,z3_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zone3loaded 1

#get rid of saboteurs
execute @e[tag=sabo_zone_math,scores={zone3loaded=1,z3_sabo_active=1}] ~ ~ ~ detect 680 34 -812 prismarine 1 /scoreboard players set @e[tag=sabo_zone_math] zone3loaded 2
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /tp @e[tag=zone3_saboteur] 403 2 -479
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /kill @e[tag=zone3_saboteur]

#remove indicator
clone 367 1 -434 374 15 -441 675 140 -815 replace force

#fix message
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.sabo3fix.subtitle"}]}
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a


#turn off solution check
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /setblock 364 1 -448 air

#stop this block
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /setblock 364 1 -445 air

#stop reset block
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /setblock 362 1 -445 air

#stop ticking area
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /tickingarea remove sabozone3

#remove this from total disaster count
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /setblock 364 1 -442 redstone_block

#reset zone3loaded
execute @e[tag=sabo_zone_math,scores={zone3loaded=2,z3_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zone3loaded 0

#mark z2 inactive
execute @e[tag=sabo_zone_math,scores={zone3loaded=0,z3_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] z3_sabo_active 0

#remove entity from the map
kill @e[tag=dis_sab_z3]