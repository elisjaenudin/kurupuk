#===Fix it===
#if we aren't active, turn off the redstone block for this command block (which is also the reset block in this case)
execute @e[tag=sabo_zone_math,scores={z1_sabo_active=0}] ~ ~ ~ /setblock 364 1 -469 air

#turn off solution check
execute @e[tag=sabo_zone_math,scores={z1_sabo_active=0}] ~ ~ ~ /setblock 364 1 -472 air
#-------------------------------------------end inactive precautions ----------------------------

#create ticking zone for zone 1
execute @e[tag=sabo_zone_math,scores={zone1loaded=0,z1_sabo_active=1}] ~ ~ ~ /tickingarea add circle 646 14 27 4 sabozone1
execute @e[tag=sabo_zone_math,scores={zone1loaded=0,z1_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zone1loaded 1

#get rid of saboteurs
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=1}] ~ ~ ~ detect 646 13 27 stone 3 /scoreboard players set @e[tag=sabo_zone_math] zone1loaded 2
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /tp @e[tag=zone1_saboteur] 403 2 -479
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /kill @e[tag=zone1_saboteur]

#remove indicator
clone 367 1 -434 374 15 -441 638 140 13 replace force

#fix message
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.sabo1fix.subtitle"}]}
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a


#turn off solution check
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /setblock 364 1 -472 air

#stop this block
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /setblock 364 1 -469 air

#stop ticking area
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /tickingarea remove sabozone1

#remove this from total disaster count
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /setblock 364 1 -466 redstone_block

#reset zone1loaded
execute @e[tag=sabo_zone_math,scores={zone1loaded=2,z1_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zone1loaded 0

#mark z1 inactive
execute @e[tag=sabo_zone_math,scores={zone1loaded=0,z1_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] z1_sabo_active 0

#remove entity from the map
kill @e[tag=dis_sab_z1]