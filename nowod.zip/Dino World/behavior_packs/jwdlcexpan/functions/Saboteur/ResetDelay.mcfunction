#reset function
scoreboard players set @e[tag=sabo_zone_math] z1_sabo_active 0
scoreboard players set @e[tag=sabo_zone_math] z2_sabo_active 0
scoreboard players set @e[tag=sabo_zone_math] z3_sabo_active 0
scoreboard players set @e[tag=sabo_zone_math] zonePicked 0
scoreboard players set @e[tag=sabo_zone_math] zone_random 0
scoreboard players set @e[tag=sabo_zone_math] z1_sabos_left 0
scoreboard players set @e[tag=sabo_zone_math] z2_sabos_left 0
scoreboard players set @e[tag=sabo_zone_math] z3_sabos_left 0
#un-suppress the messaging for fixing disasters
scoreboard players set @e[tag=sabo_zone_math] no_fix_msg 0

#turn this off
setblock 362 1 -442 air