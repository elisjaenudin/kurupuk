tickingarea remove sabozone3

#turn off this block
setblock 364 1 -442 air