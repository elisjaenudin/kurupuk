#Rogue Dinosaur Setup
scoreboard objectives add z1_sabo_active dummy
scoreboard objectives add z2_sabo_active dummy
scoreboard objectives add z3_sabo_active dummy
scoreboard objectives add z1_sabos_left dummy
scoreboard objectives add z2_sabos_left dummy
scoreboard objectives add z3_sabos_left dummy

scoreboard players set @e[tag=sabo_zone_math] z1_sabo_active 0

scoreboard players set @e[tag=sabo_zone_math] z2_sabo_active 0

scoreboard players set @e[tag=sabo_zone_math] z3_sabo_active 0

scoreboard players set @e[tag=sabo_zone_math] zonePicked 0

scoreboard players set @e[tag=sabo_zone_math] zone_random 0

scoreboard players set @e[tag=sabo_zone_math] zone1loaded 0
scoreboard players set @e[tag=sabo_zone_math] zone2loaded 0
scoreboard players set @e[tag=sabo_zone_math] zone3loaded 0

scoreboard players set @e[tag=sabo_zone_math] z1_sabos_left 0
scoreboard players set @e[tag=sabo_zone_math] z2_sabos_left 0
scoreboard players set @e[tag=sabo_zone_math] z3_sabos_left 0


scoreboard players set @e[tag=sabo_zone_math] no_fix_msg 0
