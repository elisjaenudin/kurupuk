#debug
#execute @e[tag=sabo_zone_math,scores={debug=1}] ~ ~ ~ /say Listen all y'all, it's a Zone 1 Sabotage!

#prevent redstone retriggering zone selection
execute @e[tag=sabo_zone_math,scores={z1_sabo_active=0}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=sabo_zone_math,scores={zone1loaded=0,z1_sabo_active=0}] ~ ~ ~ /setblock 364 1 -479 air

#===set one loose===
execute @e[tag=sabo_zone_math,scores={zone1loaded=0,z1_sabo_active=0}] ~ ~ ~ detect 646 13 27 stone 3 /function Saboteur/spawn/Zone1_saboteurs
#===================

#message sector 1 disaster
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.sabo1event.chat"}]}

#start check for solution
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=0}] ~ ~ ~ /setblock 364 1 -472 redstone_block

#stop this block
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=0}] ~ ~ ~ /setblock 364 1 -476 air

#----------------turn off ticking area
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=0}] ~ ~ ~ /tickingarea remove sabozone1

#add this to total disaster count
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=0}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] z1_sabo_active 1	

#reset zone1loaded
execute @e[tag=sabo_zone_math,scores={zone1loaded=1,z1_sabo_active=1}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zone1loaded 0