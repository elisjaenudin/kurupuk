#reset function
#say saboteur reset

#suppress the messaging for fixing disasters
scoreboard players set @e[tag=sabo_zone_math] no_fix_msg 1

#trigger series of delayed command blocks to undo the disasters in a staged order
setblock 364 1 -469 redstone_block
setblock 362 1 -457 redstone_block
setblock 362 1 -445 redstone_block
setblock 362 1 -442 redstone_block
