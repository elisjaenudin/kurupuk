#execute @e[tag=sabo_zone_math] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] fixedCheck 0

#execute @e[tag=zone1_saboteur,x=403,y=1,z=-479,r=10] ~ ~ ~ /scoreboard players add @e[tag=sabo_zone_math] fixedCheck 1

execute @e[tag=sabo_zone_math,scores={z1_sabos_left=0}] ~ ~ ~ /setblock 364 1 -469 redstone_block