#debug
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Park is being sabotaged!

#loop if zones arent full, until we choose a zone thats not populated
scoreboard players random @e[tag=sabo_zone_math] zone_random 1 3

#===zone1===
#if zone 1 chosen and not already active
execute @e[tag=sabo_zone_math,scores={zone_random=1..1,z1_sabo_active=0,zonePicked=0}] ~ ~ ~ /function Saboteur/cause_z1_sabo


#===zone2===
#if zone 2 chosen and not already active
execute @e[tag=sabo_zone_math,scores={zone_random=2..2,z2_sabo_active=0,zonePicked=0}] ~ ~ ~ /function Saboteur/cause_z2_sabo


#===zone3===
#if zone 3 chosen and not already active
execute @e[tag=sabo_zone_math,scores={zone_random=3..3,z3_sabo_active=0,zonePicked=0}] ~ ~ ~ /function Saboteur/cause_z3_sabo



#=======================================================
#check if all zones are active, and if they are, call a different disaster
execute @e[tag=sabo_zone_math,scores={z1_sabo_active=1,z2_sabo_active=1,z3_sabo_active=1,zonePicked=0}] ~ ~ ~ /function Saboteur/CheckActive