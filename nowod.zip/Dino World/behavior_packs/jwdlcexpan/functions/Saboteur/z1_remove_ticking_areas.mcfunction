tickingarea remove sabozone1

#turn off this block
setblock 364 1 -466 air