tickingarea remove sabozone2

#turn off this block
setblock 364 1 -454 air