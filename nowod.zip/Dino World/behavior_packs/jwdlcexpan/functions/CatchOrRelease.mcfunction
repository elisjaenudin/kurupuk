scoreboard players operation @e[tag=disaster_system] dinocheck = @e[tag=disaster_system] dinocaught

#execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /say capture
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /function CaptureDino

#already 1, so we didn't just capture the dino with the previous line, so release the dino instead
#execute @e[tag=disaster_system,scores={dinocaught=1,dinocheck=1}] ~ ~ ~ /say release
execute @e[tag=disaster_system,scores={dinocaught=1,dinocheck=1}] ~ ~ ~ /function ReleaseDino

tp @s ~ 2 ~
kill @s
clear @a spawn_egg 34
give @a spawn_egg 1 34