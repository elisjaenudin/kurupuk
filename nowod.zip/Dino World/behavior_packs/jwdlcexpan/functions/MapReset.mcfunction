#disasters remove themselves from count, so no need to run it here
#scoreboard players set @e[tag=disaster_system] disaster_count 1


function ParkReset
function tp/MonorailReset
function ColdStorage/Reset
function EggRoom/Reset
function Lecturn/Reset
function tp/InitialSpawn

setblock 351 1 -483 redstone_block