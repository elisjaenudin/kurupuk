#Disaster countdown loop

#choose new countdown time/reset

#-----------------------------------------------------------------------------------------
#after between 30 seconds and 10 minutes, the time between disasters is 3 minutes

#no storm active
execute @e[tag=disaster_system,scores={total_open_secs=30..600,countdown=..0,storm_active=0}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 180
#storm active, make cooldown 33% faster
execute @e[tag=disaster_system,scores={total_open_secs=30..600,countdown=..0,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 120

#-----------------------------------------------------------------------------------------
#between 10 seconds and 15 minutes, the time between disasters 2 minutes

#no storm active
execute @e[tag=disaster_system,scores={total_open_secs=601..900,countdown=..0,storm_active=0}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 120
#storm active, make cooldown 33% faster
execute @e[tag=disaster_system,scores={total_open_secs=601..900,countdown=..0,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 80

#-----------------------------------------------------------------------------------------
#between 15 and  30 minutes, the time between disasters is 1 minutes

#no storm active
execute @e[tag=disaster_system,scores={total_open_secs=901..1800,countdown=..0,storm_active=0}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 60
#storm active, make cooldown 33% faster
execute @e[tag=disaster_system,scores={total_open_secs=901..1800,countdown=..0,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 40

#-----------------------------------------------------------------------------------------
#after 30 minutes, the time between disasters is 30 seconds 

#no storm active
execute @e[tag=disaster_system,scores={total_open_secs=1801..,countdown=..0,storm_active=0}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 30
#storm active, make cooldown 33% faster
execute @e[tag=disaster_system,scores={total_open_secs=1801..,countdown=..0,storm_active=1}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] countdown 20

#-----------------------------------------------------------------------------------------

#increment time open, decrement countdown
scoreboard players add @e[tag=disaster_system,scores={park_open=1}] time_open_secs 1
scoreboard players add @e[tag=disaster_system,scores={park_open=1}] total_open_secs 1

execute @e[tag=disaster_system,scores={time_open_secs=60}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] time_open_mins 1
execute @e[tag=disaster_system,scores={time_open_secs=60}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] time_open_secs 0

execute @e[tag=disaster_system,scores={time_open_mins=60}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] time_open_hrs 1
execute @e[tag=disaster_system,scores={time_open_mins=60}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] time_open_mins 0

scoreboard players remove @e[tag=disaster_system,scores={park_open=1}] countdown 1

#find which tier we are in and pick a disaster from it
execute @e[tag=disaster_system,scores={countdown=..0,park_open=1}] ~ ~ ~ /function FindTier
