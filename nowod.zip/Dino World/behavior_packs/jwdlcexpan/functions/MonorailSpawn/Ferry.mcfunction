#===========Spawn Monorail Ferry===============

kill @e[type=minecart,x=0,y=33,z=37,r=1]
kill @e[type=item,x=0,y=33,z=37,r=1]
summon minecart 0 33 37