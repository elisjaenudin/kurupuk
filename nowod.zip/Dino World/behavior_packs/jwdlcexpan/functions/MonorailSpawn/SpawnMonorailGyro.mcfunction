#===========Spawn Monorail Gyro===============

summon minecart 139 55 -619