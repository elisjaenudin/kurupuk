#===========Spawn Monorail Gallimimus===============

summon minecart 507 58 -624