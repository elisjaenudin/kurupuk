#===========Spawn Monorail Mosasaurus===============

summon minecart 288 58 -184