#===========Brewing Stand Refuel===============

clone 399 6 -419 399 6 -419 376 52 -413 replace force
replaceitem block 382 52 -419 slot.container 4 blaze_powder 64
replaceitem block 383 52 -419 slot.container 4 blaze_powder 64