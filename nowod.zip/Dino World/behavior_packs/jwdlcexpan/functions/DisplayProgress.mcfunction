# Show the player progress toward getting the samples in the island, jungle mines, and desert site
#say DEBUG display progress

execute @a[tag=inIsland,scores={islandSamples=0}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"0 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=1}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"1 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=2}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"2 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=3}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"3 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=4}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"4 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=5}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"5 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=6}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"6 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"0 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"1 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=2}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"2 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=3}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"3 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=4}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"4 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=5}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"5 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=6}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"6 / 6"},{"translate":"jw.progress.island_samples"}]}
execute @a[tag=inIsland,scores={islandSamples=6}] ~ ~ ~ /setblock 344 8 -420 redstone_block
execute @a[tag=inIsland,scores={islandSamples=6}] ~ ~ ~ /scoreboard players add @a islandSamples 1

execute @a[tag=inJungle,scores={jungleSamples=0}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"0 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=1}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"1 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=2}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"2 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=3}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"3 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=4}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"4 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=5}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"5 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"0 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"1 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=2}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"2 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=3}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"3 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=4}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"4 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=5}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"5 / 5"},{"translate":"jw.progress.jungle_samples"}]}
execute @a[tag=inJungle,scores={jungleSamples=5}] ~ ~ ~ /setblock 344 8 -420 redstone_block
execute @a[tag=inJungle,scores={jungleSamples=5}] ~ ~ ~ /scoreboard players add @a jungleSamples 1

execute @a[tag=inDesert,scores={desertSamples=0}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"0 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=1}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"1 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=2}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"2 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=3}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"3 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=4}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"4 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=5}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"5 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"0 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"1 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=2}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"2 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=3}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"3 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=4}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"4 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=5}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"5 / 5"},{"translate":"jw.progress.desert_samples"}]}
execute @a[tag=inDesert,scores={desertSamples=5}] ~ ~ ~ /setblock 344 8 -420 redstone_block
execute @a[tag=inDesert,scores={desertSamples=5}] ~ ~ ~ /scoreboard players add @a desertSamples 1

execute @e[tag=disaster_system] ~ ~ ~ detect 342 55 -432 lever 5 /fill 344 8 -424 344 8 -424 redstone_block 0 replace air