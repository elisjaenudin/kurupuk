#-----QBE Quickbuild Refill-----

clone 342 8 -424 342 8 -424 208 43 -370
clone 342 8 -426 342 8 -426 208 43 -372
execute @a[scores={quickbuild=9}] ~ ~ ~ /clone 342 9 -426 342 9 -426 208 43 -372

say Supplies Refilled