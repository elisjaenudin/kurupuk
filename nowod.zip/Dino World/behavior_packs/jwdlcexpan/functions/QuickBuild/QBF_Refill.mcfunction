#-----QBF Quickbuild Refill-----

clone 342 10 -424 342 10 -424 294 48 -299
clone 342 10 -426 342 10 -426 296 48 -299
execute @a[scores={quickbuild=9}] ~ ~ ~ /clone 342 11 -426 342 11 -426 296 48 -299

say Supplies Refilled