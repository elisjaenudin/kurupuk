scoreboard objectives add state dummy
scoreboard objectives add querying_step dummy
scoreboard objectives add warning dummy
scoreboard objectives add warned dummy
scoreboard objectives add option dummy
scoreboard objectives add lastoption dummy

scoreboard players set @e[tag=qb1_system] state 1
scoreboard players set @e[tag=qb1_system] option 0
scoreboard players set @e[tag=qb1_system] warned 0
scoreboard players set @e[tag=qb1_system] querying_step 0
scoreboard players set @e[tag=qb1_system] warning 0



