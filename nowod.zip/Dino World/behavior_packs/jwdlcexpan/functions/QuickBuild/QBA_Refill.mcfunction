#-----QBA Quickbuild Refill-----

clone 342 10 -424 342 10 -424 622 53 -138
clone 342 10 -426 342 10 -426 624 53 -138
execute @a[scores={quickbuild=9}] ~ ~ ~ /clone 342 11 -426 342 11 -426 624 53 -138

say Supplies Refilled
