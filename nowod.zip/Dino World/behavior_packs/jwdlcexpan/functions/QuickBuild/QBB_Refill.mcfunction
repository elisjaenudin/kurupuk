#-----QBB Quickbuild Refill-----

clone 342 14 -424 342 14 -424 472 48 -277
clone 342 14 -426 342 14 -426 470 48 -277
execute @a[scores={quickbuild=9}] ~ ~ ~ /clone 342 15 -426 342 15 -426 470 48 -277

say Supplies Refilled