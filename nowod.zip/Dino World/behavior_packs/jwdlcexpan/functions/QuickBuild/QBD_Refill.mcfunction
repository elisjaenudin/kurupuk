#-----QBD Quickbuild Refill-----

clone 342 14 -424 342 14 -424 326 53 -604
clone 342 14 -426 342 14 -426 324 53 -604
execute @a[scores={quickbuild=9}] ~ ~ ~ /clone 342 15 -426 342 15 -426 324 53 -604

say Supplies Refilled