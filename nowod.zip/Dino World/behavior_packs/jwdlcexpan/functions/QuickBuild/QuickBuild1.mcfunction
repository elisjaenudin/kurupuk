
#check for dinosuars
scoreboard players set @e[tag=qb1_system] warning 0
execute @e[type=cow,x=-7,y=4,z=-5,dx=7,dy=10,dz=10] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] warning 1
#give warning instead
#execute @e[tag=qb1_system,scores={warning=1,querying_step=1}] ~ ~ ~ /say All dinosaurs must be relocated before remodeling can begin.
#execute @e[tag=qb1_system,scores={warning=1,querying_step=1}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 0


#store last ticks option
scoreboard players operation @e[tag=qb1_system] lastoption = @e[tag=qb1_system] option

#======================custom=====================================
# custom button hit

#===step0===
#is button pressed?
execute @e[tag=qb1_system,scores={state=!1}] ~ ~ ~ detect 1 5 1 stone_button 13 /scoreboard players set @e[tag=qb1_system] option 1

#pressed this frame, and already querying for a state, and our previous state was not the same, reset querying step
execute @e[tag=qb1_system,scores={option=1,lastoption=!1,querying_step=1..}] ~ ~ ~ /setblock 1 4 0 air
execute @e[tag=qb1_system,scores={option=1,lastoption=!1,querying_step=1..}] ~ ~ ~ /setblock 1 4 -1 air
execute @e[tag=qb1_system,scores={option=1,lastoption=!1,querying_step=1..}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 0


execute @e[tag=qb1_system,scores={option=1,warning=1,warned=20}] ~ ~ ~ /say All dinosaurs must be relocated before remodeling can begin.
execute @e[tag=qb1_system,scores={option=1,warning=1,warned=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] option 0

execute @e[tag=qb1_system,scores={option=1,querying_step=0,warning=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 1

#===step1===
#output warning message
execute @e[tag=qb1_system,scores={option=1,querying_step=1,warning=0}] ~ ~ ~ /say Load custom build? Press the red button to confirm.

#copy in overwrite button
execute @e[tag=qb1_system,scores={option=1,querying_step=1,warning=0}] ~ ~ ~ /setblock 1 4 1 acacia_button 5
execute @e[tag=qb1_system,scores={option=1,querying_step=1,warning=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 2

#===step 2===
#check for overwrite button pressed
execute @e[tag=qb1_system,scores={option=1,querying_step=2}] ~ ~ ~ detect 1 4 1 acacia_button 13 /scoreboard players set @e[tag=qb1_system] querying_step 3

#===step 3===
#copy in custom area
execute @e[tag=qb1_system,scores={option=1,querying_step=3}] ~ ~ ~ /clone -15 4 17 -20 20 9 -6 4 -4 replace
	
#remove acacia button
execute @e[tag=qb1_system,scores={option=1,querying_step=3}] ~ ~ ~ /setblock 1 4 1 air

#remove custom button
execute @e[tag=qb1_system,scores={option=1,querying_step=3}] ~ ~ ~ /setblock 1 5 1 air

#make sure other buttons are available
execute @e[tag=qb1_system,scores={option=1,querying_step=3}] ~ ~ ~ /setblock 1 5 0 stone_button 5
execute @e[tag=qb1_system,scores={option=1,querying_step=3}] ~ ~ ~ /setblock 1 5 -1 stone_button 5

#set state to custom
execute @e[tag=qb1_system,scores={option=1,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] state 1

#reset option
execute @e[tag=qb1_system,scores={state=1,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] option 0

#reset querying_step
execute @e[tag=qb1_system,scores={state=1,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 0
#======================

#================= Option 2===================================
#===step0===
#is button pressed?
#set option to 2 and advance query step
execute @e[tag=qb1_system,scores={state=!2}] ~ ~ ~ detect 1 5 0 stone_button 13 /scoreboard players set @e[tag=qb1_system] option 2

#pressed this frame, and already querying for a state, and our previous state was not the same, reset querying step
execute @e[tag=qb1_system,scores={option=2,lastoption=!2,querying_step=1..}] ~ ~ ~ /setblock 1 4 1 air
execute @e[tag=qb1_system,scores={option=2,lastoption=!2,querying_step=1..}] ~ ~ ~ /setblock 1 4 -1 air
execute @e[tag=qb1_system,scores={option=2,lastoption=!2,querying_step=1..}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 0


execute @e[tag=qb1_system,scores={option=2,warning=1,warned=20}] ~ ~ ~ /say All dinosaurs must be relocated before remodeling can begin.
execute @e[tag=qb1_system,scores={option=2,warning=1,warned=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] option 0

execute @e[tag=qb1_system,scores={option=2,querying_step=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 1

#===step1===
#output warning message
execute @e[tag=qb1_system,scores={option=2,querying_step=1,warning=0}] ~ ~ ~ /say Load High Security? Press the red button to confirm.

#copy in overwrite button
execute @e[tag=qb1_system,scores={option=2,querying_step=1,warning=0}] ~ ~ ~ /setblock 1 4 0 acacia_button 5
execute @e[tag=qb1_system,scores={option=2,querying_step=1,warning=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 2

#===step 2===
#check for overwrite button pressed
execute @e[tag=qb1_system,scores={option=2,querying_step=2}] ~ ~ ~ detect 1 4 0 acacia_button 13 /scoreboard players set @e[tag=qb1_system] querying_step 3

#===step 3===
#copy custom build to safety
execute @e[tag=qb1_system,scores={option=2,querying_step=3,state=1}] ~ ~ ~ /clone -1 4 4 -6 13 -4 -20 4 9 replace

#copy in high security area
execute @e[tag=qb1_system,scores={option=2,querying_step=3}] ~ ~ ~ /clone -15 4 -7 -20 20 -15 -6 4 -4 replace
	
#remove acacia button
execute @e[tag=qb1_system,scores={option=2,querying_step=3}] ~ ~ ~ /setblock 1 4 0 air

#remove high security button
execute @e[tag=qb1_system,scores={option=2,querying_step=3}] ~ ~ ~ /setblock 1 5 0 air

#make sure other buttons are available
execute @e[tag=qb1_system,scores={option=2,querying_step=3}] ~ ~ ~ /setblock 1 5 1 stone_button 5
execute @e[tag=qb1_system,scores={option=2,querying_step=3}] ~ ~ ~ /setblock 1 5 -1 stone_button 5

#set state to high security
execute @e[tag=qb1_system,scores={option=2,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] state 2

#reset option
execute @e[tag=qb1_system,scores={state=2,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] option 0

#reset querying_step
execute @e[tag=qb1_system,scores={state=2,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 0
#===============================================================

#====Option 3========================================================
#===step0===
#is button pressed?
#set option to 2 and advance query step
execute @e[tag=qb1_system,scores={state=!3}] ~ ~ ~ detect 1 5 -1 stone_button 13 /scoreboard players set @e[tag=qb1_system] option 3

#pressed this frame, and already querying for a state, and our previous state was not the same, reset querying step
execute @e[tag=qb1_system,scores={option=3,lastoption=!3,querying_step=1..}] ~ ~ ~ /setblock 1 4 1 air
execute @e[tag=qb1_system,scores={option=3,lastoption=!3,querying_step=1..}] ~ ~ ~ /setblock 1 4 0 air
execute @e[tag=qb1_system,scores={option=3,lastoption=!3,querying_step=1..}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 0


execute @e[tag=qb1_system,scores={option=3,warning=1,warned=20}] ~ ~ ~ /say All dinosaurs must be relocated before remodeling can begin.
execute @e[tag=qb1_system,scores={option=3,warning=1,warned=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] option 0

execute @e[tag=qb1_system,scores={option=3,querying_step=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 1

#===step1===
#output warning message
execute @e[tag=qb1_system,scores={option=3,querying_step=1,warning=0}] ~ ~ ~ /say Load Low Security? Press the red button to confirm.

#copy in overwrite button
execute @e[tag=qb1_system,scores={option=3,querying_step=1,warning=0}] ~ ~ ~ /setblock 1 4 -1 acacia_button 5
execute @e[tag=qb1_system,scores={option=3,querying_step=1,warning=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 2

#===step 2===
#check for overwrite button pressed
execute @e[tag=qb1_system,scores={option=3,querying_step=2}] ~ ~ ~ detect 1 4 -1 acacia_button 13 /scoreboard players set @e[tag=qb1_system] querying_step 3

#===step 3===
#copy custom build to safety
execute @e[tag=qb1_system,scores={option=2,querying_step=3,state=1}] ~ ~ ~ /clone -1 4 4 -6 13 -4 -20 4 9 replace

#copy in low security area
execute @e[tag=qb1_system,scores={option=3,querying_step=3}] ~ ~ ~ /clone -15 4 4 -20 20 -4 -6 4 -4 replace
	
#remove acacia button
execute @e[tag=qb1_system,scores={option=3,querying_step=3}] ~ ~ ~ /setblock 1 4 -1 air

#remove low security button
execute @e[tag=qb1_system,scores={option=3,querying_step=3}] ~ ~ ~ /setblock 1 5 -1 air

#make sure other buttons are available
execute @e[tag=qb1_system,scores={option=3,querying_step=3}] ~ ~ ~ /setblock 1 5 0 stone_button 5
execute @e[tag=qb1_system,scores={option=3,querying_step=3}] ~ ~ ~ /setblock 1 5 1 stone_button 5

#set state to low security
execute @e[tag=qb1_system,scores={option=3,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] state 3

#reset option
execute @e[tag=qb1_system,scores={state=3,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] option 0

#reset querying_step
execute @e[tag=qb1_system,scores={state=3,querying_step=3}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] querying_step 0
#===============================================================

execute @e[tag=qb1_system,scores={warning=1,warned=0}] ~ ~ ~ /scoreboard players set @e[tag=qb1_system] warned 20
execute @e[tag=qb1_system,scores={option=!0,warning=1,warned=1..}] ~ ~ ~ /scoreboard players remove @e[tag=qb1_system] warned 1