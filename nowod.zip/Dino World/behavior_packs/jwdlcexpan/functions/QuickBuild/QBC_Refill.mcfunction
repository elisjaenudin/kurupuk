#-----QBC Quickbuild Refill-----

clone 342 12 -424 342 12 -424 721 43 -392
clone 342 12 -426 342 12 -426 721 43 -390
execute @a[scores={quickbuild=9}] ~ ~ ~ /clone 342 13 -426 342 13 -426 721 43 -390

say Supplies Refilled