#-----QBG Quickbuild Refill-----

clone 342 14 -424 342 14 -424 246 43 -226
clone 342 14 -426 342 14 -426 244 43 -226
execute @a[scores={quickbuild=9}] ~ ~ ~ /clone 342 15 -426 342 15 -426 244 43 -226

say Supplies Refilled