#orient Innovation stuff

#Hammond Creation Lab
execute @e[type=jurassic_world:sign_hammond_creation_lab] ~ ~ ~ /tp 390.0 56.3 -391.9

#Hammond Statue

#Innovation Center signs
execute @e[type=jurassic_world:sign_innovation_center] ~ ~ ~ /tp 390.0 57 -348.95