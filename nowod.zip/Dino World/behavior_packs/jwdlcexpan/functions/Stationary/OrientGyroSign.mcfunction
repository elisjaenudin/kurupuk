#orient gyro signs

execute @e[type=jurassic_world:sign_gyrosphere] ~ ~ ~ /tp 145.8 44 -651.25