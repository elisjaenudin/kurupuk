#spawn entrance gate

summon jurassic_world:entrance_gate 260.5 68.5 -139.5