#orient control room signs


execute @e[type=jurassic_world:sign_control_monitor_time_open] ~ ~ ~ /tp 336 63 -442
execute @e[type=jurassic_world:sign_control_monitor_active_disasters] ~ ~ ~ /tp 336 61 -441
execute @e[type=jurassic_world:sign_control_monitor_hype] ~ ~ ~ /tp 336 59 -441 
execute @e[type=jurassic_world:sign_control_monitor_revenue] ~ ~ ~ /tp 336 57 -441
execute @e[type=jurassic_world:sign_control_monitor_high_score] ~ ~ ~ /tp 336 55 -441
execute @e[type=jurassic_world:sign_control_monitor_park_closed] ~ ~ ~ /tp 336 63 -441

