#orient entrance gate

execute @e[type=jurassic_world:entrance_gate] ~ ~ ~ /tp @s ~ ~ ~ 180