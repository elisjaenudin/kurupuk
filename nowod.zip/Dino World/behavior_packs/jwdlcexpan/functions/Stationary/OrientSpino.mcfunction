#orient spino on main street

execute @e[type=jurassic_world:skeleton_spinosaurus] ~ ~ ~ /tp 383 48.5 -323 180