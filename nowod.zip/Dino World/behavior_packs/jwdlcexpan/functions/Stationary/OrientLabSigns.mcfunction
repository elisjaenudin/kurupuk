#orient lab stuff

#stations
execute @e[type=jurassic_world:sign_lab_cold_storage] ~ ~ ~ /tp 371.5 51.5 -413.2 180
execute @e[type=jurassic_world:sign_lab_extraction] ~ ~ ~ /tp 382 51 -420
execute @e[type=jurassic_world:sign_lab_assembly] ~ ~ ~ /tp 385 51 -417 90
execute @e[type=jurassic_world:sign_lab_incubation] ~ ~ ~ /tp 385 51 -407 90
execute @e[type=jurassic_world:sign_lab_hatchery] ~ ~ ~ /tp 372 50.5 -409 270

#Mr. DNA
execute @e[type=jurassic_world:sign_mr_dna_extractor] ~ ~ ~ /tp 383 52 -428.3
execute @e[type=jurassic_world:sign_mr_dna_crafting] ~ ~ ~ /tp 377 52 -428.3
execute @e[type=jurassic_world:sign_mr_dna_incubation] ~ ~ ~ /tp 371 52 -428.3

