execute @a[x=1742, y=64, z=-327, r=4] ~ ~ ~ /spawnpoint @s 1748 63 -319
