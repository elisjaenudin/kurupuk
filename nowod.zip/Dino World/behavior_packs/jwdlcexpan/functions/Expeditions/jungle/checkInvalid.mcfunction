# checks the block below the player and adds the 'invalid" tag

execute @a[tag=inJungle] ~ ~ ~ detect ~ ~-1 ~ barrier 0 /tag @s add invalid
#execute @a[tag=inJungle] ~ ~ ~ detect ~ ~-1 ~ planks 1 /tag @s add invalid
#execute @a[tag=inJungle] ~ ~ ~ detect ~ ~-1 ~ wooden_slab 9 /tag @s add invalid
#execute @a[tag=inJungle] ~ ~ ~ detect ~ ~-1 ~ double_wooden_slab 1 /tag @s add invalid
execute @a[tag=invalid] ~ ~ ~ kill @e[type=minecart,r=4]
