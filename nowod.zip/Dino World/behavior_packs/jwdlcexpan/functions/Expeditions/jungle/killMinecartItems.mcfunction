# kills minecarts as they approch checkpoints

execute @e[type=item] 1752 68 -187 /kill @e[type=item,r=1]
execute @e[type=item] 1758 68 -196 /kill @e[type=item,r=1]
execute @e[type=item] 1762 55 -236 /kill @e[type=item,r=1]
execute @e[type=item] 1758 38 -184 /kill @e[type=item,r=1]
execute @e[type=item] 1757 23 -154 /kill @e[type=item,r=1]

