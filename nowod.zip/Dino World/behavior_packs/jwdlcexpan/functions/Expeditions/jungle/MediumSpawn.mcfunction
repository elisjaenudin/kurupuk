say Jungle Medium Spawn

summon llama 0 4 -2
summon llama -1 4 -3