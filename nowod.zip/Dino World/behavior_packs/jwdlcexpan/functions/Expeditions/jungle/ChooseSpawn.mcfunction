
scoreboard players set @e[tag=disaster_system] found_DNA 0
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_1 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_2 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_3 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_4 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_5 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_6 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_7 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_8 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_9 found_DNA
scoreboard players operation @e[tag=disaster_system] found_DNA += jungle_10 found_DNA

execute @e[tag=disaster_system,scores={found_DNA=0..4}] ~ ~ ~ /function Expeditions/jungle/LightSpawn

execute @e[tag=disaster_system,scores={found_DNA=5..7}] ~ ~ ~ /function Expeditions/jungle/MediumSpawn

execute @e[tag=disaster_system,scores={found_DNA=8..10}] ~ ~ ~ /function Expeditions/jungle/HeavySpawn