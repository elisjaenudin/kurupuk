kill @e[type=minecart,r=9]
kill @e[type=item,r=9]
summon minecart 1755 23 -154