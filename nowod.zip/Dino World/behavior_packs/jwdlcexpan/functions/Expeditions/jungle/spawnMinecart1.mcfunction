kill @e[type=minecart,r=5]
kill @e[type=item,r=5]
summon minecart 1753 67 -235