#Jungle respawn

fill 1757 73 -189 1757 73 -191 redstone_block 0 replace air 0
setblock 1782 48 -261 jw:brachiosaurus_block
setblock 1766 52 -282 jw:spinosaurus_block