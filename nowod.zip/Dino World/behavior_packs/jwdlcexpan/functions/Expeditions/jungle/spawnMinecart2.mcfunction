kill @e[type=minecart,r=7]
kill @e[type=item,r=7]
summon minecart 1752 67 -186