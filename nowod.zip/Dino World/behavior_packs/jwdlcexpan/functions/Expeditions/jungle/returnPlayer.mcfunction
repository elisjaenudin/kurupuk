# returns the player to their checkpoint when they have the "invalid" tag 

execute @a[tag=invalid,scores={checkpoint=1}] ~ ~ ~ /tp @s 1750 67 -237 facing 1751 67 -235
execute @a[tag=invalid,scores={checkpoint=2}] ~ ~ ~ /tp @s 1753 67 -188 facing 1753 67 -186
execute @a[tag=invalid,scores={checkpoint=3}] ~ ~ ~ /tp @s 1758 68 -196 facing 1758 68 -197
execute @a[tag=invalid,scores={checkpoint=4}] ~ ~ ~ /tp @s 1761 55 -237 facing 1759 55 -235
execute @a[tag=invalid,scores={checkpoint=5}] ~ ~ ~ /tp @s 1758 38 -186 facing 1760 38 -186
execute @a[tag=invalid,scores={checkpoint=6}] ~ ~ ~ /tp @s 1711 59 -269 facing 1712 58 -267
execute @a[tag=invalid,scores={checkpoint=7}] ~ ~ ~ /tp @s 1757 23 -153 facing 1756 23 -153
execute @a[tag=invalid,scores={checkpoint=8}] ~ ~ ~ /tp @s 1723 60 -294 facing 1723 60 -290
execute @a[tag=invalid,scores={checkpoint=9}] ~ ~ ~ /tp @s 1738 61 -246 facing 1734 61 -249
execute @a[tag=invalid,scores={checkpoint=10}] ~ ~ ~ /tp @s 1802 62 -292 facing 1799 62 -292
execute @a[tag=invalid,scores={checkpoint=11}] ~ ~ ~ /tp @s 1789 63 -295 facing 1790 63 -294
# do nothing if the tag = 0 
execute @a[tag=invalid] ~ ~ ~ /tag @s add displayText
execute @a[tag=invalid,scores={checkpoint=0}] ~ ~ ~ /tag @s remove displayText


execute @a[tag=invalid,tag=displayText] ~ ~ ~ /tag @s add alternateText

execute @a[tag=invalid,tag=displayText,tag=fallText1,scores={checkpoint=6..}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.fallText1.chat"}]}
execute @a[tag=invalid,tag=displayText,tag=fallText1,scores={checkpoint=6..}] ~ ~ ~ /titleraw @s title {"rawtext":[{"text":" "}]}
execute @a[tag=invalid,tag=displayText,tag=fallText1,scores={checkpoint=6..}] ~ ~ ~ /tag @s add fallText2
execute @a[tag=invalid,tag=displayText,tag=fallText1,tag=fallText2,scores={checkpoint=6..}] ~ ~ ~ /tag @s remove alternateText
execute @a[tag=invalid,tag=displayText,tag=fallText1,tag=fallText2,scores={checkpoint=6..}] ~ ~ ~ /tag @s remove fallText1


execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=alternateText,scores={checkpoint=6..}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.fallText2.chat"}]}
execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=alternateText,scores={checkpoint=6..}] ~ ~ ~ /titleraw @s title {"rawtext":[{"text":" "}]}
execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=alternateText,scores={checkpoint=6..}] ~ ~ ~ /tag @s add fallText1
execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=fallText1,tag=alternateText,scores={checkpoint=6..}] ~ ~ ~ /tag @s remove fallText2



execute @a[tag=invalid,tag=displayText,tag=fallText1,scores={checkpoint=..5}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.fallText3.chat"}]}
execute @a[tag=invalid,tag=displayText,tag=fallText1,scores={checkpoint=..5}] ~ ~ ~ /titleraw @s title {"rawtext":[{"text":" "}]}
execute @a[tag=invalid,tag=displayText,tag=fallText1,scores={checkpoint=..5}] ~ ~ ~ /tag @s add fallText2
execute @a[tag=invalid,tag=displayText,tag=fallText1,tag=fallText2,scores={checkpoint=..5}] ~ ~ ~ /tag @s remove alternateText
execute @a[tag=invalid,tag=displayText,tag=fallText1,tag=fallText2,scores={checkpoint=..5}] ~ ~ ~ /tag @s remove fallText1


execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=alternateText,scores={checkpoint=..5}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.fallText4.chat"}]}
execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=alternateText,scores={checkpoint=..5}] ~ ~ ~ /titleraw @s title {"rawtext":[{"text":" "}]}
execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=alternateText,scores={checkpoint=..5}] ~ ~ ~ /tag @s add fallText1
execute @a[tag=invalid,tag=displayText,tag=fallText2,tag=fallText1,tag=alternateText,scores={checkpoint=..5}] ~ ~ ~ /tag @s remove fallText2

execute @a[tag=invalid] ~ ~ ~ /tag @s remove invalid
execute @a[tag=displayText] ~ ~ ~ /tag @s remove displayText