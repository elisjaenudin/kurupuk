# kills minecarts as they approch checkpoints

execute @e[type=minecart] 1752 67 -187 /kill @e[type=minecart,r=0.5]
execute @e[type=minecart] 1758 68 -196 /kill @e[type=minecart,r=0.5]
execute @e[type=minecart] 1762 55 -236 /kill @e[type=minecart,r=0.5]
execute @e[type=minecart] 1758 38 -184 /kill @e[type=minecart,r=0.5]
execute @e[type=minecart] 1757 23 -154 /kill @e[type=minecart,r=0.5]

