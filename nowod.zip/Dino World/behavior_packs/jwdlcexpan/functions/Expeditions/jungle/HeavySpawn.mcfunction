say Jungle Heavy Spawn

summon llama 0 4 -2
summon llama -1 4 -3
summon llama 1 4 -4