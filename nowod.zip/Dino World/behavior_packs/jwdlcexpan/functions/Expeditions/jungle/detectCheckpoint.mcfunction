# detects when a player passes a checkpoint and updates thier "checkpoint" score

execute @a[x=1750, y=67, z=-237, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 1
execute @a[x=1753, y=67, z=-188, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 2
execute @a[x=1758, y=68, z=-196, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 3
execute @a[x=1761, y=55, z=-238, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 4
execute @a[x=1758, y=38, z=-186, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 5
execute @a[x=1711, y=59, z=-269, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 6
execute @a[x=1757, y=23, z=-153, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 7
execute @a[x=1723, y=60, z=-294, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 8
execute @a[x=1738, y=61, z=-246, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 9
execute @a[x=1802, y=62, z=-292, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 10
execute @a[x=1785, y=63, z=-296, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 11
execute @a[x=1758, y=51, z=-261, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 0
execute @a[x=1765, y=59, z=-283, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 0
execute @a[x=1738, y=63, z=-315, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 0
execute @a[x=1761, y=63, z=-320, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 0
execute @a[x=1709, y=63, z=-356, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 0
execute @a[x=1752, y=48, z=-259, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 0
execute @a[x=1763, y=58, z=-273, r=4,tag=inJungle] ~ ~ ~ /scoreboard players set @s checkpoint 0