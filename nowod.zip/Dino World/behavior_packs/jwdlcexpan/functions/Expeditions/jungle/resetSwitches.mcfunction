# sets all switchs to the correct position for the minecart puzzle

setblock 1753 67 -184 lever 5
setblock 1759 69 -198 lever 11
setblock 1758 55 -236 lever 4
setblock 1761 38 -187 lever 13