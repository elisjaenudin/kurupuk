scoreboard objectives add found_DNA dummy
scoreboard objectives add checkpoint dummy
tag @s remove alternateText
tag @s remove fallText1
tag @s remove fallText2
tag @s add fallText1

scoreboard players reset * found_DNA


scoreboard players set jungle_1 found_DNA 0
scoreboard players set jungle_2 found_DNA 0
scoreboard players set jungle_3 found_DNA 0
scoreboard players set jungle_4 found_DNA 0
scoreboard players set jungle_5 found_DNA 0
scoreboard players set jungle_6 found_DNA 0
scoreboard players set jungle_7 found_DNA 0
scoreboard players set jungle_8 found_DNA 0
scoreboard players set jungle_9 found_DNA 0
scoreboard players set jungle_10 found_DNA 0


scoreboard players set desert_1 found_DNA 0
scoreboard players set desert_2 found_DNA 0
scoreboard players set desert_3 found_DNA 0
scoreboard players set desert_4 found_DNA 0
scoreboard players set desert_5 found_DNA 0
scoreboard players set desert_6 found_DNA 0
scoreboard players set desert_7 found_DNA 0
scoreboard players set desert_8 found_DNA 0
scoreboard players set desert_9 found_DNA 0
scoreboard players set desert_10 found_DNA 0


scoreboard players set tundra_1 found_DNA 0
scoreboard players set tundra_2 found_DNA 0
scoreboard players set tundra_3 found_DNA 0
scoreboard players set tundra_4 found_DNA 0
scoreboard players set tundra_5 found_DNA 0
scoreboard players set tundra_6 found_DNA 0
scoreboard players set tundra_7 found_DNA 0
scoreboard players set tundra_8 found_DNA 0
scoreboard players set tundra_9 found_DNA 0
scoreboard players set tundra_10 found_DNA 0