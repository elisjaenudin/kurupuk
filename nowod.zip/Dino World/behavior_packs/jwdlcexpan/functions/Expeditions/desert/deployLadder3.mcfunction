# deploys a ladder
#DEBUG ladder3
setblock 434 18 -2260 air
fill 433 12 -2260 433 17 -2260 ladder 4
execute @a[tag=inDesert] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.ladderDeployed.chat"}]}
execute @a[tag=inDesert] ~ ~ ~ /titleraw @a title {"rawtext":[{"text":" "}]}