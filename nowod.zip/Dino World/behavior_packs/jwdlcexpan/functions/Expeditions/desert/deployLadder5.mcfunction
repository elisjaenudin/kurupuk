# deploys a ladder
#DEBUG ladder5
setblock 421 20 -2293 air
fill 421 14 -2292 421 19 -2292 ladder 1
execute @a[tag=inDesert] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.ladderDeployed.chat"}]}
execute @a[tag=inDesert] ~ ~ ~ /titleraw @a title {"rawtext":[{"text":" "}]}