# deploys a ladder
#DEBUG ladder2
setblock 439 10 -2281 air
fill 439 7 -2280 439 9 -2280 ladder 1
execute @a[tag=inDesert] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.ladderDeployed.chat"}]}
execute @a[tag=inDesert] ~ ~ ~ /titleraw @a title {"rawtext":[{"text":" "}]}