# checks for players in ladder zones
execute @e[type=jurassic_world:rope_ladder] ~ ~ ~ /tp @s ~ 0 ~

kill @e[type=jurassic_world:rope_ladder]

summon jurassic_world:rope_ladder 429 10 -2273
tag @e[type=jurassic_world:rope_ladder,x=429,y=10,z=-2273,r=2] add ladder1
execute @e[tag=ladder1] ~ ~ ~ /tp @s ~ ~ ~ 90

summon jurassic_world:rope_ladder 439 10 -2281
tag @e[type=jurassic_world:rope_ladder,x=439,y=10,z=-2281,r=2] add ladder2
execute @e[tag=ladder2] ~ ~ ~ /tp @s ~ ~ ~ 180

summon jurassic_world:rope_ladder 434 18 -2260
tag @e[type=jurassic_world:rope_ladder,x=434,y=18,z=-2260,r=2] add ladder3
execute @e[tag=ladder3] ~ ~ ~ /tp @s ~ ~ ~ 270

summon jurassic_world:rope_ladder 418 20 -2272
tag @e[type=jurassic_world:rope_ladder,x=418,y=20,z=-2272,r=2] add ladder4
execute @e[tag=ladder4] ~ ~ ~ /tp @s ~ ~ ~ 0

summon jurassic_world:rope_ladder 421 20 -2293
tag @e[type=jurassic_world:rope_ladder,x=421,y=20,z=-2293,r=2] add ladder5
execute @e[tag=ladder5] ~ ~ ~ /tp @s ~ ~ ~ 180