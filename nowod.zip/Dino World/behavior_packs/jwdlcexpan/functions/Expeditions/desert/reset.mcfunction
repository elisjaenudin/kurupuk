# resets desert
#DEBUG reset

#cleanup
kill @e[type=jurassic_world:scientist,x=435,y=6,z=-2280,r=2]

#structure block
setblock 416 20 -2302 redstone_block
#function Expeditions/desert/spawnLadders
