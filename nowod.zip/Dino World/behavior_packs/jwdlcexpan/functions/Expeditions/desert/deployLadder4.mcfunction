# deploys a ladder
#DEBUG ladder4
setblock 418 20 -2272 air
fill 418 14 -2273 418 19 -2273 ladder 2
execute @a[tag=inDesert] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.ladderDeployed.chat"}]}
execute @a[tag=inDesert] ~ ~ ~ /titleraw @a title {"rawtext":[{"text":" "}]}