# deploys a ladder
#DEBUG ladder1

setblock 429 10 -2273 air
fill 430 7 -2273 430 9 -2273 ladder 5
execute @a[tag=inDesert] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.ladderDeployed.chat"}]}
execute @a[tag=inDesert] ~ ~ ~ /titleraw @a title {"rawtext":[{"text":" "}]}