#disasters left message switch

execute @e[tag=disaster_system,scores={disaster_count=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.none_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=2}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.one_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=3}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.two_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=4}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.three_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=5}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.four_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=6}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.five_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=7}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.six_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=8}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.seven_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=9}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.eight_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=10}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.nine_left.chat"}]}
execute @e[tag=disaster_system,scores={disaster_count=11}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ten_left.chat"}]}
