#===========Coal Refuel===============

replaceitem block 382 51 -405 slot.container 1 coal 64
replaceitem block 382 52 -405 slot.container 1 coal 64
replaceitem block 380 51 -405 slot.container 1 coal 64
replaceitem block 380 52 -405 slot.container 1 coal 64

#give players some xp for naming dinos
xp 5L @a