#pick tier 0 disaster
#say Picking Disaster:

#random number generator
scoreboard players random @e[tag=disaster_system] randomDisaster 1 60

#============================power outage============================
#execute @e[tag=disaster_system,scores={randomDisaster=1..10}] ~ ~ ~ /say power outage
execute @e[tag=disaster_system,scores={randomDisaster=1..10}] ~ ~ ~ /setblock 346 1 -479 redstone_block
execute @e[tag=disaster_system,scores={randomDisaster=1..10}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zonePicked 0

#--------DEBUG----------
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /say power outage
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /setblock 346 1 -479 redstone_block
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zonePicked 0
#====================================================================


#============================damage exhibit============================
execute @e[tag=disaster_system,scores={randomDisaster=31..40,debug=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zonePicked 0
execute @e[tag=disaster_system,scores={randomDisaster=31..40,debug=0}] ~ ~ ~ /setblock 356 1 -479 redstone_block
#execute @e[tag=disaster_system,scores={randomDisaster=31..40,debug=0}] ~ ~ ~ /say damage exhibit

#--------DEBUG----------
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /say damage exhibit
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /setblock 346 1 -479 redstone_block
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zonePicked 0
#====================================================================

#============================Break Transportation============================
execute @e[tag=disaster_system,scores={randomDisaster=41..50,debug=0}] ~ ~ ~ /setblock 350 1 -479 redstone_block
execute @e[tag=disaster_system,scores={randomDisaster=41..50,debug=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zonePicked 0
#execute @e[tag=disaster_system,scores={randomDisaster=41..50,debug=0}] ~ ~ ~ /say Break Vehicle
#--------DEBUG----------
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /setblock 350 1 -479  redstone_block
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zonePicked 0
#====================================================================

#============================storm============================
execute @e[tag=disaster_system,scores={randomDisaster=51..60}] ~ ~ ~ /setblock 348 1 -479 redstone_block
execute @e[tag=disaster_system,scores={randomDisaster=51..60}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] zonePicked 0
#execute @e[tag=disaster_system,scores={randomDisaster=51..60}] ~ ~ ~ /say storm
#--------DEBUG----------
#execute @e[tag=disaster_system,scores={randomDisaster=1..,debug=1}] ~ ~ ~ /setblock 348 1 -479  redstone_block
#execute @e[tag=disaster_system,scores={randomDisaster=1..,debug=1}] ~ ~ ~ /scoreboard players set @e[tag=storm_zone_math] zonePicked 0
#====================================================================


#============================escaped Dino============================
#execute @e[tag=disaster_system,scores={randomDisaster=11..20}] ~ ~ ~ /say escaped dino
execute @e[tag=disaster_system,scores={randomDisaster=11..20}] ~ ~ ~ /setblock 360 1 -479 redstone_block
execute @e[tag=disaster_system,scores={randomDisaster=11..20}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zonePicked 0
#--------DEBUG----------
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /say escaped dino
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /setblock 360 1 -479 redstone_block
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zonePicked 0
#====================================================================


#============================Saboteur============================
execute @e[tag=disaster_system,scores={randomDisaster=21..30,debug=0}] ~ ~ ~ /setblock 364 1 -479 redstone_block
execute @e[tag=disaster_system,scores={randomDisaster=21..30,debug=0}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zonePicked 0
#execute @e[tag=disaster_system,scores={randomDisaster=21..30,debug=0}] ~ ~ ~ /say saboteur
#--------DEBUG----------
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /say saboteur
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /setblock 364 1 -479 redstone_block
#execute @e[tag=disaster_system,scores={randomDisaster=1..}] ~ ~ ~ /scoreboard players set @e[tag=sabo_zone_math] zonePicked 0
#====================================================================




#============================nothing============================
#execute @e[tag=disaster_system,scores={debug=0}] ~ ~ ~ /execute @e[tag=disaster_system,scores={randomDisaster=101..110}] ~ ~ ~ /setblock 30 4 2 redstone_block
#execute @e[tag=disaster_system,scores={debug=0}] ~ ~ ~ /execute @e[tag=disaster_system,scores={randomDisaster=101..110}] ~ ~ ~ /say Nothing