# closes QCD Safari gates
#DEBUG QCD Safari gate close

#close
fill 353 52 -600 355 56 -605 air 0 replace stained_glass_pane 5
fill 356 52 -601 356 56 -604 stained_glass_pane 5 replace air

fill 365 52 -600 363 56 -605 air 0 replace stained_glass_pane 5
fill 362 53 -601 362 56 -604 stained_glass_pane 5 replace air