# closes gyrosphere valley side gate
#DEBUG Gyro Side Gate close

#Close 
fill 229 49 -645 229 49 -648 cobblestone_wall 4 replace air
fill 229 50 -645 229 50 -648 iron_bars 0 replace air
fill 229 51 -645 229 51 -648 cobblestone_wall 4 replace air
fill 229 52 -645 229 52 -648 iron_bars 0 replace air
fill 229 53 -645 229 53 -648 cobblestone_wall 4 replace air