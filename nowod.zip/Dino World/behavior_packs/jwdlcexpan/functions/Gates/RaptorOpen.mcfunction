# opens rator gates
#DEBUG raptor gate open

#open
fill 817 53 -480 825 56 -480 air 0 replace stained_glass_pane 5
fill 817 59 -480 825 62 -480 stained_glass_pane 5 replace air