# closes cretaceous cruise notrh gates
#DEBUG cretaceous cruise north gate close

#close
fill 658 16 -353 662 21 -353 air 0 replace iron_bars
fill 658 16 -353 662 18 -353 iron_bars 0 replace air
fill 658 15 -353 662 15 -353 iron_bars 0

fill 658 16 -349 662 21 -349 air 0 replace iron_bars
fill 658 16 -349 662 18 -349 iron_bars 0 replace air
fill 658 15 -349 662 15 -349 iron_bars 0