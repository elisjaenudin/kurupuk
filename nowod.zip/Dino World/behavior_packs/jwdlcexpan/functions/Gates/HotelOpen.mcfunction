# opens hotel gates
#DEBUG hotel gate open

#open
fill 267 48 -192 271 51 -193 stained_glass_pane 5 replace air 0
fill 268 48 -192 270 51 -194 air 0 replace stained_glass_pane 5