# closes trex gates
#DEBUG trex gate close

#close
fill 310 44 -301 315 48 -303 stone_slab 0
fill 310 44 -302 315 48 -302 smooth_stone