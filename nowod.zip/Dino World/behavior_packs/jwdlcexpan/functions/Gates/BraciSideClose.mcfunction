# closes gyrosphere valley side gate
#DEBUG Gyro Side Gate close

#Close 
fill 284 43 -601 287 43 -601 cobblestone_wall 4 replace air
fill 284 44 -601 287 44 -601 iron_bars 0 replace air
fill 284 45 -601 287 45 -601 cobblestone_wall 4 replace air
fill 284 46 -601 287 46 -601 iron_bars 0 replace air
fill 284 47 -601 287 47 -601 cobblestone_wall 4 replace air