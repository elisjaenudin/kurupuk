# closes hotel gates
#DEBUG hotel gate close

#close
fill 267 48 -192 271 51 -193 air 0 replace stained_glass_pane 5
fill 268 48 -194 270 51 -194 stained_glass_pane 5 replace air