# opens gyrosphere valley side gate
#DEBUG Gyro Side Gate open

#open
fill 229 49 -645 229 53 -648 air