# closes cretaceous cruise notrh gates
#DEBUG cretaceous cruise north gate close

#close
fill 607 16 -262 611 21 -262 air 0 replace iron_bars
fill 607 16 -262 611 18 -262 iron_bars 0 replace air
fill 607 15 -262 611 15 -262 iron_bars 0

fill 607 16 -258 611 21 -258 air 0 replace iron_bars
fill 607 16 -258 611 18 -258 iron_bars 0 replace air
fill 607 15 -258 611 15 -258 iron_bars 0