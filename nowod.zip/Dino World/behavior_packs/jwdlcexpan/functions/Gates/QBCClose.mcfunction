# closes QCC Safari gates
#DEBUG QCC Safari gate close

#close
fill 721 53 -355 726 56 -357 air 0 replace stained_glass_pane 5
fill 722 53 -358 725 56 -358 stained_glass_pane 5 replace air

fill 721 52 -365 726 56 -367 air 0 replace stained_glass_pane 5
fill 722 52 -364 725 56 -364 stained_glass_pane 5 replace air