# closes C_cruise side gate
#DEBUG C_cruise Side Gate close

#Close 
fill 579 18 -456 582 18 -456 cobblestone_wall 4 replace air
fill 579 19 -456 582 19 -456 iron_bars 0 replace air
fill 579 20 -456 582 20 -456 cobblestone_wall 4 replace air
fill 579 21 -456 582 21 -456 iron_bars 0 replace air
fill 579 22 -456 582 22 -456 cobblestone_wall 4 replace air