# opens C_cruise side gate
#DEBUG C_cruise Side Gate open

#open
fill 579 18 -456 582 22 -456 air