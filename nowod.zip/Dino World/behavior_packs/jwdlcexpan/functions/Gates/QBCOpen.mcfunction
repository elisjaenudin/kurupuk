# closes QCC Safari gates
#DEBUG QCC Safari gate close

#open
fill 721 53 -355 726 56 -357 stained_glass_pane 5 replace air
fill 722 53 -355 725 56 -358 air 0 replace stained_glass_pane 5

fill 721 52 -365 726 56 -367 stained_glass_pane 5 replace air
fill 722 52 -364 725 56 -367 air 0 replace stained_glass_pane 5