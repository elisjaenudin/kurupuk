# opens gallimimus valley station gates
#DEBUG Galli Gate open

#open
fill 491 42 -607 491 45 -608 stained_glass_pane 5 replace air 0
fill 496 42 -607 496 45 -608 stained_glass_pane 5 replace air 0
fill 492 42 -606 495 45 -606 air 0 replace stained_glass_pane 5

fill 491 42 -600 491 45 -598 stained_glass_pane 5 replace air 0
fill 496 42 -600 496 45 -598 stained_glass_pane 5 replace air 0
fill 492 42 -601 495 45 -601 air 0 replace stained_glass_pane 5