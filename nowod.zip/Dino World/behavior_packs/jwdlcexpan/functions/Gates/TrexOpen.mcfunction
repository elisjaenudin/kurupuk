# opens trex gates
#DEBUG trex gate open

#open
fill 310 44 -301 315 48 -303 air