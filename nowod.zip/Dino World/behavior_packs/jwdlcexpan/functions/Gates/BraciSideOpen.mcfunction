# opens gyrosphere valley side gate
#DEBUG Gyro Side Gate open

#open
fill 284 43 -601 287 47 -601 air