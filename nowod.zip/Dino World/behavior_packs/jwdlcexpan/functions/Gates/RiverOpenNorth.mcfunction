# opens cretaceous cruise gates
#DEBUG cretaceous cruise gate open

#open
fill 658 16 -353 662 21 -353 iron_bars 0 replace air
fill 658 16 -353 662 17 -353 air 0 replace iron_bars
fill 658 15 -353 662 15 -353 water 7 replace iron_bars

fill 658 16 -349 662 21 -349 iron_bars 0 replace air
fill 658 16 -349 662 17 -349 air 0 replace iron_bars
fill 658 15 -349 662 15 -349 water 7 replace iron_bars