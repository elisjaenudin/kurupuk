# opens cretaceous cruise gates
#DEBUG cretaceous cruise gate open

#open
fill 607 16 -262 611 21 -262 iron_bars 0 replace air
fill 607 16 -262 611 17 -262 air 0 replace iron_bars
fill 607 15 -262 611 15 -262 water 7 replace iron_bars

fill 607 16 -258 611 21 -258 iron_bars 0 replace air
fill 607 16 -258 611 17 -258 air 0 replace iron_bars
fill 607 15 -258 611 15 -258 water 7 replace iron_bars