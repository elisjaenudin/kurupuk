tp @p 701 52 -392 facing 702 52 -392
setblock 363 2 -420 redstone_block