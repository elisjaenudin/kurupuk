tp @p 329 67 -625 facing 329 67 -624
setblock 379 2 -420 redstone_block