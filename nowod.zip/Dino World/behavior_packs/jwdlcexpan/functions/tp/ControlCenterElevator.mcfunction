tp @p 352 56 -415 180 0
#playsound elevator.ding @a 352 56 -415
playsound elevator.ding @a[x=350,y=42,z=-413,dx=353,dy=77,dz=-417]
kill @e[type=jw:breadcrumb_2,x=353.8,y=52.5,z=-418,r=0.5]
function DisplayProgress