clone 342 1 -441 342 1 -441 341 1 -445
gamerule dotiledrops false
setblock 341 1 -445 air 0 destroy
execute @p ~ ~ ~ /tp @e[type=item,x=341,y=1,z=-445,r=3,c=1] ~ ~ ~
gamerule dotiledrops true
kill @e[type=item,x=341,y=1,z=-445,r=6]