#open
#execute @e[tag=disaster_system] ~ ~ ~ detect 344 56 -427 lever 13 /say open
execute @e[tag=disaster_system,scores={park_open=0,park_resetting=0}] ~ ~ ~ detect 342 55 -432 lever 13 /function ParkSwitchedOn
execute @e[tag=disaster_system,scores={park_open=0,park_resetting=0}] ~ ~ ~ detect 342 55 -432 lever 13 /setblock 378 1 -464 redstone_block
execute @e[tag=disaster_system,scores={park_open=0,park_resetting=0}] ~ ~ ~ detect 342 55 -432 lever 13 /titleraw @a times 1 60 1
execute @e[tag=disaster_system,scores={park_open=0,park_resetting=0}] ~ ~ ~ detect 342 55 -432 lever 13 /titleraw @a subtitle {"rawtext":[{"translate":"jw:park_open"}]}
execute @e[tag=disaster_system,scores={park_open=0,park_resetting=0}] ~ ~ ~ detect 342 55 -432 lever 13 /titleraw @a title {"rawtext":[{"text":" "}]}
execute @e[tag=disaster_system,scores={park_open=0,park_resetting=0}] ~ ~ ~ detect 342 55 -432 lever 13 /scoreboard players set @e[tag=disaster_system] park_open 1
execute @e[tag=disaster_system,scores={park_open=0,park_resetting=0}] ~ ~ ~ detect 342 55 -432 lever 13 /tag @a remove park_closed

#say checking  park status
#closed
#execute @e[tag=disaster_system] ~ ~ ~ detect 344 56 -427 lever 5 /say closed
execute @e[tag=disaster_system,scores={park_open=1}] ~ ~ ~ detect 342 55 -432 lever 5 /function ParkReset
execute @e[tag=disaster_system,scores={park_open=1}] ~ ~ ~ detect 342 55 -432 lever 5 /setblock 378 1 -464 air
execute @e[tag=disaster_system,scores={park_open=1}] ~ ~ ~ detect 342 55 -432 lever 5 /titleraw @a times 1 60 1
execute @e[tag=disaster_system,scores={park_open=1}] ~ ~ ~ detect 342 55 -432 lever 5 /titleraw @a subtitle {"rawtext":[{"translate":"jw:park_close"}]}
execute @e[tag=disaster_system,scores={park_open=1}] ~ ~ ~ detect 342 55 -432 lever 5 /titleraw @a title {"rawtext":[{"text":" "}]}
execute @e[tag=disaster_system,scores={park_open=1}] ~ ~ ~ detect 342 55 -432 lever 5 /scoreboard players set @e[tag=disaster_system] park_open 0
execute @e[tag=disaster_system,scores={park_open=1}] ~ ~ ~ detect 342 55 -432 lever 5 /tag @a add park_closed
