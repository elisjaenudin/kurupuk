# disable section 3
#DEBUG disableSec3

execute @a[scores={breadcrumb=1}] ~ ~ ~ /scoreboard players set @s breadcrumb 2
function Breadcrumb/laySection
function HotelMonoSwitch

setblock 346 8 -420 air
setblock 346 8 -425 air
setblock 346 8 -430 air
setblock 346 8 -435 air
setblock 346 8 -440 air
setblock 346 8 -445 air