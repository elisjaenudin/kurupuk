# resets the breadcrumbs
#DEBUG reset

execute @a ~ ~ ~ /scoreboard players set @s breadcrumb 0
setblock 346 12 -420 redstone_block
setblock 346 10 -420 redstone_block
setblock 346 8 -420 redstone_block
setblock 348 12 -420 redstone_block
setblock 348 10 -420 redstone_block
setblock 350 12 -420 redstone_block
setblock 350 10 -420 redstone_block
setblock 346 8 -420 redstone_block
setblock 346 8 -425 redstone_block
setblock 346 8 -430 redstone_block
setblock 346 8 -435 redstone_block
setblock 346 8 -440 redstone_block
setblock 346 8 -445 redstone_block
kill @e[type=jw:breadcrumb]
kill @e[type=jw:breadcrumb_2]

execute @e[type=jurassic_world:henry_wu,tag=Wu1] ~ ~ ~ /tp 362 51 -414
execute @e[type=jurassic_world:henry_wu,tag=Wu2,tag=npcClosed] ~ ~ ~ /tp 342 1 -436
execute @e[type=jurassic_world:henry_wu,tag=Wu2,tag=npcOpen] ~ ~ ~ /tp 342 1 -434

execute @a[scores={breadcrumb=0}] ~ ~ ~ /tp @e[tag=starter_GG] 474 57 -331
execute @a[scores={breadcrumb=0}] ~ ~ ~ /tp @e[tag=perm_GG] 349 1 -436