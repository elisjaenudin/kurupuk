# summons the appropriate section of breadcrumb entities according to a score thats based on checkpoint triggers
#DEBUG laySection

#Cleanup
kill @e[type=jw:breadcrumb]
kill @e[type=jw:breadcrumb_2]

#======Section 9

execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 359 42 -410
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 359 42 -399
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 360 42 -393
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 366 42 -392
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 386 42 -392
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 406 42 -392
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 426 42 -392
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 446 42 -392
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 458 42 -393
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 463 41 -394
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 465 41 -399
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 465 41 -419
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 465 40 -439

#Button Highlight: to Gali Valley
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb_2 467.8 41.5 -445

execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 479 39 -449
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 488 39 -450
execute @a[scores={breadcrumb=8}] ~ ~ ~ /summon jw:breadcrumb 501 37 -454

#End of tutorial
execute @a[scores={breadcrumb=8}] ~ ~ ~ /scoreboard players set @s breadcrumb 9

#======Section 8

execute @a[scores={breadcrumb=7}] ~ ~ ~ /summon jw:breadcrumb 357 51 -415

#Door Highlight
execute @a[scores={breadcrumb=7}] ~ ~ ~ /summon jw:breadcrumb 354 51 -415

#Door Highlight
execute @a[scores={breadcrumb=7}] ~ ~ ~ /summon jw:breadcrumb 354 51 -416

#Button Highlight: to Garage
execute @a[scores={breadcrumb=7}] ~ ~ ~ /summon jw:breadcrumb_2 353.8 51.5 -417.9

#Vehicle Highlight
execute @a[scores={breadcrumb=7}] ~ ~ ~ /summon jw:breadcrumb 365 42 -414

#End of section
execute @a[scores={breadcrumb=7}] ~ ~ ~ /scoreboard players set @s breadcrumb 8

#======Section 7

#Door Highlight
execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb 349 75 -415

#Door Highlight
execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb 349 75 -416

#Button Highlight: to Lab
execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb_2 350.2 76.5 -412.2

#Door Highlight
execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb 354 51 -416

#Door Highlight
execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb 354 51 -415

execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb 361 51 -416

#Dr Wu 2 Highlight
execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb 368 51 -419

#Station 1 Highlight
execute @a[scores={breadcrumb=6}] ~ ~ ~ /summon jw:breadcrumb 371 51 -414

#End of section
execute @a[scores={breadcrumb=6}] ~ ~ ~ /scoreboard players set @s breadcrumb 7

#======Section 5

execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1738 61 -361
execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1738 62 -354
execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1738 65 -345
execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1739 65 -336
execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1741 64 -328
execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1746 63 -322

#Foreman Highlight
execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1750 63 -317

#Amber Highlight
execute @a[scores={breadcrumb=4}] ~ ~ ~ /summon jw:breadcrumb 1756 64 -312

#Move onto next section
execute @a[scores={breadcrumb=4}] ~ ~ ~ /scoreboard players set @s breadcrumb 6

#======Section 6

execute @a[scores={breadcrumb=5}] ~ ~ ~ /summon jw:breadcrumb 438 19 -2241
execute @a[scores={breadcrumb=5}] ~ ~ ~ /summon jw:breadcrumb 438 16 -2248
execute @a[scores={breadcrumb=5}] ~ ~ ~ /summon jw:breadcrumb 438 10 -2259
execute @a[scores={breadcrumb=5}] ~ ~ ~ /summon jw:breadcrumb 438 7 -2269

#Paleontologist Highlight
execute @a[scores={breadcrumb=5}] ~ ~ ~ /summon jw:breadcrumb 435 6 -2280

#Fossile Highlight
execute @a[scores={breadcrumb=5}] ~ ~ ~ /summon jw:breadcrumb 443 5 -2268

#Move onto next section
execute @a[scores={breadcrumb=5}] ~ ~ ~ /scoreboard players set @s breadcrumb 6

#======Section 4

execute @a[scores={breadcrumb=3}] ~ ~ ~ /summon jw:breadcrumb 349 56 -423

#Door Highlight
execute @a[scores={breadcrumb=3}] ~ ~ ~ /summon jw:breadcrumb 351 56 -418

#Door Highlight
execute @a[scores={breadcrumb=3}] ~ ~ ~ /summon jw:breadcrumb 352 56 -418

#Button Highlight: to Helepad 
execute @a[scores={breadcrumb=3}] ~ ~ ~ /summon jw:breadcrumb_2 349.2 58.5 -416.9

#Door Highlight
execute @a[scores={breadcrumb=3}] ~ ~ ~ /summon jw:breadcrumb 349 75 -415

#Door Highlight
execute @a[scores={breadcrumb=3}] ~ ~ ~ /summon jw:breadcrumb 349 75 -416

#Masrani Highlight
execute @a[scores={breadcrumb=3}] ~ ~ ~ /summon jw:breadcrumb 342 75 -417

#Swap Dr. Wu
execute @a[scores={breadcrumb=3}] ~ ~ ~ /tp @e[type=jurassic_world:henry_wu,tag=Wu1] 342 1 -436
execute @a[scores={breadcrumb=3}] ~ ~ ~ /tp @e[type=jurassic_world:henry_wu,tag=npcClosed,tag=Wu2] 368 51 -419 90

#Move onto next section
execute @a[scores={breadcrumb=3}] ~ ~ ~ /scoreboard players set @s breadcrumb 4

#======Section 3

#Fossil Highlight
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 399 52 -391

#Hammond Lab Section
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 390 51 -396
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 390 51 -401
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 390 51 -406
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 390 51 -411
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 390 51 -416
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 390 51 -421

#Door Highlight
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 366 51 -422


execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 365 51 -417

#Dr Wu Highlight
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 362 51 -414

#execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 361 51 -416
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 354 51 -416
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 354 51 -415

#Button Highlight: to Control Room
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb_2 353.8 52.5 -417.8

#Button disaster cursor
#execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 353 53 -414

execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 351 56 -418
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 352 56 -418
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 350 56 -423

#Claire Highlight
execute @a[scores={breadcrumb=2}] ~ ~ ~ /summon jw:breadcrumb 341 55 -425

#Gentle Giants monorsil staff swap
execute @a[scores={breadcrumb=2}] ~ ~ ~ /tp @e[tag=starter_GG] 349 1 -436
execute @a[scores={breadcrumb=2}] ~ ~ ~ /tp @e[tag=perm_GG] 474 57 -331

#Move onto next section
execute @a[scores={breadcrumb=2}] ~ ~ ~ /scoreboard players set @s breadcrumb 3

#=======Section 2

#Gentle Giants Monorail Staff Highlight
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 474 57 -331

#Innovation Center Section
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 470 55 -332
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 468 53 -332
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 466 51 -332
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 464 49 -332
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 460 48 -332
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 457 48 -334
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 455 48 -337
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 455 48 -341
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 453 48 -344
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 451 48 -347
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 448 48 -351
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 444 48 -353
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 440 48 -353
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 436 48 -353
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 432 48 -352
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 428 48 -350
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 424 48 -348
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 422 48 -344
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 420 48 -340
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 416 48 -338
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 411 48 -338
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 406 48 -337
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 401 48 -335
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 396 48 -334
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 392 48 -334
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 389 48 -335
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 390 48 -339
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 389 49 -343
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 389 51 -347

#Door Highlight
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 389 51 -351

#Door Highlight
execute @a[scores={breadcrumb=1}] ~ ~ ~ /summon jw:breadcrumb 390 51 -351

#Move onto next section
execute @a[scores={breadcrumb=1}] ~ ~ ~ /scoreboard players set @s breadcrumb 2

#=======Section 1

#Monorail Section
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 13 8
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 15 13
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 18 16
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 21 19
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 24 22
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 27 25
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 30 28
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb 0 32 30
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb -1 32 33

#Ferry Monorail Staff Highlight
execute @a[scores={breadcrumb=0}] ~ ~ ~ /summon jw:breadcrumb -2 32 34

#Move onto next section
execute @a[scores={breadcrumb=0}] ~ ~ ~ /scoreboard players set @s breadcrumb 1

