scoreboard players set @e[tag=disaster_system] countdown 30

scoreboard players set @e[tag=disaster_system] time_open_secs 0
scoreboard players set @e[tag=disaster_system] total_open_secs 0
scoreboard players set @e[tag=disaster_system] time_open_mins 0
scoreboard players set @e[tag=disaster_system] time_open_hrs 0

scoreboard players set @e[tag=disaster_system] storm_active 0

#disasters remove themselves from count, so no need to run it here
#scoreboard players set @e[tag=disaster_system] disaster_count 1


#set off reset chain
setblock 368 1 -478 redstone_block
scoreboard players set @e[tag=disaster_system] park_resetting 1

titleraw @a actionbar {"rawtext":[{"translate":"jw.resetting.actionbar"}]}

#disable lever while reset is happening
#setblock 344 56 -427 air

#park closed sign
clone 370 10 -420 370 10 -420 335 63 -441
execute @e[type=jurassic_world:sign_control_monitor_park_closed] ~ ~ ~ /tp 336 63 -441
execute @e[type=jurassic_world:sign_control_monitor_time_open] ~ ~ ~ /tp 336 63 -442

#Swap NPCs
execute @e[type=jurassic_world:claire_dearing,tag=npcClosed] ~ ~ ~ /tp 341 55 -425 180
execute @e[type=jurassic_world:lowery_cruthers,tag=npcClosed] ~ ~ ~ /tp 337 54 -431 180
execute @e[type=jurassic_world:vivian_krill,tag=npcClosed] ~ ~ ~ /tp 340 54 -431 180
execute @e[type=jurassic_world:simon_masrani,tag=npcClosed] ~ ~ ~ /tp 342 75 -417
execute @e[type=jurassic_world:henry_wu,tag=npcClosed,tag=Wu2] ~ ~ ~ /tp 366 51 -415 90

execute @e[type=jurassic_world:claire_dearing,tag=npcOpen] ~ ~ ~ /tp 342 1 -426
execute @e[type=jurassic_world:lowery_cruthers,tag=npcOpen] ~ ~ ~ /tp 342 1 -430
execute @e[type=jurassic_world:vivian_krill,tag=npcOpen] ~ ~ ~ /tp 342 1 -428
execute @e[type=jurassic_world:simon_masrani,tag=npcOpen] ~ ~ ~ /tp 342 1 -432
execute @e[type=jurassic_world:henry_wu,tag=npcOpen,tag=Wu2] ~ ~ ~ /tp 342 1 -434