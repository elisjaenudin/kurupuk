#capture dino
execute @e[type=minecraft:skeleton] ~ ~ ~ /tag @e[tag=sleeping,r=5,c=1] add dino_to_catch
#execute @e[type=minecraft:skeleton] ~ ~ ~ /say dino caught

execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /execute @e[tag=dino_to_catch] ~ ~ ~ /playsound helicopter.transition @a[r=32]
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /tp @e[tag=dino_to_catch] 395 1 -479
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /tag @e[tag=dino_to_catch] add caught_dino
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /clear @a spawn_egg 34
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /setblock 360 1 -483 redstone_block

#if dino is already caught, then make sure they have the release item, not the capture item.
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /clear @a spawn_egg 34
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /clear @a spawn_egg 46
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /give @a spawn_egg 1 46
#execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.dino_already_caught.chat"}]}

#execute @e[tag=caught_dino] ~ ~ ~ /say dino successfully caught
execute @e[tag=caught_dino] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] dinocaught 1
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.no_sleeping_dinos.chat"}]}
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /clear @a spawn_egg 46
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /clear @a spawn_egg 34
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /give @a spawn_egg 1 34

tag @e[tag=dino_to_catch] remove dino_to_catch