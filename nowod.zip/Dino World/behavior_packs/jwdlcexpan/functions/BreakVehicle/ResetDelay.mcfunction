#reset function
scoreboard players set @e[tag=vehi_zone_math] z1_vehi_active 0
scoreboard players set @e[tag=vehi_zone_math] z2_vehi_active 0
scoreboard players set @e[tag=vehi_zone_math] z3_vehi_active 0
scoreboard players set @e[tag=vehi_zone_math] zonePicked 0
scoreboard players set @e[tag=vehi_zone_math] zone_random 0

#un-suppress the messaging for fixing disasters
scoreboard players set @e[tag=vehi_zone_math] no_fix_msg 0

#turn this off
setblock 348 1 -442 air