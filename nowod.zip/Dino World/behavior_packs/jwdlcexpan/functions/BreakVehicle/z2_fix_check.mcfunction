
# set off fix z2 block if vehicle was teleported
execute @e[tag=zone2_vehicle,x=403,y=1,z=-479,r=10] ~ ~ ~ /setblock 350 1 -457 redstone_block