#debug 
#execute @e[tag=vehi_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 2 Break Vehicle

#prevent redstone retriggering zone selection
execute @e[tag=vehi_zone_math,scores={z2_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=vehi_zone_math,scores={zone2loaded=0,z2_vehi_active=0}] ~ ~ ~ /setblock 350 1 -479 air

#===spawn the broken vehicle===
execute @e[tag=vehi_zone_math,scores={zone2loaded=0,z2_vehi_active=0}] ~ ~ ~ detect 172 38 -709 grass 0 /function BreakVehicle/spawn/Zone2_Gyrosphere
#====================

#message Sector 2 disaster
execute @e[tag=vehi_zone_math,scores={zone2loaded=1,z2_vehi_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.vehicle2event.chat"}]}

#start check for solution
execute @e[tag=vehi_zone_math,scores={zone2loaded=1,z2_vehi_active=0}] ~ ~ ~ /setblock 350 1 -460 redstone_block

#stop this block
execute @e[tag=vehi_zone_math,scores={zone2loaded=1,z2_vehi_active=0}] ~ ~ ~ /setblock 350 1 -463 air

#----------------turn off ticking area
execute @e[tag=vehi_zone_math,scores={zone2loaded=1,z2_vehi_active=0}] ~ ~ ~ /tickingarea remove vehizone2

#add this to total disaster count
execute @e[tag=vehi_zone_math,scores={zone2loaded=1,z2_vehi_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=vehi_zone_math,scores={zone2loaded=1,z2_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] z2_vehi_active 1

#reset zone2loaded
execute @e[tag=vehi_zone_math,scores={zone2loaded=1,z2_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zone2loaded 0