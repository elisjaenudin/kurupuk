
# set off fix z3 block if vehicle was teleported
execute @e[tag=zone3_vehicle,x=403,y=1,z=-479,r=10] ~ ~ ~ /setblock 350 1 -445 redstone_block