tickingarea remove vehizone3

#turn off this block
setblock 350 1 -442 air