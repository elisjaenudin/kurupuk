#debug 
#execute @e[tag=vehi_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 1 Break Vehicle

#prevent redstone retriggering zone selection
execute @e[tag=vehi_zone_math,scores={z1_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=vehi_zone_math,scores={zone1loaded=0,z1_vehi_active=0}] ~ ~ ~ /setblock 350 1 -479 air

#===spawn the broken vehicle===
execute @e[tag=vehi_zone_math,scores={zone1loaded=0,z1_vehi_active=0}] ~ ~ ~ detect 376 52 -104 wool 13 /function BreakVehicle/spawn/Zone1_Helicopter
#====================

#message Sector 1 disaster
execute @e[tag=vehi_zone_math,scores={zone1loaded=1,z1_vehi_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.vehicle1event.chat"}]}

#start check for solution
execute @e[tag=vehi_zone_math,scores={zone1loaded=1,z1_vehi_active=0}] ~ ~ ~ /setblock 350 1 -472 redstone_block

#stop this block
execute @e[tag=vehi_zone_math,scores={zone1loaded=1,z1_vehi_active=0}] ~ ~ ~ /setblock 350 1 -476 air

#----------------turn off ticking area
execute @e[tag=vehi_zone_math,scores={zone1loaded=1,z1_vehi_active=0}] ~ ~ ~ /tickingarea remove vehizone1

#add this to total disaster count
execute @e[tag=vehi_zone_math,scores={zone1loaded=1,z1_vehi_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=vehi_zone_math,scores={zone1loaded=1,z1_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] z1_vehi_active 1

#reset zone1loaded
execute @e[tag=vehi_zone_math,scores={zone1loaded=1,z1_vehi_active=1}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zone1loaded 0