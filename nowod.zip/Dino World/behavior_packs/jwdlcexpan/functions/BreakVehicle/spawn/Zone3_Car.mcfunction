#=========================== Zone 3 Car broken =================

#dino spawn
summon jurassic_world:truck_jp18 494 36 -549 "jw:broken"
execute @e[type=jurassic_world:truck_jp18,x=494,y=36,z=-549,r=2] ~ ~ ~ /tag @s add zone3_vehicle

scoreboard players set @e[tag=vehi_zone_math] zone3loaded 1

#add entity from the map
summon jw:disaster 349.4 59.3 -441
execute @e[type=jw:disaster,x=349.4,y=59.3,z=-441,r=1] 349.4 59.3 -441 tag @s add dis_broken_vez3
