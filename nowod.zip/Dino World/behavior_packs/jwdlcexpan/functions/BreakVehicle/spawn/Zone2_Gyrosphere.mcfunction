#=========================== Zone 2 Gyrosphere broken =================

#dino spawn
summon jurassic_world:gyrosphere 172 39 -709 "jw:broken"
execute @e[type=jurassic_world:gyrosphere,x=172,y=39,z=-709,r=2] ~ ~ ~ /tag @s add zone2_vehicle

scoreboard players set @e[tag=vehi_zone_math] zone2loaded 1

#add entity from the map
summon jw:disaster 346.8 60.4 -441
execute @e[type=jw:disaster,x=346.8,y=60.4,z=-441,r=1] 346.8 60.4 -441 tag @s add dis_broken_vez2
