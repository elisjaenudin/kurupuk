#=========================== Zone 1 helicopter broken =================

#dino spawn
summon jurassic_world:helicopter 376 53 -104 "jw:broken"
execute @e[type=jurassic_world:helicopter,x=376,y=53,z=-104,r=2] ~ ~ ~ /tag @s add zone1_vehicle

scoreboard players set @e[tag=vehi_zone_math] zone1loaded 1

#add entity from the map
summon jw:disaster 348.3 55.8 -441
execute @e[type=jw:disaster,x=348.3,y=55.8,z=-441,r=1] 348.3 55.8 -441 tag @s add dis_broken_vez1
