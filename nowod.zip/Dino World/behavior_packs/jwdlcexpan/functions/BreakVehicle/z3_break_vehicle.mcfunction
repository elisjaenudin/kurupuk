#debug 
#execute @e[tag=vehi_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 3 Break Vehicle

#prevent redstone retriggering zone selection
execute @e[tag=vehi_zone_math,scores={z3_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=vehi_zone_math,scores={zone3loaded=0,z3_vehi_active=0}] ~ ~ ~ /setblock 350 1 -479 air

#===spawn the broken vehicle===
execute @e[tag=vehi_zone_math,scores={zone3loaded=0,z3_vehi_active=0}] ~ ~ ~ detect 494 35 -549 grass 0 /function BreakVehicle/spawn/Zone3_Car
#====================

#message Sector 3 disaster
execute @e[tag=vehi_zone_math,scores={zone3loaded=1,z3_vehi_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.vehicle3event.chat"}]}

#start check for solution
execute @e[tag=vehi_zone_math,scores={zone3loaded=1,z3_vehi_active=0}] ~ ~ ~ /setblock 350 1 -448 redstone_block

#stop this block
execute @e[tag=vehi_zone_math,scores={zone3loaded=1,z3_vehi_active=0}] ~ ~ ~ /setblock 350 1 -451 air

#----------------turn off ticking area
execute @e[tag=vehi_zone_math,scores={zone3loaded=1,z3_vehi_active=0}] ~ ~ ~ /tickingarea remove vehizone3

#add this to total disaster count
execute @e[tag=vehi_zone_math,scores={zone3loaded=1,z3_vehi_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=vehi_zone_math,scores={zone3loaded=1,z3_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] z3_vehi_active 1

#reset zone3loaded
execute @e[tag=vehi_zone_math,scores={zone3loaded=1,z3_vehi_active=0}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zone3loaded 0