#if we aren't active, turn off the redstone block for this command block
execute @e[tag=vehi_zone_math,scores={z2_vehi_active=0}] ~ ~ ~ /setblock 350 1 -457 air

#turn off reset block
execute @e[tag=vehi_zone_math,scores={z2_vehi_active=0}] ~ ~ ~ /setblock 348 1 -457 air

#turn off solution check
execute @e[tag=vehi_zone_math,scores={z2_vehi_active=0}] ~ ~ ~ /setblock 350 1 -460 air
#------------------------------------------end inactive precautions-------------------------

#create ticking zone for zone 1
execute @e[tag=vehi_zone_math,scores={zone2loaded=0,z2_vehi_active=1}] ~ ~ ~ /tickingarea add circle 172 39 -709 4 vehizone2
execute @e[tag=vehi_zone_math,scores={zone2loaded=0,z2_vehi_active=1}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zone2loaded 1

#get rid of dinosaur
execute @e[tag=vehi_zone_math,scores={zone2loaded=1, z2_vehi_active=1}] ~ ~ ~ detect 172 38 -709 grass 0 /scoreboard players set @e[tag=vehi_zone_math] zone2loaded 2
execute @e[tag=vehi_zone_math,scores={zone2loaded=2, z2_vehi_active=1}] ~ ~ ~ /tp @e[tag=zone2_vehicle] 403 2 -479
execute @e[tag=vehi_zone_math,scores={zone2loaded=2, z2_vehi_active=1}] ~ ~ ~ /kill @e[tag=zone2_vehicle]

#remove indicator
clone 367 1 -434 374 15 -441 172 140 -709 replace force

#fix message
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.vehicle2fix.subtitle"}]}
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}


#play stinger
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#turn off solution check
execute @e[tag=vehi_zone_math,scores={zone2loaded=2, z2_vehi_active=1}] ~ ~ ~ /setblock 350 1 -460 air

#stop this block
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1}] ~ ~ ~ /setblock 350 1 -457 air

#stop reset block
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1}] ~ ~ ~ /setblock 348 1 -457 air

#stop ticking area
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1}] ~ ~ ~ /tickingarea remove vehizone2

#remove this from total disaster count
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1}] ~ ~ ~ /setblock 350 1 -454 redstone_block

#reset zone 2 loaded 
execute @e[tag=vehi_zone_math,scores={zone2loaded=2,z2_vehi_active=1}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zone2loaded 0

#mark z2 inactive
execute @e[tag=vehi_zone_math,scores={zone2loaded=0,z2_vehi_active=1}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] z2_vehi_active 0

#remove entity from the map
kill @e[tag=dis_broken_vez2]
