#create the ticking zone
tickingarea add circle 494 36 -549 1 vehizone3

#turn off block for finding vehicle to break
setblock 350 1 -479 air

#activate the redstone block for spawning broken vehicle
setblock 350 1 -451 redstone_block

#reset zone3loaded
scoreboard players set @e[tag=vehi_zone_math] zone3loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=vehi_zone_math] zonePicked 1

#add indicator
clone 365 1 -425 372 15 -432 494 140 -549 replace force

#play disaster sound
playsound stinger.disaster.01 @a