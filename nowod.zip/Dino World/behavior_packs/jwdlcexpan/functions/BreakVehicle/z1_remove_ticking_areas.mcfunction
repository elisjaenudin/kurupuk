tickingarea remove vehizone1

#turn off this block
setblock 350 1 -466 air