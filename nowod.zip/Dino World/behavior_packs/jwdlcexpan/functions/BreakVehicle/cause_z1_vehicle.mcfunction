#create the ticking zone
tickingarea add circle 376 53 -104 1 vehizone1

#turn off block for finding transportation to break
setblock 350 1 -479 air

#activate the redstone block for breaking vehicle
setblock 350 1 -476 redstone_block

#reset zone1loaded
scoreboard players set @e[tag=vehi_zone_math] zone1loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=vehi_zone_math] zonePicked 1

#add indicator
clone 365 1 -425 372 15 -432 376 140 -104 replace force

#play disaster sound
playsound stinger.disaster.01 @a