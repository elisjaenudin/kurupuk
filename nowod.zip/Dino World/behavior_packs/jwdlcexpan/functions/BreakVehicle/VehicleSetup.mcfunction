#Break Vehicle Setup
scoreboard objectives add z1_vehi_active dummy
scoreboard objectives add z2_vehi_active dummy
scoreboard objectives add z3_vehi_active dummy

scoreboard players set @e[tag=vehi_zone_math] z1_vehi_active 0

scoreboard players set @e[tag=vehi_zone_math] z2_vehi_active 0

scoreboard players set @e[tag=vehi_zone_math] z3_vehi_active 0

scoreboard players set @e[tag=vehi_zone_math] zonePicked 0
scoreboard players set @e[tag=vehi_zone_math] zone_random 0
