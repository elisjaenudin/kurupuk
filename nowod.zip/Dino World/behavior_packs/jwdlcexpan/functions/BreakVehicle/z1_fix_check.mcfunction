
# set off fix z1 block if vehicle was teleported
execute @e[tag=zone1_vehicle,x=403,y=1,z=-479,r=10] ~ ~ ~ /setblock 350 1 -469 redstone_block