#debug
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Break Gyrosphere

#loop if zones aren't full until we choose a zone that doesn't have a broken gyro
scoreboard players random @e[tag=vehi_zone_math] zone_random 1 3

#===Zone1===
execute @e[tag=vehi_zone_math,scores={zone_random=1..1,z1_vehi_active=0,zonePicked=0}] ~ ~ ~ /function BreakVehicle/cause_z1_vehicle

#===Zone2===
execute @e[tag=vehi_zone_math,scores={zone_random=2..2,z2_vehi_active=0,zonePicked=0}] ~ ~ ~ /function BreakVehicle/cause_z2_vehicle

#===Zone3===
execute @e[tag=vehi_zone_math,scores={zone_random=3..3,z3_vehi_active=0,zonePicked=0}] ~ ~ ~ /function BreakVehicle/cause_z3_vehicle

#=======================================================
#check if all zones are active, and if they are, call a different disaster
execute @e[tag=vehi_zone_math,scores={z1_vehi_active=1,z2_vehi_active=1,z3_vehi_active=1,zonePicked=0}] ~ ~ ~ /function BreakVehicle/CheckActive