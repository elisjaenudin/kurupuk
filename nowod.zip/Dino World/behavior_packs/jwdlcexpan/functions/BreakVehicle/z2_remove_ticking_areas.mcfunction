tickingarea remove vehizone2

#turn off this block
setblock 350 1 -454 air