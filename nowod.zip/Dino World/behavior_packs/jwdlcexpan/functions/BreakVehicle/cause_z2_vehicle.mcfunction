#create the ticking zone
tickingarea add circle 172 39 -709 1 vehizone2

#turn off block for finding dinosaur to spawn
setblock 350 1 -479 air

#activate the redstone block for spawning dino
setblock 350 1 -463 redstone_block

#reset zone2loaded
scoreboard players set @e[tag=vehi_zone_math] zone2loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=vehi_zone_math] zonePicked 1

#add indicator
clone 365 1 -425 372 15 -432 172 140 -709 replace force

#play disaster sound
playsound stinger.disaster.01 @a