#if we aren't active, turn off the redstone block for this command block (which is also reset in this case)
execute @e[tag=vehi_zone_math,scores={z1_vehi_active=0}] ~ ~ ~ /setblock 350 1 -469 air

#turn off solution check
execute @e[tag=vehi_zone_math,scores={z1_vehi_active=0}] ~ ~ ~ /setblock 350 1 -472 air
#------------------------------------------end inactive precautions-------------------------

#create ticking zone for zone 1
execute @e[tag=vehi_zone_math,scores={zone1loaded=0,z1_vehi_active=1}] ~ ~ ~ /tickingarea add circle 376 53 -104 1 vehizone1
execute @e[tag=vehi_zone_math,scores={zone1loaded=0,z1_vehi_active=1}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zone1loaded 1

#get rid of dinosaur
execute @e[tag=vehi_zone_math,scores={zone1loaded=1, z1_vehi_active=1}] ~ ~ ~ detect 376 52 -104 wool 13 /scoreboard players set @e[tag=vehi_zone_math] zone1loaded 2
execute @e[tag=vehi_zone_math,scores={zone1loaded=2, z1_vehi_active=1}] ~ ~ ~ /tp @e[tag=zone1_vehicle] 403 2 -479
execute @e[tag=vehi_zone_math,scores={zone1loaded=2, z1_vehi_active=1}] ~ ~ ~ /kill @e[tag=zone1_vehicle]

#remove indicator
clone 367 1 -434 374 15 -441 376 140 -104 replace force

#fix message
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.vehicle1fix.subtitle"}]}
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#turn off solution check
execute @e[tag=vehi_zone_math,scores={zone1loaded=2, z1_vehi_active=1}] ~ ~ ~ /setblock 350 1 -472 air

#stop this block
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1}] ~ ~ ~ /setblock 350 1 -469 air

#stop ticking area
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1}] ~ ~ ~ /tickingarea remove vehizone1

#remove this from total disaster count
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1}] ~ ~ ~ /setblock 350 1 -466 redstone_block

#reset zone 1 loaded 
execute @e[tag=vehi_zone_math,scores={zone1loaded=2,z1_vehi_active=1}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] zone1loaded 0

#mark z1 inactive
execute @e[tag=vehi_zone_math,scores={zone1loaded=0,z1_vehi_active=1}] ~ ~ ~ /scoreboard players set @e[tag=vehi_zone_math] z1_vehi_active 0

#remove entity from the map
kill @e[tag=dis_broken_vez1]
