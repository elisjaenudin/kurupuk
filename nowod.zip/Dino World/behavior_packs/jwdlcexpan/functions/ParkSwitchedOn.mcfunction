scoreboard players set @e[tag=disaster_system] countdown 30

scoreboard players set @e[tag=disaster_system] time_open_secs 0
scoreboard players set @e[tag=disaster_system] total_open_secs 0

#reset the revenue
function Hype/Reset
function Hype/CalculateHype

#time open sign
clone 369 10 -420 369 10 -420 335 63 -441
execute @e[type=jurassic_world:sign_control_monitor_park_closed] ~ ~ ~ /tp 336 63 -442
execute @e[type=jurassic_world:sign_control_monitor_time_open] ~ ~ ~ /tp 336 63 -441

#unequip the players
clear @a jw:wrench
clear @a crossbow
clear @a arrow 64
clear @a diamond_sword

#equip the players
function TakeEquipment
function GiveEquipment
clear @a spawn_egg 33 1
give @a spawn_egg 1 33 {"can_place_on":{"blocks":["grass","gravel","stone","stained_glass","sand","stained_hardened_clay","planks","wooden_slab"]}}

#Swap NPCs
execute @e[type=jurassic_world:claire_dearing,tag=npcClosed] ~ ~ ~ /tp 342 1 -426 
execute @e[type=jurassic_world:lowery_cruthers,tag=npcClosed] ~ ~ ~ /tp 342 1 -430
execute @e[type=jurassic_world:vivian_krill,tag=npcClosed] ~ ~ ~ /tp 342 1 -428
execute @e[type=jurassic_world:simon_masrani,tag=npcClosed] ~ ~ ~ /tp 342 1 -432
execute @e[type=jurassic_world:henry_wu,tag=npcClosed,tag=Wu2] ~ ~ ~ /tp 342 1 -434

execute @e[type=jurassic_world:claire_dearing,tag=npcOpen] ~ ~ ~ /tp 341 55 -425 180
execute @e[type=jurassic_world:lowery_cruthers,tag=npcOpen] ~ ~ ~ /tp 337 54 -431 180
execute @e[type=jurassic_world:vivian_krill,tag=npcOpen] ~ ~ ~ /tp 340 54 -431 180
execute @e[type=jurassic_world:simon_masrani,tag=npcOpen] ~ ~ ~ /tp 342 75 -417
execute @e[type=jurassic_world:henry_wu,tag=npcOpen,tag=Wu2] ~ ~ ~ /tp 366 51 -415 90

playsound stinger.epic.02 @a

#Disable Reminder
setblock 344 8 -424 sponge

#replenish visitors
execute @e[tag=disaster_system,scores={vis=..87}] ~ ~ ~ /setblock 348 12 -425 redstone_block