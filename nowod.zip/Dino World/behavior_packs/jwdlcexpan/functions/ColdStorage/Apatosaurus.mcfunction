#===========Apatosaurus_block===============

setblock 398 6 -424 redstone_block 0 replace
clone 343 14 -420 343 14 -420 375 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Apatosaurus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Apatosaurus_subtitle"}]}
tag @e[type=jurassic_world:robotic_arm_2_amber] add done

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a islandSamples 1
function DisplayProgress