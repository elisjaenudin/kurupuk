#===========Triceratops_block===============

setblock 398 9 -424 redstone_block 0 replace
clone 353 14 -420 353 14 -420 366 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Triceratops_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Triceratops_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a desertSamples 1
function DisplayProgress