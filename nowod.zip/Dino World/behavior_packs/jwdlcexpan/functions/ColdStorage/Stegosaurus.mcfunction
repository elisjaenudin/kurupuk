#===========Stegosaurus_block===============

setblock 393 6 -424 redstone_block 0 replace
clone 346 14 -420 346 14 -420 367 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Stegosaurus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Stegosaurus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a jungleSamples 1
function DisplayProgress