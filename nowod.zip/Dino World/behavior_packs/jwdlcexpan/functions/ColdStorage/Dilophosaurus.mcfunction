#===========Dilophosaurus_block===============

setblock 396 6 -424 redstone_block 0 replace
clone 349 14 -420 349 14 -420 373 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Compsognathus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Dilophosaurus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a islandSamples 1
function DisplayProgress


