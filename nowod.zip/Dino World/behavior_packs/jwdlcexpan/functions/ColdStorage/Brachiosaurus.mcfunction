#===========Brachiosaurus_block===============

setblock 397 7 -424 redstone_block 0 replace
clone 344 14 -420 344 14 -420 375 51 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Brachiosaurus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Brachiosaurus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a jungleSamples 1
function DisplayProgress