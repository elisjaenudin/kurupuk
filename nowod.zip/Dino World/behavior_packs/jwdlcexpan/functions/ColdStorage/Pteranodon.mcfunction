#===========Pteranodon_block===============

setblock 394 6 -424 redstone_block 0 replace
clone 345 14 -420 345 14 -420 368 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Pteranodon_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Pteranodon_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a desertSamples 1
function DisplayProgress