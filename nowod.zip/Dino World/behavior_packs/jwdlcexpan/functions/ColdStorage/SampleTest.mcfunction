#===========SampleCheck===============

##Jungle Mines
execute @e[tag=disaster_system] ~ ~ ~ detect 1782 48 -261 water -1 /setblock 397 7 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 1757 64 -312 air 0 /setblock 396 7 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 1766 52 -282 air 0 /setblock 393 7 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 1710 59 -269 air 0 /setblock 393 6 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 1754 67 -144 air 0 /setblock 397 10 -420 redstone_block

##Desert Mines
execute @e[tag=disaster_system] ~ ~ ~ detect 430 7 -2263 air 0 /setblock 397 6 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 440 7 -2263 air 0 /setblock 394 6 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 443 17 -2297 air 0 /setblock 397 9 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 444 5 -2268 air 0 /setblock 398 10 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 429 11 -2290 air 0 /setblock 398 9 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 429 11 -2290 sand -1 /setblock 398 9 -420 redstone_block

execute @e[tag=disaster_system] ~ ~ ~ detect 430 7 -2263 sand 1 /setblock 397 6 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 440 7 -2263 sand 1 /setblock 394 6 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 443 17 -2297 sand 1 /setblock 397 9 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 444 5 -2268 sand 1 /setblock 398 10 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 424 8 -2292 sand 1 /setblock 398 9 -420 redstone_block

##Isla Nublar
execute @e[tag=disaster_system] ~ ~ ~ detect 146 43 -651 air 0 /setblock 398 7 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 398 52 -415 air 0 /setblock 398 6 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 395 52 -407 air 0 /setblock 395 7 -420 redstone_block
execute @e[tag=disaster_system] ~ ~ ~ detect 399 52 -392 air 0 /setblock 394 8 -420 redstone_block
