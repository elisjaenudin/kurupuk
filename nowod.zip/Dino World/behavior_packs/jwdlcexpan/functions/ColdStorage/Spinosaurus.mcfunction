#===========Parasaurolophus_block===============

setblock 393 7 -424 redstone_block 0 replace
clone 356 14 -420 356 14 -420 368 51 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Parasaurolophus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Spinosaurus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a jungleSamples 1
function DisplayProgress