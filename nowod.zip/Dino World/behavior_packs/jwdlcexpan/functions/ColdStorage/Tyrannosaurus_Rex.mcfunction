#===========Tyrannosaurus_Rex_block===============

setblock 397 10 -424 redstone_block 0 replace
clone 355 14 -420 355 14 -420 366 51 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Tyrannosaurus_Rex_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Tyrannosaurus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a jungleSamples 1
function DisplayProgress