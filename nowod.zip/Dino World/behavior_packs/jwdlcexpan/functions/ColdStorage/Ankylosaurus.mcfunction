#===========Ankylosaurus_block===============

setblock 398 7 -424 redstone_block 0 replace
clone 352 14 -420 352 14 -420 376 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Ankylosaurus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Ankylosaurus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a islandSamples 1
function DisplayProgress
