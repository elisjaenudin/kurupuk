#===========Dimorphodon_block===============

setblock 395 7 -424 redstone_block 0 replace
clone 358 14 -420 358 14 -420 369 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Dimorphodon_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Dimorphodon_subtitle"}]}
tag @e[type=jurassic_world:robotic_arm_2_fossil] add done

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a islandSamples 1
function DisplayProgress