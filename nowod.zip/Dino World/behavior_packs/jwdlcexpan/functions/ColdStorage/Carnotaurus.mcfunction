#===========Carnotaurus_block===============

setblock 397 6 -424 redstone_block 0 replace
clone 342 14 -420 342 14 -420 374 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Carnotaurus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Carnotaurus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a desertSamples 1
function DisplayProgress
