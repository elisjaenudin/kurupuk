#===========Reset===============

scoreboard players set @a islandSamples 0
scoreboard players set @a jungleSamples 0
scoreboard players set @a desertSamples 0

fill 397 9 -420 398 10 -424 air 0 replace redstone_block 0
fill 393 6 -420 398 8 -420 air 0 replace redstone_block 0
fill 397 9 -424 398 10 -424 air 0 replace redstone_block 0
fill 393 6 -424 398 7 -424 air 0 replace redstone_block 0
fill 395 1 -424 395 1 -425 redstone_block 0 replace air 0
setblock 394 7 -428 air

#clone cold storage container
clone 393 10 -419 393 10 -419 376 53 -413 replace force
clone 393 10 -419 393 10 -419 375 53 -413 replace force
clone 393 10 -419 393 10 -419 375 52 -413 replace force
clone 393 10 -419 393 10 -419 374 53 -413 replace force
clone 393 10 -419 393 10 -419 374 52 -413 replace force
clone 393 10 -419 393 10 -419 373 53 -413 replace force
clone 393 10 -419 393 10 -419 373 52 -413 replace force
clone 393 10 -419 393 10 -419 369 53 -413 replace force
clone 393 10 -419 393 10 -419 369 52 -413 replace force
clone 393 10 -419 393 10 -419 368 53 -413 replace force
clone 393 10 -419 393 10 -419 368 52 -413 replace force
clone 393 10 -419 393 10 -419 367 53 -413 replace force
clone 393 10 -419 393 10 -419 367 52 -413 replace force
clone 393 10 -419 393 10 -419 366 53 -413 replace force
clone 393 10 -419 393 10 -419 366 52 -413 replace force
clone 393 10 -419 393 10 -419 365 53 -413 replace force
#animal samples
clone 396 10 -419 396 10 -419 365 52 -413 replace force
clone 396 9 -419 396 9 -419 364 53 -413 replace force
clone 395 10 -419 395 10 -419 364 52 -413 replace force
clone 395 9 -419 395 9 -419 363 53 -413 replace force
clone 394 10 -419 394 10 -419 363 52 -413 replace force
#clone cold storage signs
clone 370 14 -420 370 14 -420 376 54 -414 replace force
clone 370 14 -420 370 14 -420 375 54 -414 replace force
clone 370 14 -420 370 14 -420 375 51 -414 replace force
clone 370 14 -420 370 14 -420 374 54 -414 replace force
clone 370 14 -420 370 14 -420 374 51 -414 replace force
clone 370 14 -420 370 14 -420 373 54 -414 replace force
clone 370 14 -420 370 14 -420 373 51 -414 replace force
clone 370 14 -420 370 14 -420 369 54 -414 replace force
clone 370 14 -420 370 14 -420 369 51 -414 replace force
clone 370 14 -420 370 14 -420 368 54 -414 replace force
clone 370 14 -420 370 14 -420 368 51 -414 replace force
clone 370 14 -420 370 14 -420 367 54 -414 replace force
clone 370 14 -420 370 14 -420 367 51 -414 replace force
clone 370 14 -420 370 14 -420 366 54 -414 replace force
clone 370 14 -420 370 14 -420 366 51 -414 replace force
clone 370 14 -420 370 14 -420 365 54 -414 replace force