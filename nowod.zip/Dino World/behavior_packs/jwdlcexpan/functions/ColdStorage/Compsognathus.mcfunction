#===========Compsognathus_block===============

setblock 396 7 -424 redstone_block 0 replace
clone 359 14 -420 359 14 -420 374 51 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Compsognathus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Compsognathus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a jungleSamples 1
function DisplayProgress