#===========Stygimoloch_block===============

setblock 398 10 -424 redstone_block 0 replace
clone 348 14 -420 348 14 -420 367 51 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Stygimoloch_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Stygimoloch_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a desertSamples 1
function DisplayProgress