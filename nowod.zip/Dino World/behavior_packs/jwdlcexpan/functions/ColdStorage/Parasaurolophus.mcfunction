#===========Parasaurolophus_block===============

setblock 394 7 -428 redstone_block 0 replace
setblock 399 52 -392 air
clone 357 14 -420 357 14 -420 369 51 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Parasaurolophus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Parasaurolophus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a islandSamples 1
function DisplayProgress