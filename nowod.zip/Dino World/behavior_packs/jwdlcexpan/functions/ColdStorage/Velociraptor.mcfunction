#===========Velociraptor_block===============

setblock 397 9 -424 redstone_block 0 replace
clone 354 14 -420 354 14 -420 365 54 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Velociraptor_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Velociraptor_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a desertSamples 1
function DisplayProgress