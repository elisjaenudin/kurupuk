#===========Gallimimus_block===============

clear @a JW:Gallimimus_block 0 1
setblock 395 6 -424 redstone_block 0 replace
clone 347 14 -420 347 14 -420 373 51 -414 replace force
titleraw @a title {"rawtext":[{"translate":"jw:found_Gallimimus_block"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:found_Gallimimus_subtitle"}]}

#play disaster sound
playsound stinger.epic.01 @a

scoreboard players add @a islandSamples 1
function DisplayProgress