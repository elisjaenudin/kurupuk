# Notify the player that they can open the park
#say DEBUG notify

#titleraw @a subtitle {"rawtext":[{"translate":"jw.progress.park_ready"}]}
#titleraw @a title {"rawtext":[{"translate":" "}]}

titleraw @a actionbar {"rawtext":[{"translate":"jw.progress.park_ready"}]}
tellraw @a {"rawtext":[{"translate":"jw.progress.park_ready"}]} 
