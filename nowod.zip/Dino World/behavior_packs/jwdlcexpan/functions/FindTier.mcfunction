#Find what tier we are in
#say finding tier

#Already 12 active disasters, close the park
execute @e[tag=disaster_system,scores={disaster_count=13..}] ~ ~ ~ /function ShutDownPark

#still able to run disasters
execute @e[tag=disaster_system,scores={disaster_count=1..12}] ~ ~ ~ /function PickDisaster