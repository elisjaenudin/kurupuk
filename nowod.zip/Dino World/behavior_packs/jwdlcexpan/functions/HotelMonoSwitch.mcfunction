#Setup hotel monorail station after the player passes

#structure bank
setblock 265 38 -190 redstone_block
# disable command zone detector
setblock 350 8 -420 air