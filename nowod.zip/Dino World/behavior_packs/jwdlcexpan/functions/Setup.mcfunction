scoreboard objectives add countdown dummy
scoreboard objectives add timeCheck dummy
scoreboard objectives add tierPoints dummy
scoreboard objectives add randomDisaster dummy
scoreboard objectives add randomTime dummy
scoreboard objectives add z1_random_time dummy
scoreboard objectives add z2_random_time dummy
scoreboard objectives add z3_random_time dummy
scoreboard objectives add zonePicked dummy
scoreboard objectives add zone_random dummy
scoreboard objectives add fixedCheck dummy
scoreboard objectives add loading dummy
scoreboard objectives add zone1loaded dummy
scoreboard objectives add zone2loaded dummy
scoreboard objectives add zone3loaded dummy
scoreboard objectives add debug dummy
scoreboard objectives add disaster_count dummy
scoreboard objectives add time_open_secs dummy
scoreboard objectives add total_open_secs dummy
scoreboard objectives add time_open_mins dummy
scoreboard objectives add time_open_hrs dummy
scoreboard objectives add park_resetting dummy
scoreboard objectives add dinocaught dummy
scoreboard objectives add dinocheck dummy
scoreboard objectives add vis dummy

scoreboard objectives add park_open dummy
scoreboard objectives add no_fix_msg dummy
scoreboard objectives add storm_active dummy
scoreboard objectives add islandSamples dummy
scoreboard objectives add quickbuild dummy

scoreboard players set @e[tag=disaster_system] tierPoints 0
scoreboard players set @e[tag=disaster_system] countdown 0

scoreboard players set @e[tag=disaster_system] time_open_secs 0
scoreboard players set @e[tag=disaster_system] total_open_secs 0

scoreboard players set @e[tag=disaster_system] time_open_mins 0
scoreboard players set @e[tag=disaster_system] time_open_hrs 0

scoreboard players set @e[tag=disaster_system] disaster_count 1

scoreboard players set @e[tag=disaster_system] debug 0

scoreboard players set @e[tag=disaster_system] park_open 0
scoreboard players set @e[tag=disaster_system] park_resetting 0

scoreboard players set @e[tag=disaster_system] no_fix_msg 0

scoreboard players set @e[tag=disaster_system] storm_active 0

scoreboard players set @e[tag=disaster_system] dinocaught 0
scoreboard players set @e[tag=disaster_system] dinocheck 0

#uncomment next line to turn on debug
#scoreboard players set @e[tag=disaster_system] debug 1


function PowerOutage/PowerSetup
function BreakExhibit/DamageExhibitSetup
function BreakVehicle/VehicleSetup
function Storm/StormSetup
function RogueDino/RogueDinoSetup
function Saboteur/SaboteurSetup
function Music/MusicSetup

function Hype/HypeSetup
function QuickbuildReset
function HotelMonoSetup
function Breadcrumb/reset

#Welcome to Jurasic World text
setblock 348 8 -420 redstone_block

#Park Open Lever
setblock 342 55 -432 air

#Enable Reminder
setblock 344 8 -424 air

function ColdStorage/Reset
function EggRoom/Reset

function Expeditions/ExpeditionSetup

time set 0

tag @e[type=jurassic_world:robotic_arm_2_amber] remove done
tag @e[type=jurassic_world:robotic_arm_2_fossil] remove done