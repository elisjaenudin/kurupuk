

setblock 342 55 -432 lever 5

playsound stinger.disaster.02 @a

function ParkReset
setblock 378 1 -464 air
titleraw @a times 1 60 1
titleraw @a subtitle {"rawtext":[{"translate":"jw:park_shutdown.subtitle"}]}
titleraw @a title {"rawtext":[{"translate":"jw:park_shutdown.title"}]}
scoreboard players set @e[tag=disaster_system] park_open 0