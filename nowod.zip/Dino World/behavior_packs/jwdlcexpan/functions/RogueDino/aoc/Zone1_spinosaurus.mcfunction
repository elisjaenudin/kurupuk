#=========================== Zone 1 Spinosaurus escape =================

#dino spawn
summon jurassic_world:spinosaurus 516 20 -70 jw:escaped
execute @e[type=jurassic_world:spinosaurus,x=516,y=20,z=-70,r=2] 516 20 -70 tag @s add dino_escaped
execute @e[type=jurassic_world:spinosaurus,x=516,y=20,z=-70,r=2] 516 20 -70 tag @s add zone1_roguedino

scoreboard players set @e[tag=dino_zone_math] zone1loaded 1
scoreboard players set @e[tag=dino_zone_math] z1_dinos_left 1

#add entity from the map
summon jw:disaster 349 55.4 -441
execute @e[type=jw:disaster,x=349,y=55.4,z=-441,r=1] 349 55.4 -441 tag @s add dis_dino_escapez1