#=========================== Zone 2 T-rex escape =================

#dino spawn
summon jurassic_world:tyrannosaurus_rex 165 58 -329 jw:escaped
execute @e[type=jurassic_world:tyrannosaurus_rex,x=165,y=58,z=-329,r=2] 165 58 -329 tag @s add dino_escaped
execute @e[type=jurassic_world:tyrannosaurus_rex,x=165,y=58,z=-329,r=2] 165 58 -329 tag @s add zone2_roguedino

scoreboard players set @e[tag=dino_zone_math] zone2loaded 1
scoreboard players set @e[tag=dino_zone_math] z2_dinos_left 1

#add entity from the map
summon jw:disaster 346.7 57.6 -441
execute @e[type=jw:disaster,x=346.7,y=57.6,z=-441,r=1] 346.7 57.6 -441 tag @s add dis_dino_escapez2