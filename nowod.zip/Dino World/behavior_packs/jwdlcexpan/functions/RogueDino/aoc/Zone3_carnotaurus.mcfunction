#=========================== Zone 3 Carnotaurus =================

#dino spawn
summon jurassic_world:carnotaurus 617 42 -624 jw:escaped
execute @e[type=jurassic_world:carnotaurus,x=617,y=42,z=-624,r=2] 617 42 -624 tag @s add dino_escaped
execute @e[type=jurassic_world:carnotaurus,x=617,y=42,z=-624,r=2] 617 42 -624 tag @s add zone3_roguedino

scoreboard players set @e[tag=dino_zone_math] zone3loaded 1
scoreboard players set @e[tag=dino_zone_math] z3_dinos_left 1

#add entity from the map
summon jw:disaster 350.3 59.9 -441
execute @e[type=jw:disaster,x=350.3,y=59.9,z=-441,r=1] 350.3 59.9 -441 tag @s add dis_dino_escapez3