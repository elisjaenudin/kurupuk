#reset function
scoreboard players set @e[tag=dino_zone_math] z1_dino_active 0
scoreboard players set @e[tag=dino_zone_math] z2_dino_active 0
scoreboard players set @e[tag=dino_zone_math] z3_dino_active 0
scoreboard players set @e[tag=dino_zone_math] zonePicked 0
scoreboard players set @e[tag=dino_zone_math] zone_random 0
scoreboard players set @e[tag=dino_zone_math] z1_dinos_left 0
scoreboard players set @e[tag=dino_zone_math] z2_dinos_left 0
scoreboard players set @e[tag=dino_zone_math] z3_dinos_left 0

#un-suppress the messaging for fixing disasters
scoreboard players set @e[tag=dino_zone_math] no_fix_msg 0

#turn this off
setblock 358 1 -442 air