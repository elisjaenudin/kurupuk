tickingarea remove dinozone1

#turn off this block
setblock 360 1 -466 air