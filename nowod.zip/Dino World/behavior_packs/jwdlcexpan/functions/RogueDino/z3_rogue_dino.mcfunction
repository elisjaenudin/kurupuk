#debug 
#execute @e[tag=dino_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 3 Asset Out Of Containment

#prevent redstone retriggering zone selection
execute @e[tag=dino_zone_math,scores={z3_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=dino_zone_math,scores={zone3loaded=0,z3_dino_active=0}] ~ ~ ~ /setblock 360 1 -479 air

#===set one loose===
execute @e[tag=dino_zone_math,scores={zone3loaded=0,z3_dino_active=0}] ~ ~ ~ detect 617 41 -624 grass 0 /function RogueDino/aoc/Zone3_carnotaurus
#====================

#message Sector 3 disaster
execute @e[tag=dino_zone_math,scores={zone3loaded=1,z3_dino_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.aoc3event.chat"}]}

#start check for solution
execute @e[tag=dino_zone_math,scores={zone3loaded=1,z3_dino_active=0}] ~ ~ ~ /setblock 360 1 -448 redstone_block

#stop this block
execute @e[tag=dino_zone_math,scores={zone3loaded=1,z3_dino_active=0}] ~ ~ ~ /setblock 360 1 -451 air

#----------------turn off ticking area
execute @e[tag=dino_zone_math,scores={zone3loaded=1,z3_dino_active=0}] ~ ~ ~ /tickingarea remove dinozone3

#add this to total disaster count
execute @e[tag=dino_zone_math,scores={zone3loaded=1,z3_dino_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=dino_zone_math,scores={zone3loaded=1,z3_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] z3_dino_active 1

#reset zone3loaded
execute @e[tag=dino_zone_math,scores={zone3loaded=1,z3_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zone3loaded 0