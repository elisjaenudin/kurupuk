#if all zones are active, stop looping to find a power zone
setblock 360 1 -479 air

#also call a different disaster
function FindTier

#debug
#say finding new disaster

#make sure we don't call this more than once due to redstone power
scoreboard players set @e[tag=dino_zone_math] zonePicked 1