#create the ticking zone
tickingarea add circle 165 58 -329 1 dinozone2

#turn off block for finding dinosaur to spawn
setblock 360 1 -479 air

#activate the redstone block for spawning dino
setblock 360 1 -463 redstone_block

#reset zone2loaded
scoreboard players set @e[tag=dino_zone_math] zone2loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=dino_zone_math] zonePicked 1

#add indicator
clone 365 1 -425 372 15 -432 165 140 -329 replace force

#play disaster sound
playsound stinger.disaster.01 @a