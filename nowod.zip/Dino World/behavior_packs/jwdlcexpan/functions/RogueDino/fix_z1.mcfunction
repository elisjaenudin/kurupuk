#if we aren't active, turn off the redstone block for this command block (which is also reset in this case)
execute @e[tag=dino_zone_math,scores={z1_dino_active=0}] ~ ~ ~ /setblock 360 1 -469 air

#turn off solution check
execute @e[tag=dino_zone_math,scores={z1_dino_active=0}] ~ ~ ~ /setblock 360 1 -472 air
#------------------------------------------end inactive precautions-------------------------

#create ticking zone for zone 1
execute @e[tag=dino_zone_math,scores={zone1loaded=0,z1_dino_active=1}] ~ ~ ~ /tickingarea add circle 516 20 -70 4 dinozone1
execute @e[tag=dino_zone_math,scores={zone1loaded=0,z1_dino_active=1}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zone1loaded 1

#get rid of dinosaur
execute @e[tag=dino_zone_math,scores={zone1loaded=1, z1_dino_active=1}] ~ ~ ~ detect 516 19 -70 grass 0 /scoreboard players set @e[tag=dino_zone_math] zone1loaded 2
execute @e[tag=dino_zone_math,scores={zone1loaded=2, z1_dino_active=1}] ~ ~ ~ /tp @e[tag=zone1_roguedino] 403 2 -479
execute @e[tag=dino_zone_math,scores={zone1loaded=2, z1_dino_active=1}] ~ ~ ~ /kill @e[tag=zone1_roguedino]

#remove indicator
clone 367 1 -434 374 15 -441 516 140 -70 replace force

#fix message
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.aoc1fix.subtitle"}]}
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#turn off solution check
execute @e[tag=dino_zone_math,scores={zone1loaded=2, z1_dino_active=1}] ~ ~ ~ /setblock 360 1 -472 air

#stop this block
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1}] ~ ~ ~ /setblock 360 1 -469 air

#stop ticking area
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1}] ~ ~ ~ /tickingarea remove dinozone1

#remove this from total disaster count
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1}] ~ ~ ~ /setblock 360 1 -466 redstone_block

#reset zone 1 loaded 
execute @e[tag=dino_zone_math,scores={zone1loaded=2,z1_dino_active=1}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zone1loaded 0

#mark z1 inactive
execute @e[tag=dino_zone_math,scores={zone1loaded=0,z1_dino_active=1}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] z1_dino_active 0

#remove entity from the map
kill @e[tag=dis_dino_escapez1]