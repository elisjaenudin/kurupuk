execute @e[tag=dino_zone_math] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] fixedCheck 0

execute @e[tag=zone1_roguedino,x=395,y=1,z=-479,r=10] ~ ~ ~ /scoreboard players add @e[tag=dino_zone_math] fixedCheck 1

#remove tag so that it won't get killed if you solve the disaster manually and have teleported the dinosaur
execute @e[tag=dino_zone_math,scores={fixedCheck=1}] ~ ~ ~ /tag @e[tag=zone1_roguedino] remove zone1_roguedino

# set off fix z1 block if dino was teleported
execute @e[tag=dino_zone_math,scores={fixedCheck=1}] ~ ~ ~ /setblock 360 1 -469 redstone_block

# set off fix z1 block if dino was killed
execute @e[tag=dino_zone_math,scores={z1_dinos_left=0}] ~ ~ ~ /setblock 360 1 -469 redstone_block