#debug
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Dinosaur on the loose!

#=======================================================
#check if all zones are active, and if they are, call a different disaster
execute @e[tag=dino_zone_math,scores={z1_dino_active=1,z2_dino_active=1,z3_dino_active=1,zonePicked=0}] ~ ~ ~ /function RogueDino/CheckActive
#=======================================================

#loop if zones arent full, until we choose a zone thats not populated
scoreboard players random @e[tag=dino_zone_math] zone_random 1 3

#===zone1===
#if zone 1 chosen and not already active, power the command block with /function z1_rogue_dino
execute @e[tag=dino_zone_math,scores={zone_random=1..1,z1_dino_active=0,zonePicked=0}] ~ ~ ~ /function RogueDino/cause_z1_dino



#===zone2===
#if zone 2 chosen and not already active, power the command block with /function z2_rogue_dino
execute @e[tag=dino_zone_math,scores={zone_random=2..2,z2_dino_active=0,zonePicked=0}] ~ ~ ~ /function RogueDino/cause_z2_dino


#===zone3===
#if zone 3 chosen and not already active, power the command block with /function z3_rogue_dino
execute @e[tag=dino_zone_math,scores={zone_random=3..3,z3_dino_active=0,zonePicked=0}] ~ ~ ~ /function RogueDino/cause_z3_dino



#=======================================================