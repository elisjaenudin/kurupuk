#debug 
#execute @e[tag=dino_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 1 Asset Out Of Containment

#prevent redstone retriggering zone selection
execute @e[tag=dino_zone_math,scores={z1_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=dino_zone_math,scores={zone1loaded=0,z1_dino_active=0}] ~ ~ ~ /setblock 360 1 -479 air

#===set one loose===
execute @e[tag=dino_zone_math,scores={zone1loaded=0,z1_dino_active=0}] ~ ~ ~ detect 516 19 -70 grass 0 /function RogueDino/aoc/Zone1_spinosaurus
#====================

#message Sector 1 disaster
execute @e[tag=dino_zone_math,scores={zone1loaded=1,z1_dino_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.aoc1event.chat"}]}

#start check for solution
execute @e[tag=dino_zone_math,scores={zone1loaded=1,z1_dino_active=0}] ~ ~ ~ /setblock 360 1 -472 redstone_block

#stop this block
execute @e[tag=dino_zone_math,scores={zone1loaded=1,z1_dino_active=0}] ~ ~ ~ /setblock 360 1 -476 air

#----------------turn off ticking area
execute @e[tag=dino_zone_math,scores={zone1loaded=1,z1_dino_active=0}] ~ ~ ~ /tickingarea remove dinozone1

#add this to total disaster count
execute @e[tag=dino_zone_math,scores={zone1loaded=1,z1_dino_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=dino_zone_math,scores={zone1loaded=1,z1_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] z1_dino_active 1

#reset zone1loaded
execute @e[tag=dino_zone_math,scores={zone1loaded=1,z1_dino_active=1}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zone1loaded 0