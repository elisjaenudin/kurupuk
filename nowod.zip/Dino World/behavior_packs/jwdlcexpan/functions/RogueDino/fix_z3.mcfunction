#if we aren't active, turn off the redstone block for this command block
execute @e[tag=dino_zone_math,scores={z3_dino_active=0}] ~ ~ ~ /setblock 360 1 -445 air

#turn off reset block
execute @e[tag=dino_zone_math,scores={z3_dino_active=0}] ~ ~ ~ /setblock 358 1 -445 air

#turn off solution check
execute @e[tag=dino_zone_math,scores={z3_dino_active=0}] ~ ~ ~ /setblock 360 1 -448 air
#------------------------------------------end inactive precautions-------------------------

#create ticking zone for zone 1
execute @e[tag=dino_zone_math,scores={zone3loaded=0,z3_dino_active=1}] ~ ~ ~ /tickingarea add circle 516 20 -70 4 dinozone1
execute @e[tag=dino_zone_math,scores={zone3loaded=0,z3_dino_active=1}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zone3loaded 1

#get rid of dinosaur
execute @e[tag=dino_zone_math,scores={zone3loaded=1, z3_dino_active=1}] ~ ~ ~ detect 617 41 -624 grass 0 /scoreboard players set @e[tag=dino_zone_math] zone3loaded 2
execute @e[tag=dino_zone_math,scores={zone3loaded=2, z3_dino_active=1}] ~ ~ ~ /tp @e[tag=zone3_roguedino] 403 2 -479
execute @e[tag=dino_zone_math,scores={zone3loaded=2, z3_dino_active=1}] ~ ~ ~ /kill @e[tag=zone3_roguedino]

#remove indicator
clone 367 1 -434 374 15 -441 617 140 -624 replace force

#fix message
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.aoc3fix.subtitle"}]}
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a


#turn off solution check
execute @e[tag=dino_zone_math,scores={zone3loaded=2, z3_dino_active=1}] ~ ~ ~ /setblock 360 1 -448 air

#stop this block
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1}] ~ ~ ~ /setblock 360 1 -445 air

#stop reset block
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1}] ~ ~ ~ /setblock 358 1 -445 air

#stop ticking area
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1}] ~ ~ ~ /tickingarea remove dinozone1

#remove this from total disaster count
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1}] ~ ~ ~ /setblock 360 1 -442 redstone_block

#reset zone 3 loaded 
execute @e[tag=dino_zone_math,scores={zone3loaded=2,z3_dino_active=1}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zone3loaded 0

#mark z3 inactive
execute @e[tag=dino_zone_math,scores={zone3loaded=0,z3_dino_active=1}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] z3_dino_active 0

#remove entity from the map
kill @e[tag=dis_dino_escapez3]