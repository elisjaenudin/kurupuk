tickingarea remove dinozone3

#turn off this block
setblock 360 1 -442 air