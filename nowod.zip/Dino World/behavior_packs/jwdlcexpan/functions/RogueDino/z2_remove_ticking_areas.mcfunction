tickingarea remove dinozone2

#turn off this block
setblock 360 1 -454 air