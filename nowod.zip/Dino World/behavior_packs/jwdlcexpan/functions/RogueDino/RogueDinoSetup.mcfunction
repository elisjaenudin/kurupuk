#Rogue Dinosaur Setup
scoreboard objectives add z1_dino_active dummy
scoreboard objectives add z2_dino_active dummy
scoreboard objectives add z3_dino_active dummy
scoreboard objectives add z1_dinos_left dummy
scoreboard objectives add z2_dinos_left dummy
scoreboard objectives add z3_dinos_left dummy
scoreboard objectives add random_event dummy

scoreboard players set @e[tag=dino_zone_math] z1_dino_active 0

scoreboard players set @e[tag=dino_zone_math] z2_dino_active 0

scoreboard players set @e[tag=dino_zone_math] z3_dino_active 0

scoreboard players set @e[tag=dino_zone_math] zonePicked 0
scoreboard players set @e[tag=dino_zone_math] zone_random 0

scoreboard players set @e[tag=dino_zone_math] z1_dinos_left 0
scoreboard players set @e[tag=dino_zone_math] z2_dinos_left 0
scoreboard players set @e[tag=dino_zone_math] z3_dinos_left 0


scoreboard players set @e[tag=dino_zone_math] no_fix_msg 0
