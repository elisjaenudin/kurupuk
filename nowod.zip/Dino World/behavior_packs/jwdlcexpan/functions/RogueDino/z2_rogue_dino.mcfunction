#debug 
#execute @e[tag=dino_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 2 Asset Out Of Containment

#prevent redstone retriggering zone selection
execute @e[tag=dino_zone_math,scores={z2_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zonePicked 1

#a zone was chosen so stop looking for a zone
execute @e[tag=dino_zone_math,scores={zone2loaded=0,z2_dino_active=0}] ~ ~ ~ /setblock 360 1 -479 air

#===set one loose===
execute @e[tag=dino_zone_math,scores={zone2loaded=0,z2_dino_active=0}] ~ ~ ~ detect 165 57 -329 grass 0 /function RogueDino/aoc/Zone2_trex
#====================

#message Sector 2 disaster
execute @e[tag=dino_zone_math,scores={zone2loaded=1,z2_dino_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.aoc2event.chat"}]}

#start check for solution
execute @e[tag=dino_zone_math,scores={zone2loaded=1,z2_dino_active=0}] ~ ~ ~ /setblock 360 1 -460 redstone_block

#stop this block
execute @e[tag=dino_zone_math,scores={zone2loaded=1,z2_dino_active=0}] ~ ~ ~ /setblock 360 1 -463 air

#----------------turn off ticking area
execute @e[tag=dino_zone_math,scores={zone2loaded=1,z2_dino_active=0}] ~ ~ ~ /tickingarea remove dinozone2

#add this to total disaster count
execute @e[tag=dino_zone_math,scores={zone2loaded=1,z2_dino_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=dino_zone_math,scores={zone2loaded=1,z2_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] z2_dino_active 1

#reset zone2loaded
execute @e[tag=dino_zone_math,scores={zone2loaded=1,z2_dino_active=0}] ~ ~ ~ /scoreboard players set @e[tag=dino_zone_math] zone2loaded 0