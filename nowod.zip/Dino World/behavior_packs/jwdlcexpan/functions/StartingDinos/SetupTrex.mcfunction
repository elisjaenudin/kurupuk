#Setup Trex

tp @s 312 54 -340

summon jurassic_world:rexy 311 43 -324 jw:adult