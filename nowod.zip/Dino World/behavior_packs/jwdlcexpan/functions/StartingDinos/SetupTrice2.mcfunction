#Setup Trice2

tp @s 632 26 -326

summon jurassic_world:triceratops 599 18 -374 jw:adult
tag @e[type=jurassic_world:triceratops, x=599, y=18, z=-374,r=1] add starting_dino
summon jurassic_world:triceratops 614 18 -312 jw:adult
tag @e[type=jurassic_world:triceratops, x=614, y=18, z=-312,r=1] add starting_dino
summon jurassic_world:triceratops 657 18 -300 jw:adult
tag @e[type=jurassic_world:triceratops, x=657, y=18, z=-300,r=1] add starting_dino