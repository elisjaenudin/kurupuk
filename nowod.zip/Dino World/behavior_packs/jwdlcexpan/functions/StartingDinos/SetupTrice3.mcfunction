#Setup Brachi

tp @s 435 52 -333

summon jurassic_world:baby_triceratops 445 48 -335
tag @e[type=jurassic_world:baby_triceratops, x=445, y=48, z=-335,r=1] add starting_dino
summon jurassic_world:baby_triceratops 443 48 -321
tag @e[type=jurassic_world:baby_triceratops, x=443, y=48, z=-321,r=1] add starting_dino