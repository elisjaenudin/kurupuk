#Setup Galli

tp @s 509 37 -454

summon jurassic_world:gallimimus 481 36 -567 jw:adult
tag @e[type=jurassic_world:gallimimus, x=481, y=36, z=-567,r=1] add starting_dino
summon jurassic_world:gallimimus 475 36 -563 jw:adult
tag @e[type=jurassic_world:gallimimus, x=475, y=36, z=-563,r=1] add starting_dino
summon jurassic_world:gallimimus 480 36 -555 jw:adult
tag @e[type=jurassic_world:gallimimus, x=480, y=36, z=-555,r=1] add starting_dino
summon jurassic_world:gallimimus 538 37 -552 jw:adult
tag @e[type=jurassic_world:gallimimus, x=538, y=37, z=-552,r=1] add starting_dino
summon jurassic_world:gallimimus 541 37 -548 jw:adult
tag @e[type=jurassic_world:gallimimus, x=541, y=37, z=-548,r=1] add starting_dino
summon jurassic_world:gallimimus 497 36 -493 jw:adult
tag @e[type=jurassic_world:gallimimus, x=497, y=36, z=-493,r=1] add starting_dino
summon jurassic_world:gallimimus 490 36 -489 jw:adult
tag @e[type=jurassic_world:gallimimus, x=490, y=36, z=-489,r=1] add starting_dino
summon jurassic_world:gallimimus 493 36 -484 jw:adult
tag @e[type=jurassic_world:gallimimus, x=493, y=36, z=-484,r=1] add starting_dino
summon jurassic_world:gallimimus 525 38 -405 jw:adult
tag @e[type=jurassic_world:gallimimus, x=525, y=38, z=-405,r=1] add starting_dino
summon jurassic_world:gallimimus 521 38 -398 jw:adult
tag @e[type=jurassic_world:gallimimus, x=521, y=38, z=-398,r=1] add starting_dino
summon jurassic_world:gallimimus 523 38 -394 jw:adult
tag @e[type=jurassic_world:gallimimus, x=523, y=38, z=-39,r=1] add starting_dino
summon jurassic_world:gallimimus 528 39 -359 jw:adult
tag @e[type=jurassic_world:gallimimus, x=528, y=39, z=-359,r=1] add starting_dino
summon jurassic_world:gallimimus 523 40 -350 jw:adult
tag @e[type=jurassic_world:gallimimus, x=523, y=40, z=-350,r=1] add starting_dino
summon jurassic_world:gallimimus 516 40 -358 jw:adult
tag @e[type=jurassic_world:gallimimus, x=516, y=40, z=-358,r=1] add starting_dino