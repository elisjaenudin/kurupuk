#Setup Trice1

tp @s 180 39 -634

summon jurassic_world:triceratops 191 39 -647 jw:adult
tag @e[type=jurassic_world:triceratops, x=119, y=39, z=-647,r=1] add starting_dino
summon jurassic_world:triceratops 180 39 -679 jw:adult
tag @e[type=jurassic_world:triceratops, x=180, y=39, z=-679,r=1] add starting_dino
summon jurassic_world:triceratops 179 39 -704 jw:adult
tag @e[type=jurassic_world:triceratops, x=179, y=39, z=-704,r=1] add starting_dino
summon jurassic_world:triceratops 172 33 -559 jw:adult
tag @e[type=jurassic_world:triceratops, x=172, y=33, z=-559,r=1] add starting_dino
summon jurassic_world:triceratops 174 33 -586 jw:adult
tag @e[type=jurassic_world:triceratops, x=174, y=33, z=-586,r=1] add starting_dino