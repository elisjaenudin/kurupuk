#Setup Brachi

tp @s 675 30 -447

summon jurassic_world:dimorphodon 661 36 -449 jw:adult
tag @e[type=jurassic_world:dimorphodon, x=661, y=36, z=-449,r=1] add starting_dino
summon jurassic_world:dimorphodon 629 20 -446 jw:adult
tag @e[type=jurassic_world:dimorphodon, x=629, y=20, z=-446,r=1] add starting_dino
summon jurassic_world:dimorphodon 652 17 -426 jw:adult
tag @e[type=jurassic_world:dimorphodon, x=652, y=17, z=-426,r=1] add starting_dino
summon jurassic_world:dimorphodon 661 36 -424 jw:adult
tag @e[type=jurassic_world:dimorphodon, x=661, y=36, z=-424,r=1] add starting_dino
summon jurassic_world:dimorphodon 682 33 -417 jw:adult
tag @e[type=jurassic_world:dimorphodon, x=682, y=33, z=-417,r=1] add starting_dino