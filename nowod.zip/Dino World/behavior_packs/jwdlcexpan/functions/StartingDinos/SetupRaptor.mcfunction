#Setup veloc

tp @s 822 60 -498

summon jurassic_world:blue 829 53 -500 jw:adult
summon jurassic_world:velociraptor 816 53 -503 jw:adult
tag @e[type=jurassic_world:velociraptor, x=816, y=53, z=-503,r=1] add starting_dino
summon jurassic_world:velociraptor 822 53 -506 jw:adult
tag @e[type=jurassic_world:velociraptor, x=822, y=53, z=-506,r=1] add starting_dino
summon jurassic_world:velociraptor 825 53 -491 jw:adult
tag @e[type=jurassic_world:velociraptor, x=825, y=53, z=-491,r=1] add starting_dino