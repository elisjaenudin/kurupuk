#Setup Brachi

tp @s 278 46 -554

summon jurassic_world:brachiosaurus 252 43 -558 jw:adult
tag @e[type=jurassic_world:brachiosaurus, x=252, y=43, z=-558,r=1] add starting_dino
summon jurassic_world:brachiosaurus 272 43 -563 jw:adult
tag @e[type=jurassic_world:brachiosaurus, x=272, y=43, z=-563,r=1] add starting_dino
summon jurassic_world:brachiosaurus 296 43 -585 jw:adult
tag @e[type=jurassic_world:brachiosaurus, x=296, y=43, z=-585,r=1] add starting_dino