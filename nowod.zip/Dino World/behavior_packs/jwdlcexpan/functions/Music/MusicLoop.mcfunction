#intro music
execute @e[tag=disaster_system,scores={ridestart=1,rideover=0}] ~ ~ ~ /tag @s[tag=!DisasterMusic,scores={current_list=!4}] add ChangeMusic
execute @e[tag=ChangeMusic,scores={current_list=!4,ridestart=1,rideover=0}] ~ ~ ~ /scoreboard players set @s current_list 4

#park open
execute @e[tag=disaster_system,scores={park_open=1,rideover=1}] ~ ~ ~ /tag @s[tag=!DisasterMusic,scores={current_list=!1}] add ChangeMusic
execute @e[tag=ChangeMusic,scores={current_list=!1,park_open=1}] ~ ~ ~ /scoreboard players set @s current_list 1

#park closed
execute @e[tag=disaster_system,scores={park_open=0,rideover=1}] ~ ~ ~ /tag @s[tag=!DisasterMusic,scores={current_list=!2}] add ChangeMusic
execute @e[tag=ChangeMusic,scores={current_list=!2,park_open=0,rideover=1}] ~ ~ ~ /scoreboard players set @s current_list 2

#expeditions
scoreboard players set @e[tag=disaster_system] numexp 0
execute @a[tag=inJungle] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] numexp 1
execute @a[tag=inDesert] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] numexp 1

execute @e[tag=disaster_system,scores={numexp=1..,rideover=1}] ~ ~ ~ /tag @s[tag=!DisasterMusic,scores={current_list=!3}] add ChangeMusic
execute @e[tag=ChangeMusic,scores={current_list=!3,numexp=1..}] ~ ~ ~ /scoreboard players set @s current_list 3


#reset track selection if we move to another area
execute @e[tag=ChangeMusic,scores={next_track=!1}] ~ ~ ~ /scoreboard players set @s next_track 1

#if we return to the area where we are already playing music for, resume playing that playlist
#last_area_play=current_list, need to reset next_track to be current track + 1
execute @e[tag=ChangeMusic] ~ ~ ~ /scoreboard players operation @s continue_check = @s last_area_play
execute @e[tag=ChangeMusic] ~ ~ ~ /scoreboard players operation @s continue_check -= @s current_list
execute @e[tag=ChangeMusic,scores={continue_check=0}] ~ ~ ~ /scoreboard players operation @s next_track = @s current_track
execute @e[tag=ChangeMusic,scores={continue_check=0}] ~ ~ ~ /scoreboard players add @s next_track 1


#wrap around if next_track > # of tracks 
execute @e[scores={current_list=1,next_track=8}] ~ ~ ~ /scoreboard players set @s next_track 1
execute @e[scores={current_list=2,next_track=7}] ~ ~ ~ /scoreboard players set @s next_track 1
execute @e[scores={current_list=3,next_track=4}] ~ ~ ~ /scoreboard players set @s next_track 1

execute @e[tag=ChangeMusic] ~ ~ ~ /tag @s remove ChangeMusic

#check for disaster music change
#execute @e[tag=disaster_system,scores={disaster_count=2..}] ~ ~ ~ /execute @e[tag=!DisasterMusic] ~ ~ ~ /scoreboard players set @s next_track 1
#execute @e[tag=disaster_system,scores={disaster_count=2..}] ~ ~ ~ /tag @e add DisasterMusic

#reset to normal music
#execute @e[tag=disaster_system,scores={disaster_count=1}] ~ ~ ~ /scoreboard players set @e[tag=DisasterMusic] next_track 1
#execute @e[tag=disaster_system,scores={disaster_count=1}] ~ ~ ~ /tag @e[tag=DisasterMusic] remove DisasterMusic

#wrap around if disaster
#execute @e[tag=DisasterMusic,scores={next_track=3}] ~ ~ ~ /scoreboard players set @s next_track 1


#----------------------Park Open----------------------------------------


#determine which song to switch to
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=1,next_track=1}] ~ ~ ~ /tag @s add area1track1
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=1,next_track=2}] ~ ~ ~ /tag @s add area1track2
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=1,next_track=3}] ~ ~ ~ /tag @s add area1track3
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=1,next_track=4}] ~ ~ ~ /tag @s add area1track4
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=1,next_track=5}] ~ ~ ~ /tag @s add area1track5
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=1,next_track=6}] ~ ~ ~ /tag @s add area1track6
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=1,next_track=7}] ~ ~ ~ /tag @s add area1track7

#song 1
execute @e[tag=area1track1] ~ ~ ~ /playsound music.park.open.01 @a
execute @e[tag=area1track1] ~ ~ ~ /scoreboard players set @s music_time_left 97
execute @e[tag=area1track1] ~ ~ ~ /scoreboard players set @s current_track 1
execute @e[tag=area1track1] ~ ~ ~ /scoreboard players set @s last_area_play 1
execute @e[tag=area1track1] ~ ~ ~ /scoreboard players set @s next_track 2
execute @e[tag=area1track1] ~ ~ ~ /tag @s remove area1track1

#song 2
execute @e[tag=area1track2] ~ ~ ~ /playsound music.park.open.02 @a
execute @e[tag=area1track2] ~ ~ ~ /scoreboard players set @s music_time_left 106
execute @e[tag=area1track2] ~ ~ ~ /scoreboard players set @s current_track 2
execute @e[tag=area1track2] ~ ~ ~ /scoreboard players set @s last_area_play 1
execute @e[tag=area1track2] ~ ~ ~ /scoreboard players set @s next_track 3
execute @e[tag=area1track2] ~ ~ ~ /tag @s remove area1track2

#song 3
execute @e[tag=area1track3] ~ ~ ~ /playsound music.park.open.03 @a
execute @e[tag=area1track3] ~ ~ ~ /scoreboard players set @s music_time_left 119
execute @e[tag=area1track3] ~ ~ ~ /scoreboard players set @s current_track 3
execute @e[tag=area1track3] ~ ~ ~ /scoreboard players set @s last_area_play 1
execute @e[tag=area1track3] ~ ~ ~ /scoreboard players set @s next_track 4
execute @e[tag=area1track3] ~ ~ ~ /tag @s remove area1track3

#song 4
execute @e[tag=area1track4] ~ ~ ~ /playsound music.park.open.04 @a
execute @e[tag=area1track4] ~ ~ ~ /scoreboard players set @s music_time_left 63
execute @e[tag=area1track4] ~ ~ ~ /scoreboard players set @s current_track 4
execute @e[tag=area1track4] ~ ~ ~ /scoreboard players set @s last_area_play 1
execute @e[tag=area1track4] ~ ~ ~ /scoreboard players set @s next_track 5
execute @e[tag=area1track4] ~ ~ ~ /tag @s remove area1track4

#song 5
execute @e[tag=area1track5] ~ ~ ~ /playsound music.park.open.05 @a
execute @e[tag=area1track5] ~ ~ ~ /scoreboard players set @s music_time_left 97
execute @e[tag=area1track5] ~ ~ ~ /scoreboard players set @s current_track 5
execute @e[tag=area1track5] ~ ~ ~ /scoreboard players set @s last_area_play 1
execute @e[tag=area1track5] ~ ~ ~ /scoreboard players set @s next_track 6
execute @e[tag=area1track5] ~ ~ ~ /tag @s remove area1track5

#song 6
execute @e[tag=area1track6] ~ ~ ~ /playsound music.park.open.06 @a
execute @e[tag=area1track6] ~ ~ ~ /scoreboard players set @s music_time_left 93
execute @e[tag=area1track6] ~ ~ ~ /scoreboard players set @s current_track 6
execute @e[tag=area1track6] ~ ~ ~ /scoreboard players set @s last_area_play 1
execute @e[tag=area1track6] ~ ~ ~ /scoreboard players set @s next_track 7
execute @e[tag=area1track6] ~ ~ ~ /tag @s remove area1track6

#song 7
execute @e[tag=area1track7] ~ ~ ~ /playsound music.park.open.07 @a
execute @e[tag=area1track7] ~ ~ ~ /scoreboard players set @s music_time_left 105
execute @e[tag=area1track7] ~ ~ ~ /scoreboard players set @s current_track 7
execute @e[tag=area1track7] ~ ~ ~ /scoreboard players set @s last_area_play 1
execute @e[tag=area1track7] ~ ~ ~ /scoreboard players set @s next_track 1
execute @e[tag=area1track7] ~ ~ ~ /tag @s remove area1track7

#----------------------Park Closed----------------------------------------

#determine which song to switch to
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=2,next_track=1}] ~ ~ ~ /tag @s add area2track1
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=2,next_track=2}] ~ ~ ~ /tag @s add area2track2
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=2,next_track=3}] ~ ~ ~ /tag @s add area2track3
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=2,next_track=4}] ~ ~ ~ /tag @s add area2track4
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=2,next_track=5}] ~ ~ ~ /tag @s add area2track5
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=2,next_track=6}] ~ ~ ~ /tag @s add area2track6

#song 1
execute @e[tag=area2track1] ~ ~ ~ /playsound music.park.closed.01 @a
execute @e[tag=area2track1] ~ ~ ~ /scoreboard players set @s music_time_left 152
execute @e[tag=area2track1] ~ ~ ~ /scoreboard players set @s current_track 1
execute @e[tag=area2track1] ~ ~ ~ /scoreboard players set @s last_area_play 2
execute @e[tag=area2track1] ~ ~ ~ /scoreboard players set @s next_track 2
execute @e[tag=area2track1] ~ ~ ~ /tag @s remove area2track1

#song 2
execute @e[tag=area2track2] ~ ~ ~ /playsound music.park.closed.02 @a
execute @e[tag=area2track2] ~ ~ ~ /scoreboard players set @s music_time_left 165
execute @e[tag=area2track2] ~ ~ ~ /scoreboard players set @s current_track 2
execute @e[tag=area2track2] ~ ~ ~ /scoreboard players set @s last_area_play 2
execute @e[tag=area2track2] ~ ~ ~ /scoreboard players set @s next_track 3
execute @e[tag=area2track2] ~ ~ ~ /tag @s remove area2track2

#song 3
execute @e[tag=area2track3] ~ ~ ~ /playsound music.park.closed.03 @a
execute @e[tag=area2track3] ~ ~ ~ /scoreboard players set @s music_time_left 71
execute @e[tag=area2track3] ~ ~ ~ /scoreboard players set @s current_track 3
execute @e[tag=area2track3] ~ ~ ~ /scoreboard players set @s last_area_play 2
execute @e[tag=area2track3] ~ ~ ~ /scoreboard players set @s next_track 4
execute @e[tag=area2track3] ~ ~ ~ /tag @s remove area2track3

#song 4
execute @e[tag=area2track4] ~ ~ ~ /playsound music.park.closed.04 @a
execute @e[tag=area2track4] ~ ~ ~ /scoreboard players set @s music_time_left 97
execute @e[tag=area2track4] ~ ~ ~ /scoreboard players set @s current_track 4
execute @e[tag=area2track4] ~ ~ ~ /scoreboard players set @s last_area_play 2
execute @e[tag=area2track4] ~ ~ ~ /scoreboard players set @s next_track 5
execute @e[tag=area2track4] ~ ~ ~ /tag @s remove area2track4

#song 5
execute @e[tag=area2track5] ~ ~ ~ /playsound music.park.closed.05 @a
execute @e[tag=area2track5] ~ ~ ~ /scoreboard players set @s music_time_left 245
execute @e[tag=area2track5] ~ ~ ~ /scoreboard players set @s current_track 5
execute @e[tag=area2track5] ~ ~ ~ /scoreboard players set @s last_area_play 2
execute @e[tag=area2track5] ~ ~ ~ /scoreboard players set @s next_track 6
execute @e[tag=area2track5] ~ ~ ~ /tag @s remove area2track5

#song 6
execute @e[tag=area2track6] ~ ~ ~ /playsound music.park.closed.06 @a
execute @e[tag=area2track6] ~ ~ ~ /scoreboard players set @s music_time_left 113
execute @e[tag=area2track6] ~ ~ ~ /scoreboard players set @s current_track 6
execute @e[tag=area2track6] ~ ~ ~ /scoreboard players set @s last_area_play 2
execute @e[tag=area2track6] ~ ~ ~ /scoreboard players set @s next_track 1
execute @e[tag=area2track6] ~ ~ ~ /tag @s remove area2track6

#----------------------Expeditions----------------------------------------

#determine which song to switch to
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=3,next_track=1}] ~ ~ ~ /tag @s add area3track1
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=3,next_track=2}] ~ ~ ~ /tag @s add area3track2
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=3,next_track=3}] ~ ~ ~ /tag @s add area3track3

#song 1
execute @e[tag=area3track1] ~ ~ ~ /playsound music.expedition.01 @a
execute @e[tag=area3track1] ~ ~ ~ /scoreboard players set @s music_time_left 99
execute @e[tag=area3track1] ~ ~ ~ /scoreboard players set @s current_track 1
execute @e[tag=area3track1] ~ ~ ~ /scoreboard players set @s last_area_play 3
execute @e[tag=area3track1] ~ ~ ~ /scoreboard players set @s next_track 2
execute @e[tag=area3track1] ~ ~ ~ /tag @s remove area3track1

#song 2
execute @e[tag=area3track2] ~ ~ ~ /playsound music.expedition.02 @a
execute @e[tag=area3track2] ~ ~ ~ /scoreboard players set @s music_time_left 106
execute @e[tag=area3track2] ~ ~ ~ /scoreboard players set @s current_track 2
execute @e[tag=area3track2] ~ ~ ~ /scoreboard players set @s last_area_play 3
execute @e[tag=area3track2] ~ ~ ~ /scoreboard players set @s next_track 3
execute @e[tag=area3track2] ~ ~ ~ /tag @s remove area3track2

#song 3
execute @e[tag=area3track3] ~ ~ ~ /playsound music.expedition.03 @a
execute @e[tag=area3track3] ~ ~ ~ /scoreboard players set @s music_time_left 122
execute @e[tag=area3track3] ~ ~ ~ /scoreboard players set @s current_track 3
execute @e[tag=area3track3] ~ ~ ~ /scoreboard players set @s last_area_play 3
execute @e[tag=area3track3] ~ ~ ~ /scoreboard players set @s next_track 1
execute @e[tag=area3track3] ~ ~ ~ /tag @s remove area3track3



#----------------------Intro----------------------------------------

#determine which song to switch to
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=4,next_track=1,ridestart=1}] ~ ~ ~ /tag @s add area4track1

#we've finished playing song so set rideover
execute @e[tag=disaster_system,scores={music_time_left=..0,current_list=4,next_track=2,ridestart=1}] ~ ~ ~ /scoreboard players set @s rideover 1


#song 1
execute @e[tag=area4track1] ~ ~ ~ /playsound music.intro.cue @a
execute @e[tag=area4track1] ~ ~ ~ /scoreboard players set @s music_time_left 184
execute @e[tag=area4track1] ~ ~ ~ /scoreboard players set @s current_track 1
execute @e[tag=area4track1] ~ ~ ~ /scoreboard players set @s last_area_play 4
execute @e[tag=area4track1] ~ ~ ~ /scoreboard players set @s next_track 2
execute @e[tag=area4track1] ~ ~ ~ /tag @s remove area4track1


#remove time
scoreboard players remove @e[tag=disaster_system,scores={ridestart=1}] music_time_left 1

#turn music on in 2 minutes if ridestart hasn't triggered
scoreboard players remove @e[tag=disaster_system,scores={ridestart=0,music_timeout=1..}] music_timeout 1

#turn on ridestart and turn off trigger check
execute @e[tag=disaster_system,scores={ridestart=0,music_timeout=0}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] ridestart 1
execute @e[tag=disaster_system,scores={ridestart=0,music_timeout=0}] ~ ~ ~ /setblock 351 1 -483 air
