
scoreboard objectives add next_track dummy
scoreboard players set @e[tag=disaster_system] next_track 0

scoreboard objectives add current_track dummy
scoreboard players set @e[tag=disaster_system] current_track 0

scoreboard objectives add current_list dummy
scoreboard players set @e[tag=disaster_system] current_list 0

scoreboard objectives add music_time_left dummy
scoreboard players set @e[tag=disaster_system] music_time_left 0

scoreboard objectives add music_timeout dummy
scoreboard players set @e[tag=disaster_system] music_timeout 120

scoreboard objectives add last_area_play dummy
scoreboard players set @e[tag=disaster_system] last_area_play 0

scoreboard objectives add continue_check dummy
scoreboard players set @e[tag=disaster_system] continue_check 0

scoreboard objectives add numexp dummy
scoreboard players set @e[tag=disaster_system] numexp 0

scoreboard objectives add ridestart dummy
scoreboard players set @e[tag=disaster_system] ridestart 0

scoreboard objectives add rideover dummy
scoreboard players set @e[tag=disaster_system] rideover 0


setblock 351 1 -483 redstone_block