# Shows the player a celebration when each of the quickbuild site on isla nublar have been built at one point
#say DEBUG celebrate quickbuilds

execute @a[scores={quickbuild=8}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.progress.all_quickbuld"}]}
execute @a[scores={quickbuild=8}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":" "}]}
execute @a[scores={quickbuild=8}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.progress.all_quickbuld"}]} 
execute @a[scores={quickbuild=8}] ~ ~ ~ /scoreboard players add @a quickbuild 1
