#===========Take Radio===============

clear @p spawn_egg 33 1