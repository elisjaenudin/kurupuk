#release dino

#no dino to set free
#execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.nodinoerror.chat"}]}
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /clear @a spawn_egg 46
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /clear @a spawn_egg 34
execute @e[tag=disaster_system,scores={dinocaught=0}] ~ ~ ~ /setblock 363 1 -483 redstone_block


#dino to set free exists, so teleport it to this location
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /tp @e[tag=caught_dino] @e[type=minecraft:stray,c=1]

#playsound
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /execute @e[tag=caught_dino] ~ ~ ~ /playsound helicopter.transition @a[r=32]

#untag dino
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /tag @e[tag=caught_dino] remove caught_dino

#make sure to get rid of spawn eggs from all players
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /clear @a spawn_egg 46

#make sure they instead have extraction beacon
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /setblock 363 1 -483 redstone_block

#clear dinocaught
execute @e[tag=disaster_system,scores={dinocaught=1}] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] dinocaught 0