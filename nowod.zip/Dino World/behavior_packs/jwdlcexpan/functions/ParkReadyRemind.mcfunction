# Notify the player that they can open the park
#say DEBUG notify

titleraw @a actionbar {"rawtext":[{"translate":"jw.progress.park_ready_long"}]}
tellraw @a {"rawtext":[{"translate":"jw.progress.park_ready_long"}]} 
