# denyAdd
# this function should be removed before shipping

execute CascadianBacon ~ ~ ~ /setblock ~ 16 ~ bedrock
execute CascadianBacon ~ ~ ~ /setblock ~ 17 ~ deny
execute CascadianBacon ~ ~ ~ /setblock ~ 140 ~ glass
say add