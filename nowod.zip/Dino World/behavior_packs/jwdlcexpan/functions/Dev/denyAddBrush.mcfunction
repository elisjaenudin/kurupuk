# denyAddBrush
# this function should be removed before shipping

execute CascadianBacon ~ ~ ~ /fill ~3 16 ~3 ~-3 16 ~-3 bedrock
execute CascadianBacon ~ ~ ~ /fill ~3 17 ~3 ~-3 17 ~-3 deny
execute CascadianBacon ~ ~ ~ /fill ~3 140 ~3 ~-3 140 ~-3 glass
say addBrush