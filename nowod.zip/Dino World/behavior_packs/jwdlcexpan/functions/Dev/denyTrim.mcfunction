# denyTrim
# this function should be removed before shipping

execute CascadianBacon ~ ~ ~ /setblock ~ 2 ~ sand
execute CascadianBacon ~ ~ ~ /setblock ~ 140 ~ air
say trim