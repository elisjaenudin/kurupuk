#===========Spinosaurus_egg===============


clone 385 8 -419 385 8 -419 352 51 -400 replace force
clone 385 5 -419 385 5 -419 352 52 -401 replace force