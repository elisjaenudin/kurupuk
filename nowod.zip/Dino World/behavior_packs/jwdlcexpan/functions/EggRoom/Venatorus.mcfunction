#===========Venatorus_egg===


clone 382 6 -423 382 6 -423 341 49 -409 replace force
clone 382 3 -423 382 3 -423 342 50 -409 replace force
