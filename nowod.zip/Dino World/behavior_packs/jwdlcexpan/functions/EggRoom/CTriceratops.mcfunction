#===========CTriceratops_egg===============


clone 390 6 -425 390 6 -425 348 49 -411 replace force
clone 390 5 -425 390 5 -425 348 52 -410 replace force
