#===========BDilophosaurus_block===============


clone 390 7 -419 390 7 -419 362 50 -400 replace force
clone 390 5 -419 390 5 -419 362 52 -401 replace force
