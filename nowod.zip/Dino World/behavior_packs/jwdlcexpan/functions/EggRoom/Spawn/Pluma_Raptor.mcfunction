#===========Pluma_Raptor_egg===

fill 405 10 -420 405 10 -420 air 0 replace redstone_block
##clone 348 1 -429 348 1 -429 397 63 -367
setblock 382 13 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

setblock 394 1 -429 redstone_block

#play disaster sound
playsound stinger.epic.03 @a