#===========Placidusaurus_egg===

fill 405 10 -419 405 10 -419 air 0 replace redstone_block 0
##clone 349 1 -429 349 1 -429 371 56 -377
setblock 382 14 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a