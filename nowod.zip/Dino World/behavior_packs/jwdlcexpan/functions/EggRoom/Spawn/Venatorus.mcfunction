#===========Venatorus_egg===

fill 405 10 -430 405 10 -430 air 0 replace redstone_block
##clone 354 1 -421 354 1 -421 397 63 -392
setblock 381 13 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a