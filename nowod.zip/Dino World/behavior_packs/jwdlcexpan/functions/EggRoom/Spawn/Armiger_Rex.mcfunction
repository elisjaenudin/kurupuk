#===========Armiger_Rex_egg===

##clone 346 1 -429 346 1 -429 377 63 -377
setblock 384 15 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
fill 405 1 -421 405 1 -421 air 0 replace redstone_block
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a