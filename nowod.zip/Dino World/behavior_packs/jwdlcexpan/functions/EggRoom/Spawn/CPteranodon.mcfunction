#===========CPteranodon_egg===============

fill 405 4 -434 405 4 -434 air 0 replace redstone_block
##clone 348 1 -421 348 1 -421 392 51 -373
setblock 381 10 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a
