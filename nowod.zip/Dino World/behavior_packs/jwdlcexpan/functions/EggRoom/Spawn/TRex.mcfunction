#===========TRex_egg===============

fill 405 10 -428 405 10 -428 air 0 replace redstone_block
setblock 386 15 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a