#===========CParasaurolophus_block===============

fill 405 4 -433 405 4 -433 air 0 replace redstone_block
##clone 356 1 -429 356 1 -429 393 51 -386
setblock 382 10 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a