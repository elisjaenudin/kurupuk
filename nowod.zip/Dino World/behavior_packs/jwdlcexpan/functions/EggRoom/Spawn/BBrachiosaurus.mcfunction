#===========BBrachiosaurus_block===============

fill 405 1 -424 405 1 -424 air 0 replace redstone_block
##clone 352 1 -421 352 1 -421 371 56 -382
setblock 388 11 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a