#===========BSpinosaurus_egg===============

fill 405 1 -432 405 1 -432 air 0 replace redstone_block
##clone 347 1 -421 347 1 -421 387 51 -373
setblock 390 14 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a