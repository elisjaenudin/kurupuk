#===========Dilophosaurus_block===============

fill 405 7 -426 405 7 -426 air 0 replace redstone_block
##clone 349 1 -421 349 1 -421 393 51 -373
setblock 385 12 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a