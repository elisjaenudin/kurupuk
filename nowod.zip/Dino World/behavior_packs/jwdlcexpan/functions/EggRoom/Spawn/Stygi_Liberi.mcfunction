#===========Stygi_Liberi_egg===

fill 405 10 -424 405 10 -424 air 0 replace redstone_block
##clone 351 1 -429 351 1 -429 396 56 -361
setblock 381 15 -419 redstone_block 0 replace
fill 342 55 -432 342 55 -432 lever 5 replace air 0
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a