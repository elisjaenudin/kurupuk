#===========Ankylosaurus_block===============

##clone 353 1 -429 353 1 -429 386 51 -386
fill 405 1 -419 405 1 -419 air 0 replace redstone_block
fill 342 55 -432 342 55 -432 lever 5 replace air 0
setblock 390 12 -419 redstone_block 0 replace
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

#play disaster sound
playsound stinger.epic.03 @a