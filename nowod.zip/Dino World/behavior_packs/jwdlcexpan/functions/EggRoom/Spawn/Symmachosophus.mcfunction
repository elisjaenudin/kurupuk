#===========Symmachosophus_egg===

fill 405 10 -426 405 10 -426 air 0 replace redstone_block
##clone 345 1 -423 345 1 -423 403 56 -366
fill 342 55 -432 342 55 -432 lever 5 replace air 0
setblock 381 14 -419 redstone_block 0 replace
titleraw @a title {"rawtext":[{"translate":"jw:dino_egg_filled"}]}
titleraw @a subtitle {"rawtext":[{"translate":"jw:dino_egg_filled2"}]}

setblock 394 1 -429 redstone_block

#play disaster sound
playsound stinger.epic.03 @a