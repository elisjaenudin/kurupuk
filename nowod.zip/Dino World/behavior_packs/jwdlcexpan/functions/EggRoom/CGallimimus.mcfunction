#===========CGallimimus_block===============


clone 388 6 -419 388 6 -419 358 49 -400 replace force
clone 388 5 -419 388 5 -419 358 52 -401 replace force
