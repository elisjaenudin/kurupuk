#===========Indoraptor_egg===


clone 382 6 -421 382 6 -421 341 49 -404 replace force
clone 382 3 -421 382 3 -421 342 50 -404 replace force

