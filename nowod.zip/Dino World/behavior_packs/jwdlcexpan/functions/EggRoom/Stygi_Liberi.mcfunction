#===========Stygi_Liberi_egg===


clone 382 8 -423 382 8 -423 341 53 -407 replace force
clone 382 5 -423 382 5 -423 342 54 -407 replace force
