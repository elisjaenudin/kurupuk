#===========CTRex_egg===============


clone 389 6 -425 389 6 -425 350 49 -411 replace force
clone 389 5 -425 389 5 -425 350 52 -410 replace force
