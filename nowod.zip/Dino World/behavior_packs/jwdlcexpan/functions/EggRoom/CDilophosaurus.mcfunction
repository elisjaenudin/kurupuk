#===========CDilophosaurus_block===============


clone 390 6 -419 390 6 -419 362 49 -400 replace force
clone 390 5 -419 390 5 -419 362 52 -401 replace force
