#===========Ankylosaurus_block===============

clone 391 7 -424 391 7 -424 366 50 -406 replace force
clone 391 5 -424 391 5 -424 365 52 -406 replace force
