#===========Ankylosaurus_block===============

clone 391 8 -424 391 8 -424 366 51 -406 replace force
clone 391 5 -424 391 5 -424 365 52 -406 replace force

