#===========CVelociraptor_egg===============


clone 388 6 -425 388 6 -425 352 49 -411 replace force
clone 388 5 -425 388 5 -425 352 52 -410 replace force
