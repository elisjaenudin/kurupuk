#===========CStegosaurus_egg===============


clone 384 6 -419 384 6 -419 350 49 -400 replace force
clone 384 5 -419 384 5 -419 350 52 -401 replace force
