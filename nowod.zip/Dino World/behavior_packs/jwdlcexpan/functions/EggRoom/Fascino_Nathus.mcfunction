#===========Fascino_Nathus_egg===


clone 382 6 -420 382 6 -420 341 49 -402 replace force
clone 382 3 -420 382 3 -420 342 50 -402 replace force

