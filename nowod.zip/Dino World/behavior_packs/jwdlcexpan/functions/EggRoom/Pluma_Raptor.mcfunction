#===========Pluma_Raptor_egg===


clone 382 6 -422 382 6 -422 341 49 -407 replace force
clone 382 3 -422 382 3 -422 342 50 -407 replace force
