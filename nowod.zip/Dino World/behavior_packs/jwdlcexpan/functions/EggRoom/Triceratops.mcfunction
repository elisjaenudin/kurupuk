#===========Triceratops_egg===============


clone 390 8 -425 390 8 -425 348 51 -411 replace force
clone 390 5 -425 390 5 -425 348 52 -410 replace force
