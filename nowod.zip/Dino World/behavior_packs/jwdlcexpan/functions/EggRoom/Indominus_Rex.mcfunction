#===========Indominus_Rex_egg===


clone 382 7 -421 382 7 -421 345 51 -400 replace force
clone 381 4 -421 381 4 -421 345 52 -401 replace force

