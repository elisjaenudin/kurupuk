#===========Stegosaurus_egg===============


clone 384 8 -419 384 8 -419 350 51 -400 replace force
clone 384 5 -419 384 5 -419 350 52 -401 replace force
