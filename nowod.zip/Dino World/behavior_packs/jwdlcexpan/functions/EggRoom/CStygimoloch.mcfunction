#===========CStygimoloch_egg===============


clone 383 6 -419 383 6 -419 348 49 -400 replace force
clone 383 5 -419 383 5 -419 348 52 -401 replace force
