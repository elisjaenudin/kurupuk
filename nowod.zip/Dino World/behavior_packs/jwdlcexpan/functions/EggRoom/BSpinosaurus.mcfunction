#===========BSpinosaurus_egg===============


clone 385 7 -419 385 7 -419 352 50 -400 replace force
clone 385 5 -419 385 5 -419 352 52 -401 replace force
