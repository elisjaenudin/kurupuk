#===========CParasaurolophus_block===============


clone 387 6 -419 387 6 -419 356 49 -400 replace force
clone 387 5 -419 387 5 -419 356 52 -401 replace force
