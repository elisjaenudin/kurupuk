#===========Dimorphodon_block===============


clone 389 8 -419 389 8 -419 360 51 -400 replace force
clone 389 5 -419 389 5 -419 360 52 -401 replace force

