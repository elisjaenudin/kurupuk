#===========CApatosaurus_block===============


clone 391 6 -423 391 6 -423 366 49 -404 replace force
clone 391 5 -423 391 5 -423 365 52 -404 replace force