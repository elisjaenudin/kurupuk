#===========CBrachiosaurus_block===============


clone 391 6 -422 391 6 -422 366 49 -402 replace force
clone 391 5 -422 391 5 -422 365 52 -402 replace force