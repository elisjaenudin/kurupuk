#===========Symmachosophus_egg===


clone 382 7 -423 382 7 -423 341 51 -409 replace force
clone 382 4 -423 382 4 -423 342 52 -409 replace force
