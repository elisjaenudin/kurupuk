#===========Claridon_egg===


clone 382 7 -420 382 7 -420 341 51 -402 replace force
clone 382 4 -420 382 4 -420 342 52 -402 replace force
