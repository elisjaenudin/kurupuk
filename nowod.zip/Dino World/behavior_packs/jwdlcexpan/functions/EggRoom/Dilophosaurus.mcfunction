#===========Dilophosaurus_block===============


clone 390 8 -419 390 8 -419 362 51 -400 replace force
clone 390 5 -419 390 5 -419 362 52 -401 replace force

