#===========Apatosaurus_block===============


clone 391 8 -423 391 8 -423 366 51 -404 replace force
clone 391 5 -423 391 5 -423 365 52 -404 replace force