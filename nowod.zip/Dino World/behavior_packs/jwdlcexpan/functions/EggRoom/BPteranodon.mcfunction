#===========BPteranodon_egg===============


clone 386 7 -419 386 7 -419 354 50 -400 replace force
clone 386 5 -419 386 5 -419 354 52 -401 replace force

