#===========CSpinosaurus_egg===============

clone 385 6 -419 385 6 -419 352 49 -400 replace force
clone 385 5 -419 385 5 -419 352 52 -401 replace force
