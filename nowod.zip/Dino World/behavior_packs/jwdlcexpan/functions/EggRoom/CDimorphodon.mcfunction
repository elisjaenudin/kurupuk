#===========CDimorphodon_block===============


clone 389 6 -419 389 6 -419 360 49 -400 replace force
clone 389 5 -419 389 5 -419 360 52 -401 replace force
