#===========BStegosaurus_egg===============


clone 384 7 -419 384 7 -419 350 50 -400 replace force
clone 384 5 -419 384 5 -419 350 52 -401 replace force
