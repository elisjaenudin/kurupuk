#===========CCompsognathus_block===============


clone 391 6 -420 391 6 -420 364 49 -400 replace force
clone 391 5 -420 391 5 -420 364 52 -401 replace force
