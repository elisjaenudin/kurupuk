#===========TRex_egg===============


clone 389 8 -425 389 8 -425 350 51 -411 replace force
clone 389 5 -425 389 5 -425 350 52 -410 replace force

