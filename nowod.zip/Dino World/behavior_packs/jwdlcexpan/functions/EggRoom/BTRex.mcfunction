#===========BTRex_egg===============


clone 389 7 -425 389 7 -425 350 50 -411 replace force
clone 389 5 -425 389 5 -425 350 52 -410 replace force
