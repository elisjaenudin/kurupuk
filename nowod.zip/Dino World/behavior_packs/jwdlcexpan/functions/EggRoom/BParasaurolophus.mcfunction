#===========BParasaurolophus_block===============


clone 387 7 -419 387 7 -419 356 50 -400 replace force
clone 387 5 -419 387 5 -419 356 52 -401 replace force
