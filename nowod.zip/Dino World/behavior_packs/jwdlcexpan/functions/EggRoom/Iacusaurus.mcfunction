#===========Iacusaurus_egg===


clone 382 8 -421 382 8 -421 341 53 -404 replace force
clone 382 5 -421 382 5 -421 342 54 -404 replace force
