#===========Stygimoloch_egg===============


clone 383 8 -419 383 8 -419 348 51 -400 replace force
clone 383 5 -419 383 5 -419 348 52 -401 replace force