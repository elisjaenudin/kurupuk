#===========Reset===============

fill 405 10 -453 405 1 -438 air 0 replace redstone_block 0
fill 405 1 -434 405 1 -419 redstone_block 0 replace air 0
fill 405 4 -434 405 4 -419 redstone_block 0 replace air 0
fill 405 7 -434 405 7 -419 redstone_block 0 replace air 0
fill 405 10 -430 405 10 -419 redstone_block 0 replace air 0
fill 390 10 -419 381 15 -419 air 0 replace redstone_block 0
clone 380 7 -420 380 9 -420 366 49 -406 replace force
clone 380 7 -420 380 9 -420 366 49 -404 replace force
clone 380 7 -420 380 9 -420 366 49 -402 replace force
clone 379 7 -419 379 9 -419 364 49 -400 replace force
#clone 380 7 -420 380 9 -420 364 49 -402 replace force
clone 379 7 -419 379 9 -419 362 49 -400 replace force
clone 379 7 -419 379 9 -419 360 49 -400 replace force
clone 379 7 -419 379 9 -419 358 49 -400 replace force
clone 379 7 -419 379 9 -419 356 49 -400 replace force
clone 379 7 -419 379 9 -419 354 49 -400 replace force 
clone 379 7 -419 379 9 -419 352 49 -400 replace force
clone 379 7 -419 379 9 -419 350 49 -400 replace force
clone 379 7 -419 379 9 -419 348 49 -400 replace force
clone 379 7 -421 379 9 -421 346 49 -411 replace force
clone 379 7 -421 379 9 -421 348 49 -411 replace force
clone 379 7 -421 379 9 -421 350 49 -411 replace force
clone 379 7 -421 379 9 -421 352 49 -411 replace force
clone 378 7 -420 378 7 -420 341 49 -409 replace force
clone 378 7 -420 378 7 -420 341 51 -409 replace force
clone 378 7 -420 378 7 -420 341 49 -407 replace force
clone 378 7 -420 378 7 -420 341 51 -407 replace force
clone 378 7 -420 378 7 -420 341 53 -407 replace force
clone 378 7 -420 378 7 -420 341 49 -404 replace force
clone 378 7 -420 378 7 -420 341 51 -404 replace force
clone 378 7 -420 378 7 -420 341 53 -404 replace force
clone 378 7 -420 378 7 -420 341 49 -402 replace force
clone 378 7 -420 378 7 -420 341 51 -402 replace force
clone 379 7 -419 379 7 -419 345 51 -400 replace force

#Signs
clone 391 4 -422 391 4 -422 365 52 -406 replace force
clone 391 4 -422 391 4 -422 365 52 -404 replace force
clone 391 4 -422 391 4 -422 365 52 -402 replace force
clone 386 4 -419 386 4 -419 364 52 -401 replace force
#clone 391 4 -422 391 4 -422 363 52 -402 replace force
clone 386 4 -419 386 4 -419 362 52 -401 replace force
clone 386 4 -419 386 4 -419 360 52 -401 replace force
clone 386 4 -419 386 4 -419 358 52 -401 replace force
clone 386 4 -419 386 4 -419 356 52 -401 replace force
clone 386 4 -419 386 4 -419 354 52 -401 replace force
clone 386 4 -419 386 4 -419 352 52 -401 replace force
clone 386 4 -419 386 4 -419 350 52 -401 replace force
clone 386 4 -419 386 4 -419 348 52 -401 replace force
clone 389 4 -425 389 4 -425 350 52 -410 replace force
clone 389 4 -425 389 4 -425 346 52 -410 replace force
clone 389 4 -425 389 4 -425 348 52 -410 replace force
clone 389 4 -425 389 4 -425 352 52 -410 replace force
clone 382 5 -422 382 5 -422 342 54 -407 replace force
clone 382 5 -422 382 5 -422 342 54 -404 replace force
clone 382 5 -422 382 5 -422 342 52 -402 replace force
clone 382 5 -422 382 5 -422 342 52 -404 replace force
clone 382 5 -422 382 5 -422 342 52 -407 replace force
clone 382 5 -422 382 5 -422 342 52 -409 replace force
clone 382 5 -422 382 5 -422 342 50 -402 replace force
clone 382 5 -422 382 5 -422 342 50 -404 replace force
clone 382 5 -422 382 5 -422 342 50 -407 replace force
clone 382 5 -422 382 5 -422 342 50 -409 replace force
clone 386 4 -419 386 4 -419 345 52 -401 replace force

#Lecturn
function EggRoom/Lecturn/Reset
