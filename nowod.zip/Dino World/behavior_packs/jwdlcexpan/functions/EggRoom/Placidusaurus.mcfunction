#===========Placidusaurus_egg===


clone 382 7 -422 382 7 -422 341 51 -407 replace force
clone 382 4 -422 382 4 -422 342 52 -407 replace force

