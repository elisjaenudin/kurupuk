#===========Ankylosaurus_block===============


clone 391 6 -424 391 6 -424 366 49 -406 replace force
clone 391 5 -424 391 5 -424 365 52 -406 replace force
