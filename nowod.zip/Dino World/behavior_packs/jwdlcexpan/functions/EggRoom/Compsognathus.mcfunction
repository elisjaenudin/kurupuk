#===========Compsognathus_block===============


clone 391 8 -420 391 8 -420 364 51 -400 replace force
clone 391 5 -420 391 5 -420 364 52 -401 replace force

