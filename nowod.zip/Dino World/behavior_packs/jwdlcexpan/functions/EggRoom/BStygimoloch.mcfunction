#===========BStygimoloch_egg===============


clone 383 7 -419 383 7 -419 348 50 -400 replace force
clone 383 5 -419 383 5 -419 348 52 -401 replace force
