#===========BGallimimus_block===============


clone 388 7 -419 388 7 -419 358 50 -400 replace force
clone 388 5 -419 388 5 -419 358 52 -401 replace force
