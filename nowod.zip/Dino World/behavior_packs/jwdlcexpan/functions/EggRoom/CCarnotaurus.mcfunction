#===========CCarnotaurus_block===============


clone 391 6 -421 391 6 -421 346 49 -411 replace force
clone 391 5 -421 391 5 -421 346 52 -410 replace force