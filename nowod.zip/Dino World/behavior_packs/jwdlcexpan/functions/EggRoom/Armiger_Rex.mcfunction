#===========Armiger_Rex_egg===

clone 382 8 -420 382 8 -420 341 51 -404 replace force
clone 382 5 -420 382 5 -420 342 52 -404 replace force

