#===========BTriceratops_egg===============


clone 390 7 -425 390 7 -425 348 50 -411 replace force
clone 390 5 -425 390 5 -425 348 52 -410 replace force
