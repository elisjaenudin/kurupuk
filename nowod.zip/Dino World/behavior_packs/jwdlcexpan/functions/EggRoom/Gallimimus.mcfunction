#===========Gallimimus_block===============


clone 388 8 -419 388 8 -419 358 51 -400 replace force
clone 388 5 -419 388 5 -419 358 52 -401 replace force
