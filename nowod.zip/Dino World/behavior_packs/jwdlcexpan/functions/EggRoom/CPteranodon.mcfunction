#===========CPteranodon_egg===============


clone 386 6 -419 386 6 -419 354 49 -400 replace force
clone 386 5 -419 386 5 -419 354 52 -401 replace force

