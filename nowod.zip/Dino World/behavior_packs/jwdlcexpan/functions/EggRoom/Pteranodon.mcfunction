#===========Pteranodon_egg===============


clone 386 8 -419 386 8 -419 354 51 -400 replace force
clone 386 5 -419 386 5 -419 354 52 -401 replace force
