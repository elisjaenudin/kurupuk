#===========BCompsognathus_block===============


clone 391 7 -420 391 7 -420 364 50 -400 replace force
clone 391 5 -420 391 5 -420 364 52 -401 replace force
