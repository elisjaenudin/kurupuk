#===========Parasaurolophus_block===============


clone 387 8 -419 387 8 -419 356 51 -400 replace force
clone 387 5 -419 387 5 -419 356 52 -401 replace force
