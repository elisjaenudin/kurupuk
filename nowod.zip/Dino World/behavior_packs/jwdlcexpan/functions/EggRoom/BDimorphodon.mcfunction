#===========BDimorphodon_block===============


clone 389 7 -419 389 7 -419 360 50 -400 replace force
clone 389 5 -419 389 5 -419 360 52 -401 replace force
