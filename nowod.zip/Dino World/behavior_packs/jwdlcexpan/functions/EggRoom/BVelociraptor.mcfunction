#===========BVelociraptor_egg===============


clone 388 7 -425 388 7 -425 352 50 -411 replace force
clone 388 5 -425 388 5 -425 352 52 -410 replace force
