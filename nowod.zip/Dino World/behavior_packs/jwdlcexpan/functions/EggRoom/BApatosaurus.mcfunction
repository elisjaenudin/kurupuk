#===========BApatosaurus_block===============

clone 391 7 -423 391 7 -423 366 50 -404 replace force
clone 391 5 -423 391 5 -423 365 52 -404 replace force