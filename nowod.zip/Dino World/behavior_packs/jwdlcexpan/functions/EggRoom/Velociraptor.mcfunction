#===========Velociraptor_egg===============


clone 388 8 -425 388 8 -425 352 51 -411 replace force
clone 388 5 -425 388 5 -425 352 52 -410 replace force
