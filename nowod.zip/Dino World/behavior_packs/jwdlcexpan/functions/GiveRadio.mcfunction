#===========Give Radio===============

give @p spawn_egg 1 33 {"can_place_on":{"blocks":["grass","gravel","stone","stained_glass","sand","stained_hardened_clay","planks","wooden_slab"]}}