#Setup hotel monorail station for first playthough

#structure bank
setblock 265 37 -190 redstone_block
#enable command zone detector 
setblock 350 8 -420 redstone_block