# resets quickbuild progress, does not clear quickbuild sites
#say DEBUG quickbuild reset

setblock 344 11 -429 sponge
setblock 344 11 -431 sponge
setblock 344 11 -433 sponge
setblock 344 11 -435 sponge
setblock 344 11 -437 sponge
setblock 344 11 -439 sponge
setblock 344 11 -441 sponge

scoreboard players set @a quickbuild 0

scoreboard players set @e[tag=disaster_system] exhibit_a 0
scoreboard players set @e[tag=disaster_system] exhibit_b 0
scoreboard players set @e[tag=disaster_system] exhibit_c 0
scoreboard players set @e[tag=disaster_system] exhibit_d 0
scoreboard players set @e[tag=disaster_system] exhibit_e 0
scoreboard players set @e[tag=disaster_system] exhibit_f 0
scoreboard players set @e[tag=disaster_system] exhibit_g 0