# Shows the player a celebration when each of the samples in the island, jungle mines, and desert site are compeletly collected
#say DEBUG celebrate progress

execute @a[tag=inIsland,scores={islandSamples=7}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.progress.all_island"}]}
execute @a[tag=inIsland,scores={islandSamples=7}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":" "}]}
execute @a[tag=inIsland,scores={islandSamples=7}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.progress.all_island"}]} 
execute @a[tag=inIsland,scores={islandSamples=7}] ~ ~ ~ /scoreboard players add @a islandSamples 1

execute @a[tag=inJungle,scores={jungleSamples=6}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.progress.all_jungle"}]}
execute @a[tag=inJungle,scores={jungleSamples=6}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":" "}]}
execute @a[tag=inJungle,scores={jungleSamples=6}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.progress.all_jungle"}]} 
execute @a[tag=inJungle,scores={jungleSamples=6}] ~ ~ ~ /scoreboard players add @a jungleSamples 1

execute @a[tag=inDesert,scores={desertSamples=6}] ~ ~ ~ /titleraw @s subtitle {"rawtext":[{"translate":"jw.progress.all_desert"}]}
execute @a[tag=inDesert,scores={desertSamples=6}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":" "}]}
execute @a[tag=inDesert,scores={desertSamples=6}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.progress.all_desert"}]} 
execute @a[tag=inDesert,scores={desertSamples=6}] ~ ~ ~ /scoreboard players add @a desertSamples 1