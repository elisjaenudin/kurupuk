#===========Give Equipment===============

give @a jw:wrench
give @a crossbow
give @a arrow 64
give @a diamond_sword
give @a spawn_egg 1 34
function Books/GiveBrochure