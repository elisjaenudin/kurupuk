#-----Armiger_Rex-----

tp @e[tag=hologram] 390 1 -466
kill @e[tag=hologram]
summon jurassic_world:h_armiger_rex 389.9 51.5 -376.1