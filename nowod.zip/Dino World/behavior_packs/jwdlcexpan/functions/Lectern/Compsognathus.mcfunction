#-----Compsognathus Lectern-----

tp @e[tag=hologram] 390 1 -466
kill @e[tag=hologram]
summon jurassic_world:h_compsognathus 389.9 51.5 -380.1
summon jurassic_world:h_compsognathus 388.1 51.5 -378.6
summon jurassic_world:h_compsognathus 392.4 51.5 -377.5
summon jurassic_world:h_compsognathus 389.4 51.5 -377.8
summon jurassic_world:h_compsognathus 391.6  51.5 -379.7