#-----Stygi_Liberi Lectern-----

tp @e[tag=hologram] 390 1 -466
kill @e[tag=hologram]
summon jurassic_world:h_stygi_liberi 389.9 51.5 -378.1