#-----Fascino_Nathus Lectern-----

tp @e[tag=hologram] 390 1 -466
kill @e[tag=hologram]
summon jurassic_world:h_fascino_nathus 389.9 51.5 -378.1