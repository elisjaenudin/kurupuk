#-----Venatorus Lectern-----

tp @e[tag=hologram] 390 1 -466
kill @e[tag=hologram]
summon jurassic_world:h_venatorus 389.9 51.5 -377.1