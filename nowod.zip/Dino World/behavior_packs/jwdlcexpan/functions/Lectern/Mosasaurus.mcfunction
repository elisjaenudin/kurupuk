#-----Mosasaurus Lectern-----

tp @e[tag=hologram] 390 1 -466
kill @e[tag=hologram]
summon jurassic_world:h_mosasaurus 389.9 53 -376.6