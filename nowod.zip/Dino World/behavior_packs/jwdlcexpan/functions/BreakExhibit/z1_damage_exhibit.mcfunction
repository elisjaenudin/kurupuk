#debug
#execute @e[tag=exhibit_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 1 Exhibit Damaged

#prevent redstone retriggering zone selection
execute @e[tag=exhibit_zone_math,scores={z1_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zonePicked 1

# a zone was chosen so stop looking for a zone
execute @e[tag=exhibit_zone_math,scores={zone1loaded=0,z1_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -479 air


#===pick an exhibit====
execute @e[tag=exhibit_zone_math,scores={zone1loaded=0,z1_exhbt_active=0}] ~ ~ ~ detect 445 47 -343 dirt 1 /function BreakExhibit/broken/Zone1_gentle_giants

#=============

#message sector 1 disaster
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit1event.chat"}]}

#start check for solution
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -472 redstone_block

#stop this block
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -476 air

#------------------turn off ticking area
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=0}] ~ ~ ~ /tickingarea remove exhibit1

#add this to total disaster count
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z1_exhbt_active 1

#reset zone1loaded
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone1loaded 0