#create the ticking zone
tickingarea add circle 206 43 -539 3 exhibit2

#turn off block for finding dino exhibit to break
setblock 356 1 -479 air

#activate the redstone block to cause the break
setblock 356 1 -463 redstone_block

#reset zone1loaded
scoreboard players set @e[tag=exhibit_zone_math] zone2loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=exhibit_zone_math] zonePicked 1

#add indicator
clone 365 1 -425 372 15 -432 206 140 -539 replace force

#play disaster sound
playsound stinger.disaster.01 @a