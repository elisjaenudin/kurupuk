#create the ticking zone
tickingarea add circle 622 17 -411 3 exhibit3

#turn off block for finding dino exhibit to break
setblock 356 1 -479 air

#activate the redstone block to cause the break
setblock 356 1 -451 redstone_block

#reset zone1loaded
scoreboard players set @e[tag=exhibit_zone_math] zone3loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=exhibit_zone_math] zonePicked 1

#add indicator
clone 365 1 -425 372 15 -432 622 140 -411 replace force

#play disaster sound
playsound stinger.disaster.01 @a