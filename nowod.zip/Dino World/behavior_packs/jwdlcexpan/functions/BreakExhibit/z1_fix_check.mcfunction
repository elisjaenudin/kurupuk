#if neither are fixed, but we detect one, output the partial fix message
execute @e[tag=exhibit_zone_math,scores={zone1_fix1=0,zone1_fix2=0,z1fence1=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit1_partial.chat"}]}
execute @e[tag=exhibit_zone_math,scores={zone1_fix1=0,zone1_fix2=0,z1fence2=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit1_partial.chat"}]}

#if this section hasn't been fixed, but we detect its been fixed, call the fixed function to activate the structure block
execute @e[tag=exhibit_zone_math,scores={zone1_fix1=0,z1fence1=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone1_gentle_giants_1
execute @e[tag=exhibit_zone_math,scores={zone1_fix2=0,z1fence2=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone1_gentle_giants_2

#set the fix z1 block to be powered
execute @e[tag=exhibit_zone_math,scores={zone1_fix1=1,zone1_fix2=1}] ~ ~ ~ /setblock 356 1 -469 redstone_block

execute @e[tag=BEZ11_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone1_fix1=1}] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=BEZ11_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone1_fix1=1}] ~ ~ ~ /kill @e[tag=BEZ11_Sparks]
execute @e[tag=BEZ12_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone1_fix2=1}] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=BEZ12_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone1_fix2=1}] ~ ~ ~ /kill @e[tag=BEZ12_Sparks]