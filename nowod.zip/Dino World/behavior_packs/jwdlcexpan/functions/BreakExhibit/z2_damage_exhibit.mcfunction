#debug
#execute @e[tag=exhibit_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 2 Exhibit Damaged

#prevent redstone retriggering zone selection
execute @e[tag=exhibit_zone_math,scores={z2_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zonePicked 1

# a zone was chosen so stop looking for a zone
execute @e[tag=exhibit_zone_math,scores={zone2loaded=0,z2_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -479 air

#===pick an exhibit====
execute @e[tag=exhibit_zone_math,scores={zone2loaded=0,z2_exhbt_active=0}] ~ ~ ~ detect 206 42 -539 grass 0 /function BreakExhibit/broken/Zone2_gyro

#=============

#message sector 2 disaster
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit2event.chat"}]}

#start check for solution
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -460 redstone_block

#stop this block
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -463 air

#------------------turn off ticking area
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=0}] ~ ~ ~ /tickingarea remove exhibit2

#add this to total disaster count
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z2_exhbt_active 1

#reset zone2loaded
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone2loaded 0