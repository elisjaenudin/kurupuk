#debug
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Damage Exhibit

#loop if zones arent full, until we choose a zone thats not populated
scoreboard players random @e[tag=exhibit_zone_math] zone_random 1 3

#===zone1===
#if zone 1 chosen and not already active, power the command block with /function z1_damage_exhibit
execute @e[tag=exhibit_zone_math,scores={zone_random=1..1,z1_exhbt_active=0,zonePicked=0}] ~ ~ ~ /function BreakExhibit/cause_z1_exhibit



#===zone2===
#if zone 2 chosen and not already active, power the command block with /function z2_power_outage
execute @e[tag=exhibit_zone_math,scores={zone_random=2..2,z2_exhbt_active=0,zonePicked=0}] ~ ~ ~ /function BreakExhibit/cause_z2_exhibit


#===zone3===
#if zone 3 chosen and not already active, power the command block with /function z3_power_outage
execute @e[tag=exhibit_zone_math,scores={zone_random=3..3,z3_exhbt_active=0,zonePicked=0}] ~ ~ ~ /function BreakExhibit/cause_z3_exhibit



#=======================================================
#check if all zones are active, and if they are, call a different disaster
execute @e[tag=exhibit_zone_math,scores={z1_exhbt_active=1,z2_exhbt_active=1,z3_exhbt_active=1,zonePicked=0}] ~ ~ ~ /function BreakExhibit/CheckActive