tickingarea remove exhibit3

#turn off this block
setblock 356 1 -442 air