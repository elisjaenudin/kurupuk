
#fence3
#fill 387 1 -419 387 1 -419 air 0 replace redstone_block 0
#fill 386 1 -419 386 1 -419 redstone_block 0 replace air 0
setblock 200 39 -544 air
setblock 199 39 -544 redstone_block


scoreboard players set @e[tag=exhibit_zone_math] zone2_fix3 1