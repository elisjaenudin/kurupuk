#=========================== exhibit broken aviary =================

#fence2
#fill 382 1 -419 382 1 -419 air 0 replace redstone_block 0
#fill 381 1 -419 381 1 -419 redstone_block 0 replace air 0

setblock 628 13 -418 air
setblock 628 13 -419 redstone_block


scoreboard players set @e[tag=exhibit_zone_math] zone3_fix2 1