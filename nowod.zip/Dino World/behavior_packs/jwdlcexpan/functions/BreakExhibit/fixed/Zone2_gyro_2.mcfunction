#=========================== exhibit broken gyrosphere =================

#fence2
#fill 389 1 -419 389 1 -419 air 0 replace redstone_block 0
#fill 388 1 -419 388 1 -419 redstone_block 0 replace air 0
setblock 203 39 -544 air
setblock 202 39 -544 redstone_block


scoreboard players set @e[tag=exhibit_zone_math] zone2_fix2 1