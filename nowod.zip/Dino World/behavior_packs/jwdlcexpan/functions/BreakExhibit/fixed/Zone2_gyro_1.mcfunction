#=========================== exhibit broken gyrosphere =================

#fence1
#fill 391 1 -419 391 1 -419 air 0 replace redstone_block 0
#fill 390 1 -419 390 1 -419 redstone_block 0 replace air 0
setblock 206 39 -544 air
setblock 205 39 -544 redstone_block


scoreboard players set @e[tag=exhibit_zone_math] zone2_fix1 1