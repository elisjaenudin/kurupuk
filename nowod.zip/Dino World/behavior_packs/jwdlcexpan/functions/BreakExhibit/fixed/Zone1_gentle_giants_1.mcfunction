#=========================== exhibit broken gentle giants =================

#fence1
fill 396 1 -419 396 1 -419 air 0 replace redstone_block 0
fill 395 1 -419 395 1 -419 redstone_block 0 replace air 0

scoreboard players set @e[tag=exhibit_zone_math] zone1_fix1 1