#=========================== exhibit broken aviary =================

#fence1
#fill 384 1 -419 384 1 -419 air 0 replace redstone_block 0
#fill 383 1 -419 383 1 -419 redstone_block 0 replace air 0
setblock 628 13 -416 air
setblock 628 13 -417 redstone_block

#fence2
#fill 382 1 -419 382 1 -419 air 0 replace redstone_block 0
#fill 381 1 -419 381 1 -419 redstone_block 0 replace air 0
setblock 628 13 -418 air
setblock 628 13 -419 redstone_block


scoreboard players set @e[tag=exhibit_zone_math] zone3loaded 2