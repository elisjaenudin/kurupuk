#debug
#execute @e[tag=exhibit_zone_math,scores={debug=1}] ~ ~ ~ /say Zone 3 Exhibit Damaged

#prevent redstone retriggering zone selection
execute @e[tag=exhibit_zone_math,scores={z3_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zonePicked 1

# a zone was chosen so stop looking for a zone
execute @e[tag=exhibit_zone_math,scores={zone3loaded=0,z3_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -479 air

#===pick an exhibit====
execute @e[tag=exhibit_zone_math,scores={zone3loaded=0,z3_exhbt_active=0}] ~ ~ ~ detect 622 16 -411 grass 0 /function BreakExhibit/broken/Zone3_aviary

#=============

#message sector 3 disaster
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit3event.chat"}]}

#start check for solution
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -448 redstone_block

#stop this block
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -451 air

#------------------turn off ticking area
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=0}] ~ ~ ~ /tickingarea remove exhibit3

#add this to total disaster count
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z3_exhbt_active 1

#reset zone3loaded
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=0}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone3loaded 0