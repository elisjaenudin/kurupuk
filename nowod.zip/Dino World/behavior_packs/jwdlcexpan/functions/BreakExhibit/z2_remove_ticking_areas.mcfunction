tickingarea remove exhibit2

#turn off this block
setblock 356 1 -454 air