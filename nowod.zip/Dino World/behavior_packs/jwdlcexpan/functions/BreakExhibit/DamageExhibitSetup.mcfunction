#Damge exhbt setup
scoreboard objectives add z1_exhbt_active dummy
scoreboard objectives add z2_exhbt_active dummy
scoreboard objectives add z3_exhbt_active dummy
scoreboard objectives add zone1_fix1 dummy
scoreboard objectives add zone1_fix2 dummy
scoreboard objectives add zone2_fix1 dummy
scoreboard objectives add zone2_fix2 dummy
scoreboard objectives add zone2_fix3 dummy
scoreboard objectives add zone3_fix1 dummy
scoreboard objectives add zone3_fix2 dummy

scoreboard objectives add z1fence1 dummy
scoreboard objectives add z1fence2 dummy
scoreboard objectives add z2fence1 dummy
scoreboard objectives add z2fence2 dummy
scoreboard objectives add z3aviary1 dummy
scoreboard objectives add z3aviary2 dummy

scoreboard players set @e[tag=exhibit_zone_math] z1_exhbt_active 0

scoreboard players set @e[tag=exhibit_zone_math] z2_exhbt_active 0

scoreboard players set @e[tag=exhibit_zone_math] z3_exhbt_active 0

scoreboard players set @e[tag=exhibit_zone_math] zonePicked 0
scoreboard players set @e[tag=exhibit_zone_math] zone_random 0


scoreboard players set @e[tag=exhibit_zone_math] no_fix_msg 0

scoreboard players set @e[tag=exhibit_zone_math] zone1_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone1_fix2 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix2 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix3 0
scoreboard players set @e[tag=exhibit_zone_math] zone3_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone3_fix2 0

scoreboard players set @e[tag=exhibit_zone_math] z1fence1 0
scoreboard players set @e[tag=exhibit_zone_math] z1fence2 0
scoreboard players set @e[tag=exhibit_zone_math] z2fence1 0
scoreboard players set @e[tag=exhibit_zone_math] z2fence2 0
scoreboard players set @e[tag=exhibit_zone_math] z3aviary1 0
scoreboard players set @e[tag=exhibit_zone_math] z3aviary2 0
