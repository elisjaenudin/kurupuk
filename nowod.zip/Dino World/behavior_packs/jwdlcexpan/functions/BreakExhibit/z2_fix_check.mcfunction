#if neither are fixed, but we detect one, output the partial fix message
execute @e[tag=exhibit_zone_math,scores={zone2_fix1=0,zone2_fix2=0,z2fence1=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit2_partial.chat"}]}
execute @e[tag=exhibit_zone_math,scores={zone2_fix1=0,zone2_fix2=0,z2fence2=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit2_partial.chat"}]}

execute @e[tag=exhibit_zone_math,scores={zone2_fix1=0,zone2_fix2=0,z2fence1=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone2_gyro_3
execute @e[tag=exhibit_zone_math,scores={zone2_fix1=0,zone2_fix2=0,z2fence2=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone2_gyro_3

#if this section hasn't been fixed, but we detect its been fixed, call the fixed function to activate the structure block
execute @e[tag=exhibit_zone_math,scores={zone2_fix1=0,z2fence1=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone2_gyro_1
execute @e[tag=exhibit_zone_math,scores={zone2_fix2=0,z2fence2=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone2_gyro_2

#remove tag so that it won't get killed if you solve the disaster manually and have teleported the dinosaur
execute @e[tag=exhibit_zone_math,scores={zone2_fix1=1,zone2_fix2=1}] ~ ~ ~ /tag @e[tag=z2_exhibit_dino] remove z2_exhibit_dino

#set the fix z2 block to be powered
execute @e[tag=exhibit_zone_math,scores={zone2_fix1=1,zone2_fix2=1}] ~ ~ ~ /setblock 356 1 -457 redstone_block

execute @e[tag=exhibit_zone_math,scores={zone2_fix1=1}] ~ ~ ~ /tp @e[tag=BEZ21_Sparks] 390 1 -466
execute @e[tag=exhibit_zone_math,scores={zone2_fix1=1}] ~ ~ ~ /kill @e[tag=BEZ21_Sparks]
execute @e[tag=exhibit_zone_math,scores={zone2_fix2=1}] ~ ~ ~ /tp @e[tag=BEZ22_Sparks] 390 1 -466
execute @e[tag=exhibit_zone_math,scores={zone2_fix2=1}] ~ ~ ~ /kill @e[tag=BEZ22_Sparks]


