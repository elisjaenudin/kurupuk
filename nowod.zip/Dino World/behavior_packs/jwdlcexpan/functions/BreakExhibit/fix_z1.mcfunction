#===Fix it===
#if we aren't active, turn off the redstone block for this command block (which is also the reset block in this case)
execute @e[tag=exhibit_zone_math,scores={z1_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -469 air

#turn off solution check
execute @e[tag=exhibit_zone_math,scores={z1_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -472 air
#-------------------------------------------end inactive precautions ----------------------------

#create ticking zone for zone 1
execute @e[tag=exhibit_zone_math,scores={zone1loaded=0,z1_exhbt_active=1}] ~ ~ ~ /tickingarea add circle 445 48 -343 3 exhibit1
execute @e[tag=exhibit_zone_math,scores={zone1loaded=0,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone1loaded 1

#reset the scores for fixes
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone1_fix1 0
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone1_fix2 0

#fix exhibit
execute @e[tag=exhibit_zone_math,scores={zone1loaded=1,z1_exhbt_active=1}] ~ ~ ~ detect 445 47 -343 dirt 1 /function BreakExhibit/fixed/Zone1_gentle_giants

#remove indicator
clone 367 1 -434 374 15 -441 445 140 -343 replace force

#fix message
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.exhibit1fix.subtitle"}]}
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#kill broken fence pieces
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z1fence1]
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z1fence2]

execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z1fence1 0
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z1fence2 0


#kill sparks
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /kill @e[tag=BEZ11_Sparks]
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /kill @e[tag=BEZ12_Sparks]

#turn off solution check
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -472 air

#stop this block
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -469 air

#stop ticking area
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /tickingarea remove exhibit1

#remove this from total disaster count
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -466 redstone_block

#reset zone1loaded
execute @e[tag=exhibit_zone_math,scores={zone1loaded=2,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone1loaded 0

#mark z1 inactive
execute @e[tag=exhibit_zone_math,scores={zone1loaded=0,z1_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z1_exhbt_active 0

#remove entity from the map
kill @e[tag=dis_broken_exz1]

