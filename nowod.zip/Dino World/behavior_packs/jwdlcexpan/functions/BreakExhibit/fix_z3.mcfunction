#===Fix it===
#if we aren't active, turn off the redstone block for this command block
execute @e[tag=exhibit_zone_math,scores={z3_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -445 air

#turn off reset block
execute @e[tag=exhibit_zone_math,scores={z3_exhbt_active=0}] ~ ~ ~ /setblock 354 1 -445 air

#turn off solution check
execute @e[tag=exhibit_zone_math,scores={z3_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -448 air
#-------------------------------------------end inactive precautions ----------------------------

#create ticking zone for zone 3
execute @e[tag=exhibit_zone_math,scores={zone3loaded=0,z3_exhbt_active=1}] ~ ~ ~ /tickingarea add circle 622 17 -411 3 exhibit3
execute @e[tag=exhibit_zone_math,scores={zone3loaded=0,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone3loaded 1

#reset the scores for fixes
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone3_fix1 0
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone3_fix2 0

#fix exhibit
execute @e[tag=exhibit_zone_math,scores={zone3loaded=1,z3_exhbt_active=1}] ~ ~ ~ detect 622 16 -411 grass 0 /function BreakExhibit/fixed/Zone3_aviary
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2, z3_exhbt_active=1}] ~ ~ ~ /tp @e[tag=z3_exhibit_dino] 403 2 -479
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2, z3_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z3_exhibit_dino]

#remove indicator
clone 367 1 -434 374 15 -441 622 140 -411 replace force

#fix message
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.exhibit3fix.subtitle"}]}
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#kill broken fence pieces
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z3aviary1]
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z3aviary2]

execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z3aviary1 0
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z3aviary2 0

#kill sparks
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /kill @e[tag=BEZ31_Sparks]
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /kill @e[tag=BEZ32_Sparks]

#turn off solution check
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -448 air

#stop this block
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -445 air

#stop ticking area
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /tickingarea remove exhibit3

#remove this from total disaster count
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage
#run delayed remove ticking areas just in case
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -442 redstone_block

#reset zone3loaded
execute @e[tag=exhibit_zone_math,scores={zone3loaded=2,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone3loaded 0

#mark z2 inactive
execute @e[tag=exhibit_zone_math,scores={zone3loaded=0,z3_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z3_exhbt_active 0

#remove entity from the map
kill @e[tag=dis_broken_exz3]