#Reset function

#suppress the messaging for fixing disasters
scoreboard players set @e[tag=exhibit_zone_math] no_fix_msg 1

#trigger series of delayed command blocks to undo the disasters in a staged order
setblock 356 1 -469 redstone_block
setblock 354 1 -457 redstone_block
setblock 354 1 -445 redstone_block
setblock 354 1 -442 redstone_block
