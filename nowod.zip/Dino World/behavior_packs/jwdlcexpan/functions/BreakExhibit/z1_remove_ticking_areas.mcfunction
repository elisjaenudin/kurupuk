tickingarea remove exhibit1

#turn off this block
setblock 356 1 -466 air