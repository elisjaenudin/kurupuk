#reset function
scoreboard players set @e[tag=exhibit_zone_math] z1_exhbt_active 0
scoreboard players set @e[tag=exhibit_zone_math] z2_exhbt_active 0
scoreboard players set @e[tag=exhibit_zone_math] z3_exhbt_active 0
scoreboard players set @e[tag=exhibit_zone_math] zonePicked 0
scoreboard players set @e[tag=exhibit_zone_math] zone_random 0
scoreboard players set @e[tag=exhibit_zone_math] zone1_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone1_fix2 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix2 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix3 0
scoreboard players set @e[tag=exhibit_zone_math] zone3_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone3_fix2 0

#un-suppress the messaging for fixing disasters
scoreboard players set @e[tag=exhibit_zone_math] no_fix_msg 0

#turn this off
setblock 354 1 -442 air





