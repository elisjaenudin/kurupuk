#if neither are fixed, but we detect one, output the partial fix message
execute @e[tag=exhibit_zone_math,scores={zone3_fix1=0,zone3_fix2=0,z3aviary1=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit3_partial.chat"}]}
execute @e[tag=exhibit_zone_math,scores={zone3_fix1=0,zone3_fix2=0,z3aviary2=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.exhibit3_partial.chat"}]}

#if this section hasn't been fixed, but we detect its been fixed, call the fixed function to activate the structure block
execute @e[tag=exhibit_zone_math,scores={zone3_fix1=0,z3aviary1=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone3_aviary_1
execute @e[tag=exhibit_zone_math,scores={zone3_fix2=0,z3aviary2=1}] ~ ~ ~ /function BreakExhibit/fixed/Zone3_aviary_2

#remove tag so that it won't get killed if you solve the disaster manually and have teleported the dinosaur
execute @e[tag=exhibit_zone_math,scores={zone3_fix1=1,zone3_fix2=1}] ~ ~ ~ /tag @e[tag=z3_exhibit_dino] remove z3_exhibit_dino

#set the fix z3 block to be powered
execute @e[tag=exhibit_zone_math,scores={zone3_fix1=1,zone3_fix2=1}] ~ ~ ~ /setblock 356 1 -445 redstone_block


execute @e[tag=BEZ31_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone3_fix1=1}] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=BEZ31_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone3_fix1=1}] ~ ~ ~ /kill @e[tag=BEZ31_Sparks]
execute @e[tag=BEZ32_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone3_fix2=1}] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=BEZ32_Sparks] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={zone3_fix2=1}] ~ ~ ~ /kill @e[tag=BEZ32_Sparks]