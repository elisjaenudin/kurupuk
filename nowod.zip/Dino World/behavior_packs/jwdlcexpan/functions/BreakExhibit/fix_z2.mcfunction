#===Fix it===
#if we aren't active, turn off the redstone block for this command block
execute @e[tag=exhibit_zone_math,scores={z2_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -457 air

#turn off reset block
execute @e[tag=exhibit_zone_math,scores={z2_exhbt_active=0}] ~ ~ ~ /setblock 354 1 -457 air

#turn off solution check
execute @e[tag=exhibit_zone_math,scores={z2_exhbt_active=0}] ~ ~ ~ /setblock 356 1 -460 air
#-------------------------------------------end inactive precautions ----------------------------

#create ticking zone for zone 2
execute @e[tag=exhibit_zone_math,scores={zone2loaded=0,z2_exhbt_active=1}] ~ ~ ~ /tickingarea add circle 206 43 -539 3 exhibit2
execute @e[tag=exhibit_zone_math,scores={zone2loaded=0,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone2loaded 1

#reset the scores for fixes
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone2_fix1 0
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone2_fix2 0

#fix exhibit
execute @e[tag=exhibit_zone_math,scores={zone2loaded=1,z2_exhbt_active=1}] ~ ~ ~ detect 206 42 -539 grass 0 /function BreakExhibit/fixed/Zone2_gyro
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2, z2_exhbt_active=1}] ~ ~ ~ /tp @e[tag=z2_exhibit_dino] 403 2 -479
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2, z2_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z2_exhibit_dino]

#remove indicator
clone 367 1 -434 374 15 -441 206 140 -539 replace force

#fix message
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.exhibit2fix.subtitle"}]}
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#kill broken fence pieces
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z2fence1]
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /kill @e[tag=z2fence2]

execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z2fence1 0
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z2fence2 0

#kill sparks
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /kill @e[tag=BEZ21_Sparks]
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /kill @e[tag=BEZ22_Sparks]

#turn off solution check
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -460 air

#stop this block
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -457 air

#stop ticking area
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /tickingarea remove exhibit2

#remove this from total disaster count
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#run delayed remove ticking areas just in case
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -454 redstone_block

#reset zone2loaded
execute @e[tag=exhibit_zone_math,scores={zone2loaded=2,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] zone2loaded 0

#mark z2 inactive
execute @e[tag=exhibit_zone_math,scores={zone2loaded=0,z2_exhbt_active=1}] ~ ~ ~ /scoreboard players set @e[tag=exhibit_zone_math] z2_exhbt_active 0

#remove entity from the map
kill @e[tag=dis_broken_exz2]