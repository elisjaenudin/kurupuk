#=========================== exhibit broken gentle giants =================

#fence1
fill 396 1 -419 396 1 -419 redstone_block 0 replace air 0
fill 395 1 -419 395 1 -419 air 0 replace redstone_block 0

scoreboard players set @e[tag=exhibit_zone_math] z1fence1 0
scoreboard players set @e[tag=exhibit_zone_math] z1fence2 0

summon jw:broken_fence 450 48 -345
tag @e[type=jw:broken_fence,x=450,y=48,z=-345,r=3] add z1fence1

summon jw:broken_fence 437 48 -351
tag @e[type=jw:broken_fence,x=437,y=48,z=-351,r=3] add z1fence2

#fence2
fill 394 1 -419 394 1 -419 redstone_block 0 replace air 0
fill 393 1 -419 393 1 -419 air 0 replace redstone_block 0

scoreboard players set @e[tag=exhibit_zone_math] zone1_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone1_fix2 0

scoreboard players set @e[tag=exhibit_zone_math] zone1loaded 1

#add entity from the map
summon jw:disaster 349.2 57.8 -441
execute @e[type=jw:disaster,x=349.2,y=57.2,z=-441,r=1] 349.2 57.2 -441 tag @s add dis_broken_exz1

#Exhibit Sparks
summon jw:sparks 450 49 -345
execute @e[type=jw:sparks,x=450,y=49,z=-345,r=1] 450 49 -345 tag @s add BEZ11_Sparks
summon jw:sparks 437 49 -351
execute @e[type=jw:sparks,x=437,y=49,z=-351,r=1] 437 49 -351 tag @s add BEZ12_Sparks