#=========================== exhibit broken aviary =================

#fence1
#fill 384 1 -419 384 1 -419 redstone_block 0 replace air 0
#fill 383 1 -419 383 1 -419 air 0 replace redstone_block 0
setblock 628 13 -416 redstone_block
setblock 628 13 -417 air

#fence2
#fill 382 1 -419 382 1 -419 redstone_block 0 replace air 0
#fill 381 1 -419 381 1 -419 air 0 replace redstone_block 0

setblock 628 13 -418 redstone_block
setblock 628 13 -419 air

scoreboard players set @e[tag=exhibit_zone_math] z3aviary1 0
scoreboard players set @e[tag=exhibit_zone_math] z3aviary2 0

summon jw:broken_aviary 625 17 -406
tag @e[type=jw:broken_aviary,x=625,y=17,z=-406,r=3] add z3aviary1

summon jw:broken_aviary 616 17 -416
tag @e[type=jw:broken_aviary,x=616,y=17,z=-416,r=3] add z3aviary2


#dino spawn
summon jurassic_world:pteranodon 617 17 -478 jw:adult
execute @e[type=jurassic_world:pteranodon,x=617,y=17,z=-478,r=2] 617 17 -478 tag @e[type=jurassic_world:pteranodon] add z3_exhibit_dino



scoreboard players set @e[tag=exhibit_zone_math] zone3_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone3_fix2 0

scoreboard players set @e[tag=exhibit_zone_math] zone3loaded 1

#add entity from the map
summon jw:disaster 350 58.3 -441
execute @e[type=jw:disaster,x=350,y=58.3,z=-441,r=1] 350 58.3 -441 tag @s add dis_broken_exz3

#Exhibit Sparks
summon jw:sparks 625 18 -406
execute @e[type=jw:sparks,x=625,y=18,z=-406,r=1] 625 18 -406 tag @s add BEZ31_Sparks
summon jw:sparks 616 18 -416
execute @e[type=jw:sparks,x=616,y=18,z=-416,r=1] 616 18 -416 tag @s add BEZ32_Sparks