#=========================== exhibit broken gyrosphere =================

#fence1
#fill 391 1 -419 391 1 -419 redstone_block 0 replace air 0
#fill 390 1 -419 390 1 -419 air 0 replace redstone_block 0
setblock 206 39 -544 redstone_block
setblock 205 39 -544 air

#fence2
#fill 389 1 -419 389 1 -419 redstone_block 0 replace air 0
#fill 388 1 -419 388 1 -419 air 0 replace redstone_block 0
setblock 203 39 -544 redstone_block
setblock 202 39 -544 air

#fence3
#fill 387 1 -419 387 1 -419 redstone_block 0 replace air 0
#fill 386 1 -419 386 1 -419 air 0 replace redstone_block 0
setblock 200 39 -544 redstone_block
setblock 199 39 -544 air

scoreboard players set @e[tag=exhibit_zone_math] z2fence1 0
scoreboard players set @e[tag=exhibit_zone_math] z2fence2 0

summon jw:broken_fence 199 43 -534
tag @e[type=jw:broken_fence,x=199,y=43,z=-534,r=3] add z2fence1

summon jw:broken_fence 209 43 -544
tag @e[type=jw:broken_fence,x=209,y=43,z=-544,r=3] add z2fence2


#spawn dino
summon jurassic_world:triceratops 218 48 -522 jw:adult
execute @e[type=jurassic_world:triceratops,x=218,y=48,z=-522,r=2] 218 48 -522 tag @e[type=jurassic_world:triceratops] add z2_exhibit_dino


scoreboard players set @e[tag=exhibit_zone_math] zone2_fix1 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix2 0
scoreboard players set @e[tag=exhibit_zone_math] zone2_fix3 0

scoreboard players set @e[tag=exhibit_zone_math] zone2loaded 1

#add entity from the map
summon jw:disaster 347.2 59.7 -441
execute @e[type=jw:disaster,x=347.2,y=59.7,z=-441,r=1] 347.2 59.7 -441 tag @s add dis_broken_exz2

#Exhibit Sparks
summon jw:sparks 209 44 -544
tag @e[type=jw:sparks,x=209,y=44,z=-544,r=2] add BEZ22_Sparks
summon jw:sparks 199 44 -534
tag @e[type=jw:sparks,x=199,y=44,z=-534,r=2] add BEZ21_Sparks

