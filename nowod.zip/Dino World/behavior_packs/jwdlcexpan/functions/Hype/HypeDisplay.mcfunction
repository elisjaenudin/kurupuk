#say Hype Display

execute @s[scores={digit_1=0}] ~ ~ ~ /setblock 342 58 -442 jw:zero 0
execute @s[scores={digit_1=1}] ~ ~ ~ /setblock 342 58 -442 jw:one 0
execute @s[scores={digit_1=2}] ~ ~ ~ /setblock 342 58 -442 jw:two 0
execute @s[scores={digit_1=3}] ~ ~ ~ /setblock 342 58 -442 jw:three 0
execute @s[scores={digit_1=4}] ~ ~ ~ /setblock 342 58 -442 jw:four 0
execute @s[scores={digit_1=5}] ~ ~ ~ /setblock 342 58 -442 jw:five 0
execute @s[scores={digit_1=6}] ~ ~ ~ /setblock 342 58 -442 jw:six 0
execute @s[scores={digit_1=7}] ~ ~ ~ /setblock 342 58 -442 jw:seven 0
execute @s[scores={digit_1=8}] ~ ~ ~ /setblock 342 58 -442 jw:eight 0
execute @s[scores={digit_1=9}] ~ ~ ~ /setblock 342 58 -442 jw:nine 0

execute @s[scores={digit_2=0}] ~ ~ ~ /setblock 341 58 -442 jw:zero 0
execute @s[scores={digit_2=1}] ~ ~ ~ /setblock 341 58 -442 jw:one 0
execute @s[scores={digit_2=2}] ~ ~ ~ /setblock 341 58 -442 jw:two 0
execute @s[scores={digit_2=3}] ~ ~ ~ /setblock 341 58 -442 jw:three 0
execute @s[scores={digit_2=4}] ~ ~ ~ /setblock 341 58 -442 jw:four 0
execute @s[scores={digit_2=5}] ~ ~ ~ /setblock 341 58 -442 jw:five 0
execute @s[scores={digit_2=6}] ~ ~ ~ /setblock 341 58 -442 jw:six 0
execute @s[scores={digit_2=7}] ~ ~ ~ /setblock 341 58 -442 jw:seven 0
execute @s[scores={digit_2=8}] ~ ~ ~ /setblock 341 58 -442 jw:eight 0
execute @s[scores={digit_2=9}] ~ ~ ~ /setblock 341 58 -442 jw:nine 0

execute @s[scores={digit_3=0}] ~ ~ ~ /setblock 340 58 -442 jw:zero 0
execute @s[scores={digit_3=1}] ~ ~ ~ /setblock 340 58 -442 jw:one 0
execute @s[scores={digit_3=2}] ~ ~ ~ /setblock 340 58 -442 jw:two 0
execute @s[scores={digit_3=3}] ~ ~ ~ /setblock 340 58 -442 jw:three 0
execute @s[scores={digit_3=4}] ~ ~ ~ /setblock 340 58 -442 jw:four 0
execute @s[scores={digit_3=5}] ~ ~ ~ /setblock 340 58 -442 jw:five 0
execute @s[scores={digit_3=6}] ~ ~ ~ /setblock 340 58 -442 jw:six 0
execute @s[scores={digit_3=7}] ~ ~ ~ /setblock 340 58 -442 jw:seven 0
execute @s[scores={digit_3=8}] ~ ~ ~ /setblock 340 58 -442 jw:eight 0
execute @s[scores={digit_3=9}] ~ ~ ~ /setblock 340 58 -442 jw:nine 0

execute @s[scores={digit_4=0}] ~ ~ ~ /setblock 339 58 -442 jw:zero 0
execute @s[scores={digit_4=1}] ~ ~ ~ /setblock 339 58 -442 jw:one 0
execute @s[scores={digit_4=2}] ~ ~ ~ /setblock 339 58 -442 jw:two 0
execute @s[scores={digit_4=3}] ~ ~ ~ /setblock 339 58 -442 jw:three 0
execute @s[scores={digit_4=4}] ~ ~ ~ /setblock 339 58 -442 jw:four 0
execute @s[scores={digit_4=5}] ~ ~ ~ /setblock 339 58 -442 jw:five 0
execute @s[scores={digit_4=6}] ~ ~ ~ /setblock 339 58 -442 jw:six 0
execute @s[scores={digit_4=7}] ~ ~ ~ /setblock 339 58 -442 jw:seven 0
execute @s[scores={digit_4=8}] ~ ~ ~ /setblock 339 58 -442 jw:eight 0
execute @s[scores={digit_4=9}] ~ ~ ~ /setblock 339 58 -442 jw:nine 0

execute @s[scores={digit_5=0}] ~ ~ ~ /setblock 338 58 -442 jw:zero 0
execute @s[scores={digit_5=1}] ~ ~ ~ /setblock 338 58 -442 jw:one 0
execute @s[scores={digit_5=2}] ~ ~ ~ /setblock 338 58 -442 jw:two 0
execute @s[scores={digit_5=3}] ~ ~ ~ /setblock 338 58 -442 jw:three 0
execute @s[scores={digit_5=4}] ~ ~ ~ /setblock 338 58 -442 jw:four 0
execute @s[scores={digit_5=5}] ~ ~ ~ /setblock 338 58 -442 jw:five 0
execute @s[scores={digit_5=6}] ~ ~ ~ /setblock 338 58 -442 jw:six 0
execute @s[scores={digit_5=7}] ~ ~ ~ /setblock 338 58 -442 jw:seven 0
execute @s[scores={digit_5=8}] ~ ~ ~ /setblock 338 58 -442 jw:eight 0
execute @s[scores={digit_5=9}] ~ ~ ~ /setblock -14 58 -442 jw:nine 0

execute @s[scores={digit_6=0}] ~ ~ ~ /setblock 337 58 -442 jw:zero 0
execute @s[scores={digit_6=1}] ~ ~ ~ /setblock 337 58 -442 jw:one 0
execute @s[scores={digit_6=2}] ~ ~ ~ /setblock 337 58 -442 jw:two 0
execute @s[scores={digit_6=3}] ~ ~ ~ /setblock 337 58 -442 jw:three 0
execute @s[scores={digit_6=4}] ~ ~ ~ /setblock 337 58 -442 jw:four 0
execute @s[scores={digit_6=5}] ~ ~ ~ /setblock 337 58 -442 jw:five 0
execute @s[scores={digit_6=6}] ~ ~ ~ /setblock 337 58 -442 jw:six 0
execute @s[scores={digit_6=7}] ~ ~ ~ /setblock 337 58 -442 jw:seven 0
execute @s[scores={digit_6=8}] ~ ~ ~ /setblock 337 58 -442 jw:eight 0
execute @s[scores={digit_6=9}] ~ ~ ~ /setblock 337 58 -442 jw:nine 0

execute @s[scores={digit_7=0}] ~ ~ ~ /setblock 336 58 -442 jw:zero 0
execute @s[scores={digit_7=1}] ~ ~ ~ /setblock 336 58 -442 jw:one 0
execute @s[scores={digit_7=2}] ~ ~ ~ /setblock 336 58 -442 jw:two 0
execute @s[scores={digit_7=3}] ~ ~ ~ /setblock 336 58 -442 jw:three 0
execute @s[scores={digit_7=4}] ~ ~ ~ /setblock 336 58 -442 jw:four 0
execute @s[scores={digit_7=5}] ~ ~ ~ /setblock 336 58 -442 jw:five 0
execute @s[scores={digit_7=6}] ~ ~ ~ /setblock 336 58 -442 jw:six 0
execute @s[scores={digit_7=7}] ~ ~ ~ /setblock 336 58 -442 jw:seven 0
execute @s[scores={digit_7=8}] ~ ~ ~ /setblock 336 58 -442 jw:eight 0
execute @s[scores={digit_7=9}] ~ ~ ~ /setblock 336 58 -442 jw:nine 0

execute @s[scores={digit_8=0}] ~ ~ ~ /setblock 335 58 -442 jw:zero 0
execute @s[scores={digit_8=1}] ~ ~ ~ /setblock 335 58 -442 jw:one 0
execute @s[scores={digit_8=2}] ~ ~ ~ /setblock 335 58 -442 jw:two 0
execute @s[scores={digit_8=3}] ~ ~ ~ /setblock 335 58 -442 jw:three 0
execute @s[scores={digit_8=4}] ~ ~ ~ /setblock 335 58 -442 jw:four 0
execute @s[scores={digit_8=5}] ~ ~ ~ /setblock 335 58 -442 jw:five 0
execute @s[scores={digit_8=6}] ~ ~ ~ /setblock 335 58 -442 jw:six 0
execute @s[scores={digit_8=7}] ~ ~ ~ /setblock 335 58 -442 jw:seven 0
execute @s[scores={digit_8=8}] ~ ~ ~ /setblock 335 58 -442 jw:eight 0
execute @s[scores={digit_8=9}] ~ ~ ~ /setblock 335 58 -442 jw:nine 0
