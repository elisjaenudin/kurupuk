#say Time Display

scoreboard players operation cache digits = @s time_open_secs
scoreboard players operation cache2 digits = @s time_open_secs

function Hype/SetDigits

execute @s[scores={digit_1=0}] ~ ~ ~ /setblock 342 62 -442 jw:zero 0
execute @s[scores={digit_1=1}] ~ ~ ~ /setblock 342 62 -442 jw:one 0
execute @s[scores={digit_1=2}] ~ ~ ~ /setblock 342 62 -442 jw:two 0
execute @s[scores={digit_1=3}] ~ ~ ~ /setblock 342 62 -442 jw:three 0
execute @s[scores={digit_1=4}] ~ ~ ~ /setblock 342 62 -442 jw:four 0
execute @s[scores={digit_1=5}] ~ ~ ~ /setblock 342 62 -442 jw:five 0
execute @s[scores={digit_1=6}] ~ ~ ~ /setblock 342 62 -442 jw:six 0
execute @s[scores={digit_1=7}] ~ ~ ~ /setblock 342 62 -442 jw:seven 0
execute @s[scores={digit_1=8}] ~ ~ ~ /setblock 342 62 -442 jw:eight 0
execute @s[scores={digit_1=9}] ~ ~ ~ /setblock 342 62 -442 jw:nine 0

execute @s[scores={digit_2=0}] ~ ~ ~ /setblock 341 62 -442 jw:zero 0
execute @s[scores={digit_2=1}] ~ ~ ~ /setblock 341 62 -442 jw:one 0
execute @s[scores={digit_2=2}] ~ ~ ~ /setblock 341 62 -442 jw:two 0
execute @s[scores={digit_2=3}] ~ ~ ~ /setblock 341 62 -442 jw:three 0
execute @s[scores={digit_2=4}] ~ ~ ~ /setblock 341 62 -442 jw:four 0
execute @s[scores={digit_2=5}] ~ ~ ~ /setblock 341 62 -442 jw:five 0
execute @s[scores={digit_2=6}] ~ ~ ~ /setblock 341 62 -442 jw:six 0
execute @s[scores={digit_2=7}] ~ ~ ~ /setblock 341 62 -442 jw:seven 0
execute @s[scores={digit_2=8}] ~ ~ ~ /setblock 341 62 -442 jw:eight 0
execute @s[scores={digit_2=9}] ~ ~ ~ /setblock 341 62 -442 jw:nine 0



scoreboard players operation cache digits = @s time_open_mins
scoreboard players operation cache2 digits = @s time_open_mins
function Hype/SetDigits


execute @s[scores={digit_1=0}] ~ ~ ~ /setblock 339 62 -442 jw:zero 0
execute @s[scores={digit_1=1}] ~ ~ ~ /setblock 339 62 -442 jw:one 0
execute @s[scores={digit_1=2}] ~ ~ ~ /setblock 339 62 -442 jw:two 0
execute @s[scores={digit_1=3}] ~ ~ ~ /setblock 339 62 -442 jw:three 0
execute @s[scores={digit_1=4}] ~ ~ ~ /setblock 339 62 -442 jw:four 0
execute @s[scores={digit_1=5}] ~ ~ ~ /setblock 339 62 -442 jw:five 0
execute @s[scores={digit_1=6}] ~ ~ ~ /setblock 339 62 -442 jw:six 0
execute @s[scores={digit_1=7}] ~ ~ ~ /setblock 339 62 -442 jw:seven 0
execute @s[scores={digit_1=8}] ~ ~ ~ /setblock 339 62 -442 jw:eight 0
execute @s[scores={digit_1=9}] ~ ~ ~ /setblock 339 62 -442 jw:nine 0

execute @s[scores={digit_2=0}] ~ ~ ~ /setblock 338 62 -442 jw:zero 0
execute @s[scores={digit_2=1}] ~ ~ ~ /setblock 338 62 -442 jw:one 0
execute @s[scores={digit_2=2}] ~ ~ ~ /setblock 338 62 -442 jw:two 0
execute @s[scores={digit_2=3}] ~ ~ ~ /setblock 338 62 -442 jw:three 0
execute @s[scores={digit_2=4}] ~ ~ ~ /setblock 338 62 -442 jw:four 0
execute @s[scores={digit_2=5}] ~ ~ ~ /setblock 338 62 -442 jw:five 0
execute @s[scores={digit_2=6}] ~ ~ ~ /setblock 338 62 -442 jw:six 0
execute @s[scores={digit_2=7}] ~ ~ ~ /setblock 338 62 -442 jw:seven 0
execute @s[scores={digit_2=8}] ~ ~ ~ /setblock 338 62 -442 jw:eight 0
execute @s[scores={digit_2=9}] ~ ~ ~ /setblock 338 62 -442 jw:nine 0

scoreboard players operation cache digits = @s time_open_hrs
scoreboard players operation cache2 digits = @s time_open_hrs
function Hype/SetDigits

execute @s[scores={digit_1=0}] ~ ~ ~ /setblock 336 62 -442 jw:zero 0
execute @s[scores={digit_1=1}] ~ ~ ~ /setblock 336 62 -442 jw:one 0
execute @s[scores={digit_1=2}] ~ ~ ~ /setblock 336 62 -442 jw:two 0
execute @s[scores={digit_1=3}] ~ ~ ~ /setblock 336 62 -442 jw:three 0
execute @s[scores={digit_1=4}] ~ ~ ~ /setblock 336 62 -442 jw:four 0
execute @s[scores={digit_1=5}] ~ ~ ~ /setblock 336 62 -442 jw:five 0
execute @s[scores={digit_1=6}] ~ ~ ~ /setblock 336 62 -442 jw:six 0
execute @s[scores={digit_1=7}] ~ ~ ~ /setblock 336 62 -442 jw:seven 0
execute @s[scores={digit_1=8}] ~ ~ ~ /setblock 336 62 -442 jw:eight 0
execute @s[scores={digit_1=9}] ~ ~ ~ /setblock 336 62 -442 jw:nine 0

execute @s[scores={digit_2=0}] ~ ~ ~ /setblock 335 62 -442 jw:zero 0
execute @s[scores={digit_2=1}] ~ ~ ~ /setblock 335 62 -442 jw:one 0
execute @s[scores={digit_2=2}] ~ ~ ~ /setblock 335 62 -442 jw:two 0
execute @s[scores={digit_2=3}] ~ ~ ~ /setblock 335 62 -442 jw:three 0
execute @s[scores={digit_2=4}] ~ ~ ~ /setblock 335 62 -442 jw:four 0
execute @s[scores={digit_2=5}] ~ ~ ~ /setblock 335 62 -442 jw:five 0
execute @s[scores={digit_2=6}] ~ ~ ~ /setblock 335 62 -442 jw:six 0
execute @s[scores={digit_2=7}] ~ ~ ~ /setblock 335 62 -442 jw:seven 0
execute @s[scores={digit_2=8}] ~ ~ ~ /setblock 335 62 -442 jw:eight 0
execute @s[scores={digit_2=9}] ~ ~ ~ /setblock 335 62 -442 jw:nine 0
