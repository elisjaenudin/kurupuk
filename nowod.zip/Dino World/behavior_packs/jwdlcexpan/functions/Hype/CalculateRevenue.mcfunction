
scoreboard players operation @s revenue_per_min = @s Hype
scoreboard players operation @s revenue_per_min /= @s disaster_count
#scoreboard players operation @s revenue_per_min /= @s seconds_per_min

scoreboard players operation @s[scores={park_open=1}] total_revenue += @s revenue_per_min


#do disaster count
scoreboard players operation cache digits = @s disaster_count
scoreboard players add cache digits -1
scoreboard players operation cache2 digits = @s disaster_count
scoreboard players add cache2 digits -1
function Hype/SetDigits
function Hype/DisasterDisplay

#do hype digits
scoreboard players operation cache digits = @s Hype
scoreboard players operation cache2 digits = @s Hype
function Hype/SetDigits
function Hype/HypeDisplay

#do Total Revenue Digits
scoreboard players operation cache digits = @s total_revenue
scoreboard players operation cache2 digits = @s total_revenue
function Hype/SetDigits
function Hype/TotalRevenueDisplay

# is our score higher than our previous hi_score? set it to the new value
scoreboard players operation @s high_score_chk = @s high_score
scoreboard players operation @s high_score_chk -= @s total_revenue

#if the delta is negative, our current score is higher than our high score, so update highscore
execute @s[scores={high_score_chk=..0}] ~ ~ ~ /scoreboard players operation @s high_score = @s total_revenue

#do hi score Digits
scoreboard players operation cache digits = @s high_score
scoreboard players operation cache2 digits = @s high_score
function Hype/SetDigits
function Hype/HiScoreDisplay


function Hype/TimeDisplay