#say figuring out the digits

scoreboard players operation cache digits %= ones digits
scoreboard players operation @s digit_1 = cache digits
scoreboard players operation cache2 digits -= @s digit_1
scoreboard players operation cache digits = cache2 digits

scoreboard players operation cache digits %= tens digits
scoreboard players operation @s digit_2 = cache digits
scoreboard players operation cache2 digits -= @s digit_2
scoreboard players operation cache digits = cache2 digits
scoreboard players operation @s digit_2 /= ones digits

scoreboard players operation cache digits %= hundreds digits
scoreboard players operation @s digit_3 = cache digits
scoreboard players operation cache2 digits -= @s digit_3
scoreboard players operation cache digits = cache2 digits
scoreboard players operation @s digit_3 /= tens digits

scoreboard players operation cache digits %= thousands digits
scoreboard players operation @s digit_4 = cache digits
scoreboard players operation cache2 digits -= @s digit_4
scoreboard players operation cache digits = cache2 digits
scoreboard players operation @s digit_4 /= hundreds digits

scoreboard players operation cache digits %= 10_thousands digits
scoreboard players operation @s digit_5 = cache digits
scoreboard players operation cache2 digits -= @s digit_5
scoreboard players operation cache digits = cache2 digits
scoreboard players operation @s digit_5 /= thousands digits

scoreboard players operation cache digits %= 100_thousands digits
scoreboard players operation @s digit_6 = cache digits
scoreboard players operation cache2 digits -= @s digit_6
scoreboard players operation cache digits = cache2 digits
scoreboard players operation @s digit_6 /= 10_thousands digits

scoreboard players operation cache digits %= millions digits
scoreboard players operation @s digit_7 = cache digits
scoreboard players operation cache2 digits -= @s digit_7
scoreboard players operation cache digits = cache2 digits
scoreboard players operation @s digit_7 /= 100_thousands digits

scoreboard players operation cache digits %= 10_millions digits
scoreboard players operation @s digit_8 = cache digits
scoreboard players operation cache2 digits -= @s digit_8
scoreboard players operation cache digits = cache2 digits
scoreboard players operation @s digit_8 /= millions digits