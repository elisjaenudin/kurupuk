#say Hype Reset
scoreboard players set @e[tag=disaster_system] total_revenue 0 


scoreboard players set @e[tag=disaster_system] revenue_per_min 0


scoreboard players set @e[tag=disaster_system] digit_1 0
scoreboard players set @e[tag=disaster_system] digit_2 0
scoreboard players set @e[tag=disaster_system] digit_3 0
scoreboard players set @e[tag=disaster_system] digit_4 0
scoreboard players set @e[tag=disaster_system] digit_5 0
scoreboard players set @e[tag=disaster_system] digit_6 0
scoreboard players set @e[tag=disaster_system] digit_7 0
scoreboard players set @e[tag=disaster_system] digit_8 0
