#say Hype Setup

scoreboard objectives add Hype dummy
scoreboard players set @e[tag=disaster_system] Hype 0

scoreboard objectives add total_revenue dummy
scoreboard players set @e[tag=disaster_system] total_revenue 0 

scoreboard objectives add high_score dummy
scoreboard players set @e[tag=disaster_system] high_score 0 

scoreboard objectives add high_score_chk dummy
scoreboard players set @e[tag=disaster_system] high_score_chk 0 

scoreboard objectives add revenue_per_min dummy
scoreboard players set @e[tag=disaster_system] revenue_per_min 0

scoreboard objectives add seconds_per_min dummy
scoreboard players set @e[tag=disaster_system] seconds_per_min 60

scoreboard objectives add digits dummy
scoreboard players set cache digits 0
scoreboard players set cache2 digits 0
scoreboard players set ones digits 10
scoreboard players set tens digits 100
scoreboard players set hundreds digits 1000
scoreboard players set thousands digits 10000
scoreboard players set 10_thousands digits 100000
scoreboard players set 100_thousands digits 1000000
scoreboard players set millions digits 10000000
scoreboard players set 10_millions digits 100000000

scoreboard objectives add digit_1 dummy
scoreboard players set @e[tag=disaster_system] digit_1 0
scoreboard objectives add digit_2 dummy
scoreboard players set @e[tag=disaster_system] digit_2 0
scoreboard objectives add digit_3 dummy
scoreboard players set @e[tag=disaster_system] digit_3 0
scoreboard objectives add digit_4 dummy
scoreboard players set @e[tag=disaster_system] digit_4 0
scoreboard objectives add digit_5 dummy
scoreboard players set @e[tag=disaster_system] digit_5 0
scoreboard objectives add digit_6 dummy
scoreboard players set @e[tag=disaster_system] digit_6 0
scoreboard objectives add digit_7 dummy
scoreboard players set @e[tag=disaster_system] digit_7 0
scoreboard objectives add digit_8 dummy
scoreboard players set @e[tag=disaster_system] digit_8 0

#create scores for every dinosaur :0

#===============Apatosaurus===================
#Apatosaurus
scoreboard objectives add apato dummy
scoreboard players set @e[tag=disaster_system] apato 0

#Colorful Apatosaurus
scoreboard objectives add apato_color dummy
scoreboard players set @e[tag=disaster_system] apato_color 0

#Bio-luminescent Apatosaurus
scoreboard objectives add apato_lumin dummy
scoreboard players set @e[tag=disaster_system] apato_lumin 0

#Stealth Apatosaurus
scoreboard objectives add apato_stealth dummy
scoreboard players set @e[tag=disaster_system] apato_stealth 0

#===============Brachiosaurus===================
#Brachiosaurus
scoreboard objectives add brachio dummy
scoreboard players set @e[tag=disaster_system] brachio 0

#Colorful Brachiosaurus
scoreboard objectives add brachio_color dummy
scoreboard players set @e[tag=disaster_system] brachio_color 0

#Bio-luminescent Brachiosaurus
scoreboard objectives add brachio_lumin dummy
scoreboard players set @e[tag=disaster_system] brachio_lumin 0

#Stealth Brachiosaurus
scoreboard objectives add brachio_stealth dummy
scoreboard players set @e[tag=disaster_system] brachio_stealth 0

#===============Dilophosaurus===================
#Dilophosaurus
scoreboard objectives add dilopho dummy
scoreboard players set @e[tag=disaster_system] dilopho 0

#Colorful Dilophosaurus
scoreboard objectives add dilopho_color dummy
scoreboard players set @e[tag=disaster_system] dilopho_color 0

#Bio-luminescent Dilophosaurus
scoreboard objectives add dilopho_lumin dummy
scoreboard players set @e[tag=disaster_system] dilopho_lumin 0

#Stealth Dilophosaurus
scoreboard objectives add dilopho_stealth dummy
scoreboard players set @e[tag=disaster_system] dilopho_stealth 0

#===============Gallimimus===================
#Gallimimus
scoreboard objectives add galli dummy
scoreboard players set @e[tag=disaster_system] galli 0

#Colorful Gallimimus
scoreboard objectives add galli_color dummy
scoreboard players set @e[tag=disaster_system] galli_color 0

#Bio-luminescent Gallimimus
scoreboard objectives add galli_lumin dummy
scoreboard players set @e[tag=disaster_system] galli_lumin 0

#Stealth Gallimimus
scoreboard objectives add galli_stealth dummy
scoreboard players set @e[tag=disaster_system] galli_stealth 0

#===============Parasaurolophus===================
#Parasaurolophus
scoreboard objectives add para dummy
scoreboard players set @e[tag=disaster_system] para 0

#Colorful Parasaurolophus
scoreboard objectives add para_color dummy
scoreboard players set @e[tag=disaster_system] para_color 0

#Bio-luminescent Parasaurolophus
scoreboard objectives add para_lumin dummy
scoreboard players set @e[tag=disaster_system] para_lumin 0

#Stealth Parasaurolophus
scoreboard objectives add para_stealth dummy
scoreboard players set @e[tag=disaster_system] para_stealth 0

#===============Triceratops===================
#Triceratops
scoreboard objectives add trice dummy
scoreboard players set @e[tag=disaster_system] trice 0

#Colorful Triceratops
scoreboard objectives add trice_color dummy
scoreboard players set @e[tag=disaster_system] trice_color 0

#Bio-luminescent Triceratops
scoreboard objectives add trice_lumin dummy
scoreboard players set @e[tag=disaster_system] trice_lumin 0

#Stealth Triceratops
scoreboard objectives add trice_stealth dummy
scoreboard players set @e[tag=disaster_system] trice_stealth 0

#===============Tyrannosaurus Rex===================
#Tyrannosaurus Rex
scoreboard objectives add trex dummy
scoreboard players set @e[tag=disaster_system] trex 0

#Colorful Tyrannosaurus Rex
scoreboard objectives add trex_color dummy
scoreboard players set @e[tag=disaster_system] trex_color 0

#Bio-luminescent Tyrannosaurus Rex
scoreboard objectives add trex_lumin dummy
scoreboard players set @e[tag=disaster_system] trex_lumin 0

#Stealth Tyrannosaurus Rex
scoreboard objectives add trex_stealth dummy
scoreboard players set @e[tag=disaster_system] trex_stealth 0

#===============Velociraptor===================
#Velociraptor
scoreboard objectives add veloc dummy
scoreboard players set @e[tag=disaster_system] veloc 0

#Colorful Velociraptor
scoreboard objectives add veloc_color dummy
scoreboard players set @e[tag=disaster_system] veloc_color 0

#Bio-luminescent Velociraptor
scoreboard objectives add veloc_lumin dummy
scoreboard players set @e[tag=disaster_system] veloc_lumin 0

#Stealth Velociraptor
scoreboard objectives add veloc_stealth dummy
scoreboard players set @e[tag=disaster_system] veloc_stealth 0

#===============Compsognathus===================
#Compsognathus
scoreboard objectives add compy dummy
scoreboard players set @e[tag=disaster_system] compy 0

#Colorful Compsognathus
scoreboard objectives add compy_color dummy
scoreboard players set @e[tag=disaster_system] compy_color 0

#Bio-luminescent Compsognathus
scoreboard objectives add compy_lumin dummy
scoreboard players set @e[tag=disaster_system] compy_lumin 0

#Stealth Compsognathus
scoreboard objectives add compy_stealth dummy
scoreboard players set @e[tag=disaster_system] compy_stealth 0

#===============Pteranodon===================
#Pteranodon
scoreboard objectives add ptera dummy
scoreboard players set @e[tag=disaster_system] ptera 0

#Colorful Pteranodon
scoreboard objectives add ptera_color dummy
scoreboard players set @e[tag=disaster_system] ptera_color 0

#Bio-luminescent Pteranodon
scoreboard objectives add ptera_lumin dummy
scoreboard players set @e[tag=disaster_system] ptera_lumin 0

#Stealth Pteranodon
scoreboard objectives add ptera_stealth dummy
scoreboard players set @e[tag=disaster_system] ptera_stealth 0

#===============Stegosaurus===================
#Stegosaurus
scoreboard objectives add stego dummy
scoreboard players set @e[tag=disaster_system] stego 0

#Colorful Stegosaurus
scoreboard objectives add stego_color dummy
scoreboard players set @e[tag=disaster_system] stego_color 0

#Bio-luminescent Stegosaurus
scoreboard objectives add stego_lumin dummy
scoreboard players set @e[tag=disaster_system] stego_lumin 0

#Stealth Stegosaurus
scoreboard objectives add stego_stealth dummy
scoreboard players set @e[tag=disaster_system] stego_stealth 0

#===============Ankylosaurus===================
#Ankylosaurus
scoreboard objectives add ankyl dummy
scoreboard players set @e[tag=disaster_system] ankyl 0

#Colorful Ankylosaurus
scoreboard objectives add ankyl_color dummy
scoreboard players set @e[tag=disaster_system] ankyl_color 0

#Bio-luminescent Ankylosaurus
scoreboard objectives add ankyl_lumin dummy
scoreboard players set @e[tag=disaster_system] ankyl_lumin 0

#Stealth Ankylosaurus
scoreboard objectives add ankyl_stealth dummy
scoreboard players set @e[tag=disaster_system] ankyl_stealth 0

#===============Spinosaurus===================
#Spinosaurus
scoreboard objectives add spino dummy
scoreboard players set @e[tag=disaster_system] spino 0

#Colorful Spinosaurus
scoreboard objectives add spino_color dummy
scoreboard players set @e[tag=disaster_system] spino_color 0

#Bio-luminescent Spinosaurus
scoreboard objectives add spino_lumin dummy
scoreboard players set @e[tag=disaster_system] spino_lumin 0

#Stealth Spinosaurus
scoreboard objectives add spino_stealth dummy
scoreboard players set @e[tag=disaster_system] spino_stealth 0

#===============Dimorphodon===================
#Dimorphodon
scoreboard objectives add dimor dummy
scoreboard players set @e[tag=disaster_system] dimor 0

#Colorful Dimorphodon
scoreboard objectives add dimor_color dummy
scoreboard players set @e[tag=disaster_system] dimor_color 0

#Bio-luminescent Dimorphodon
scoreboard objectives add dimor_lumin dummy
scoreboard players set @e[tag=disaster_system] dimor_lumin 0

#Stealth Dimorphodon
scoreboard objectives add dimor_stealth dummy
scoreboard players set @e[tag=disaster_system] dimor_stealth 0

#===============Mosasaurus===================
#Mosasaurus
scoreboard objectives add mosa dummy
scoreboard players set @e[tag=disaster_system] mosa 1

#Colorful Mosasaurus
scoreboard objectives add mosa_color dummy
scoreboard players set @e[tag=disaster_system] mosa_color 0

#Bio-luminescent Mosasaurus
scoreboard objectives add mosa_lumin dummy
scoreboard players set @e[tag=disaster_system] mosa_lumin 0

#Stealth Mosasaurus
scoreboard objectives add mosa_stealth dummy
scoreboard players set @e[tag=disaster_system] mosa_stealth 0

#===============Carnotaurus===================
#Carnotaurus
scoreboard objectives add carno dummy
scoreboard players set @e[tag=disaster_system] carno 0

#Colorful Carnotaurus
scoreboard objectives add carno_color dummy
scoreboard players set @e[tag=disaster_system] carno_color 0

#Bio-luminescent Carnotaurus
scoreboard objectives add carno_lumin dummy
scoreboard players set @e[tag=disaster_system] carno_lumin 0

#Stealth Carnotaurus
scoreboard objectives add carno_stealth dummy
scoreboard players set @e[tag=disaster_system] carno_stealth 0

#===============Stygimoloch===================
#Stygimoloch
scoreboard objectives add styg dummy
scoreboard players set @e[tag=disaster_system] styg 0

#Colorful Stygimoloch
scoreboard objectives add styg_color dummy
scoreboard players set @e[tag=disaster_system] styg_color 0

#Bio-luminescent Stygimoloch
scoreboard objectives add styg_lumin dummy
scoreboard players set @e[tag=disaster_system] styg_lumin 0

#Stealth Stygimoloch
scoreboard objectives add styg_stealth dummy
scoreboard players set @e[tag=disaster_system] styg_stealth 0

#===============Hybrids===================

#===============Indoraptor===================
scoreboard objectives add indoraptor dummy
scoreboard players set @e[tag=disaster_system] indoraptor 0

#===============Indominus Rex===================
scoreboard objectives add indomrex dummy
scoreboard players set @e[tag=disaster_system] indomrex 0

#===============Cute Dinosaur===================
scoreboard objectives add cutey dummy
scoreboard players set @e[tag=disaster_system] cutey 0

#===============Ally===================
scoreboard objectives add ally dummy
scoreboard players set @e[tag=disaster_system] ally 0

#===============Armored Carnivore===================
scoreboard objectives add armcarni dummy
scoreboard players set @e[tag=disaster_system] armcarni 0

#===============Cute Flyer===================
scoreboard objectives add cutefly dummy
scoreboard players set @e[tag=disaster_system] cutefly 0

#===============Hybrid Quadruped===================
scoreboard objectives add hybridquad dummy
scoreboard players set @e[tag=disaster_system] hybridquad 0

#===============Feathered Raptor===================
scoreboard objectives add featherraptor dummy
scoreboard players set @e[tag=disaster_system] featherraptor 0

#===============Cute Water Herbivore===================
scoreboard objectives add cuteherb dummy
scoreboard players set @e[tag=disaster_system] cuteherb 0

#===============Amphibious Flying===================
scoreboard objectives add amphfly dummy
scoreboard players set @e[tag=disaster_system] amphfly 0

#===============Ridable Huge Herbivore===================
scoreboard objectives add rideherb dummy
scoreboard players set @e[tag=disaster_system] rideherb 0




#==============Limits========================

#compy limits
scoreboard objectives add compy_limits dummy
scoreboard players set @e[tag=disaster_system] compy_limits 5

#cute limits
scoreboard objectives add cute_limits dummy
scoreboard players set @e[tag=disaster_system] cute_limits 3

#amphibious flying limits
scoreboard objectives add amphfly_limits dummy
scoreboard players set @e[tag=disaster_system] amphfly_limits 10

#===============Theme Bonuses===================
scoreboard objectives add historical dummy
scoreboard players set @e[tag=disaster_system] historical 0

scoreboard objectives add colorful dummy
scoreboard players set @e[tag=disaster_system] colorful 0

scoreboard objectives add bioluminescent dummy
scoreboard players set @e[tag=disaster_system] bioluminescent 0

scoreboard objectives add stealth dummy
scoreboard players set @e[tag=disaster_system] stealth 0


scoreboard objectives add experimental dummy
scoreboard players set @e[tag=disaster_system] experimental 0


#===============Island Development===================
scoreboard objectives add exhibit_a dummy
scoreboard players set @e[tag=disaster_system] exhibit_a 0

scoreboard objectives add exhibit_b dummy
scoreboard players set @e[tag=disaster_system] exhibit_b 0

scoreboard objectives add exhibit_c dummy
scoreboard players set @e[tag=disaster_system] exhibit_c 0

scoreboard objectives add exhibit_d dummy
scoreboard players set @e[tag=disaster_system] exhibit_d 0

scoreboard objectives add exhibit_e dummy
scoreboard players set @e[tag=disaster_system] exhibit_e 0

scoreboard objectives add exhibit_f dummy
scoreboard players set @e[tag=disaster_system] exhibit_f 0

scoreboard objectives add exhibit_g dummy
scoreboard players set @e[tag=disaster_system] exhibit_g 0

setblock 344 10 -424 sponge
