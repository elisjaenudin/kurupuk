#say Calculating Hype!

scoreboard players set @s Hype 0

#check for every dino
#===============Apatosaurus===================
#Apatosaurus - apato
scoreboard players add @s[scores={apato=1..}] Hype 20

#Colorful Apatosaurus - apato_color
scoreboard players add @s[scores={apato_color=1..}] Hype 30

#Bio-luminescent Apatosaurus - apato_lumin
scoreboard players add @s[scores={apato_lumin=1..}] Hype 30


#===============Brachiosaurus===================
#Brachiosaurus - brachio
scoreboard players add @s[scores={brachio=1..}] Hype 40

#Colorful Brachiosaurus - brachio_color
scoreboard players add @s[scores={brachio_color=1..}] Hype 60

#Bio-luminescent Brachiosaurus - brachio_lumin
scoreboard players add @s[scores={brachio_lumin=1..}] Hype 60


#===============Dilophosaurus===================
#Dilophosaurus - dilopho
scoreboard players add @s[scores={dilopho=1..}] Hype 40

#Colorful Dilophosaurus - dilopho_color
scoreboard players add @s[scores={dilopho_color=1..}] Hype 60

#Bio-luminescent Dilophosaurus - dilopho_lumin
scoreboard players add @s[scores={dilopho_lumin=1..}] Hype 60


#===============Gallimimus===================
#Gallimimus - galli
scoreboard players add @s[scores={galli=1..}] Hype 10

#Colorful Gallimimus - galli_color
scoreboard players add @s[scores={galli_color=1..}] Hype 30

#Bio-luminescent Gallimimus - galli_lumin
scoreboard players add @s[scores={galli_lumin=1..}] Hype 30


#===============Parasaurolophus===================
#Parasaurolophus - para
scoreboard players add @s[scores={para=1..}] Hype 20

#Colorful Parasaurolophus - para_color
scoreboard players add @s[scores={para_color=1..}] Hype 30

#Bio-luminescent Parasaurolophus - para_lumin
scoreboard players add @s[scores={para_lumin=1..}] Hype 30


#===============Triceratops===================
#Triceratops - trice
scoreboard players add @s[scores={trice=1..}] Hype 30

#Colorful Triceratops - trice_color
scoreboard players add @s[scores={trice_color=1..}] Hype 50

#Bio-luminescent Triceratops - trice_lumin
scoreboard players add @s[scores={trice_lumin=1..}] Hype 50


#===============Tyrannosaurus Rex===================
#Tyrannosaurus Rex - trex
scoreboard players add @s[scores={trex=1..}] Hype 80

#Colorful Tyrannosaurus Rex - trex_color
scoreboard players add @s[scores={trex_color=1..}] Hype 110

#Bio-luminescent Tyrannosaurus Rex - trex_lumin
scoreboard players add @s[scores={trex_lumin=1..}] Hype 110


#===============Velociraptor===================
#Velociraptor - veloc
scoreboard players add @s[scores={veloc=1..}] Hype 40

#Colorful Velociraptor - veloc_color
scoreboard players add @s[scores={veloc_color=1..}] Hype 60

#Bio-luminescent Velociraptor - veloc_lumin
scoreboard players add @s[scores={veloc_lumin=1..}] Hype 60


#===============Compsognathus===================
#Compsognathus - compy
scoreboard players add @s[scores={compy=1..}] Hype 20

#Colorful Compsognathus - compy_color
scoreboard players add @s[scores={compy_color=1..}] Hype 30

#Bio-luminescent Compsognathus - compy_lumin
scoreboard players add @s[scores={compy_lumin=1..}] Hype 30


#===============Pteranodon===================
#Pteranodon - ptera
scoreboard players add @s[scores={ptera=1..}] Hype 60

#Colorful Pteranodon - ptera_color
scoreboard players add @s[scores={ptera_color=1..}] Hype 80

#Bio-luminescent Pteranodon - ptera_lumin
scoreboard players add @s[scores={ptera_lumin=1..}] Hype 80


#===============Stegosaurus===================
#Stegosaurus - stego
scoreboard players add @s[scores={stego=1..}] Hype 30

#Colorful Stegosaurus - stego_color
scoreboard players add @s[scores={stego_color=1..}] Hype 50

#Bio-luminescent Stegosaurus - stego_lumin
scoreboard players add @s[scores={stego_lumin=1..}] Hype 50


#===============Ankylosaurus===================
#Ankylosaurus - ankyl
scoreboard players add @s[scores={ankyl=1..}] Hype 20

#Colorful Ankylosaurus - ankyl_color
scoreboard players add @s[scores={ankyl_color=1..}] Hype 30

#Bio-luminescent Ankylosaurus - ankyl_lumin
scoreboard players add @s[scores={ankyl_lumin=1..}] Hype 30


#===============Spinosaurus===================
#Spinosaurus - spino
scoreboard players add @s[scores={spino=1..}] Hype 50

#Colorful Spinosaurus - spino_color
scoreboard players add @s[scores={spino_color=1..}] Hype 70

#Bio-luminescent Spinosaurus - spino_lumin
scoreboard players add @s[scores={spino_lumin=1..}] Hype 70


#===============Dimorphodon===================
#Dimorphodon - dimor
scoreboard players add @s[scores={dimor=1..}] Hype 20

#Colorful Dimorphodon - dimor_color
scoreboard players add @s[scores={dimor_color=1..}] Hype 30

#Bio-luminescent Dimorphodon - dimor_lumin
scoreboard players add @s[scores={dimor_lumin=1..}] Hype 30


#===============Mosasaurus===================
#Mosasaurus - mosa
scoreboard players add @s[scores={mosa=1..}] Hype 110

#Colorful Mosasaurus - mosa_color
scoreboard players add @s[scores={mosa_color=1..}] Hype 10

#Bio-luminescent Mosasaurus - mosa_lumin
scoreboard players add @s[scores={mosa_lumin=1..}] Hype 10


#===============Carnotaurus===================
#Carnotaurus - carno
scoreboard players add @s[scores={carno=1..}] Hype 40

#Colorful Carnotaurus - carno_color
scoreboard players add @s[scores={carno_color=1..}] Hype 60

#Bio-luminescent Carnotaurus - carno_lumin
scoreboard players add @s[scores={carno_lumin=1..}] Hype 60


#===============Stygimoloch===================
#Stygimoloch - styg
scoreboard players add @s[scores={styg=1..}] Hype 20

#Colorful Stygimoloch - styg_color
scoreboard players add @s[scores={styg_color=1..}] Hype 30

#Bio-luminescent Stygimoloch - styg_lumin
scoreboard players add @s[scores={styg_lumin=1..}] Hype 30


#===============Hybrids===================

#===============Indoraptor=================== indoraptor
scoreboard players add @s[scores={indoraptor=1..}] Hype 130

#===============Indominus Rex=================== indomrex
scoreboard players add @s[scores={indomrex=1..}] Hype 130

#===============Cute Dinosaur=================== cutey
scoreboard players add @s[scores={cutey=1..}] Hype 80

#===============Ally=================== ally
scoreboard players add @s[scores={ally=1..}] Hype 80

#===============Armored Carnivore=================== armcarni
scoreboard players add @s[scores={armcarni=1..}] Hype 110

#===============Cute Flyer=================== cutefly
scoreboard players add @s[scores={cutefly=1..}] Hype 80

#===============Hybrid Quadruped=================== hybridquad
scoreboard players add @s[scores={hybridquad=1..}] Hype 80


#===============Feathered Raptor=================== featherraptor
scoreboard players add @s[scores={featherraptor=1..}] Hype 70

#===============Cute Water Herbivore=================== cuteherb
scoreboard players add @s[scores={cuteherb=1..}] Hype 80

#===============Amphibious Flying=================== amphfly
scoreboard players add @s[scores={amphfly=1..}] Hype 120

#===============Ridable Huge Herbivore=================== rideherb
scoreboard players add @s[scores={rideherb=1..}] Hype 110

#===============Theme Bonuses===================
execute @s[scores={apato=!0,brachio=!0,dilopho=!0,galli=!0,para=!0,trice=!0,trex=!0,veloc=!0,compy=!0,ptera=!0,stego=!0,ankyl=!0,spino=!0,dimor=!0,mosa=!0,carno=!0,styg=!0}] ~ ~ ~ /scoreboard players add @s historical 1
execute @s[scores={historical=1..}] ~ ~ ~ /scoreboard players add @s Hype 500

#---------------colorful------------
execute @s[scores={apato_color=!0,brachio_color=!0,dilopho_color=!0,galli_color=!0,para_color=!0,trice_color=!0,trex_color=!0,veloc_color=!0,compy_color=!0,ptera_color=!0,stego_color=!0,ankyl_color=!0,spino_color=!0,dimor_color=!0,mosa_color=!0,carno_color=!0,styg_color=!0}] ~ ~ ~ /scoreboard players add @s colorful 1
execute @s[scores={colorful=1..}] ~ ~ ~ /scoreboard players add @s Hype 2000

#---------------bioluminescent------------
execute @s[scores={apato_lumin=!0,brachio_lumin=!0,dilopho_lumin=!0,galli_lumin=!0,para_lumin=!0,trice_lumin=!0,trex_lumin=!0,veloc_lumin=!0,compy_lumin=!0,ptera_lumin=!0,stego_lumin=!0,ankyl_lumin=!0,spino_lumin=!0,dimor_lumin=!0,mosa_lumin=!0,carno_lumin=!0,styg_lumin=!0}] ~ ~ ~ /scoreboard players add @s bioluminescent 1
execute @s[scores={bioluminescent=1..}] ~ ~ ~ /scoreboard players add @s Hype 2000

#---------------experimental------------
execute @s[scores={indoraptor=!0,indomrex=!0,cutey=!0,ally=!0,armcarni=!0,cutefly=!0,hybridquad=!0,featherraptor=!0,cuteherb=!0,amphfly=!0,rideherb=!0}] ~ ~ ~ /scoreboard players add @s experimental 1
execute @s[scores={experimental=1..}] ~ ~ ~ /scoreboard players add @s Hype 2000

#===============island development===================

#---------------Exhibit A------------
execute @s[scores={exhibit_a=1..}] ~ ~ ~ /scoreboard players add @s Hype 110

#---------------Exhibit B------------
execute @s[scores={exhibit_b=1..}] ~ ~ ~ /scoreboard players add @s Hype 110

#---------------Exhibit C------------
execute @s[scores={exhibit_c=1..}] ~ ~ ~ /scoreboard players add @s Hype 110

#---------------Exhibit D------------
execute @s[scores={exhibit_d=1..}] ~ ~ ~ /scoreboard players add @s Hype 110

#---------------Exhibit E------------
execute @s[scores={exhibit_e=1..}] ~ ~ ~ /scoreboard players add @s Hype 110

#---------------Exhibit F------------
execute @s[scores={exhibit_f=1..}] ~ ~ ~ /scoreboard players add @s Hype 110

#---------------Exhibit G------------
execute @s[scores={exhibit_g=1..}] ~ ~ ~ /scoreboard players add @s Hype 110


function Hype/CalculateRevenue

execute @s ~ ~ ~ detect 342 55 -432 lever 5 /fill 344 10 -424 344 10 -424 redstone_block 0 replace sponge
