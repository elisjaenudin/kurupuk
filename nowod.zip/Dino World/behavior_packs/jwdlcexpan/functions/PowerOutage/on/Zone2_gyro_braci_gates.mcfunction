#=========================== poweroffmain - turn on Gyro Braci gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Gyro Braci Gates ON

#gates
fill 242 53 -510 245 56 -506 stained_hardened_clay 13 replace air 0
fill 192 43 -533 188 46 -530 stained_hardened_clay 13 replace air 0



