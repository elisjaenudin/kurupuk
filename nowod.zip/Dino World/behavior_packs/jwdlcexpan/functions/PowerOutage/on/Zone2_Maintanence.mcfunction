#=========================== poweronmain - turn on zone 2 Maintanence =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Maintenance On

#Lights
fill 256 66 -500 256 66 -500 end_rod 4 replace air 0
fill 257 66 -500 257 66 -500 end_rod 5 replace air 0
fill 262 66 -500 262 66 -500 end_rod 4 replace air 0
fill 263 66 -500 263 66 -500 end_rod 5 replace air 0








