#=========================== poweronmain - turn on zone 3 Maintanence =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Maintenance On

#Lights
fill 545 52 -612 545 52 -612 end_rod 2 replace air 0
fill 545 52 -611 545 52 -611 end_rod 3 replace air 0
fill 537 52 -611 537 52 -611 end_rod 3 replace air 0
fill 537 52 -612 537 52 -612 end_rod 2 replace air 0

#lights acu
fill 567 53 -614 567 53 -614 end_rod 5 replace air 0
fill 566 53 -614 566 53 -614 end_rod 4 replace air 0
fill 561 53 -614 561 53 -614 end_rod 5 replace air 0
fill 560 53 -614 560 53 -614 end_rod 4 replace air 0
fill 560 53 -602 560 53 -602 end_rod 4 replace air 0
fill 561 53 -602 561 53 -602 end_rod 5 replace air 0
fill 566 53 -602 566 53 -602 end_rod 4 replace air 0
fill 567 53 -602 567 53 -602 end_rod 5 replace air 0

#gates
fill 550 47 -598 554 50 -598 stained_hardened_clay 13 replace air 0
fill 550 47 -600 554 50 -600 stained_hardened_clay 13 replace air 0

scoreboard players set @e[tag=power_zone_math] zone3loaded 6
tickingarea remove gallimain
tickingarea add 794 66 -528 870 66 -456 raptorpad