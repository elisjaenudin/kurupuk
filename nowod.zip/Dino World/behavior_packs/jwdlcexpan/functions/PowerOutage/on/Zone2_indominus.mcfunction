#=========================== poweroffmain - turn on Indominus paddock =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Indominus On

#gate
fill 362 74 -702 362 82 -706 air 0 replace nether_brick
fill 362 74 -702 362 82 -706 air 0 replace stonebrick
fill 362 74 -701 362 82 -701 nether_brick 0 replace air 0
fill 362 74 -699 362 82 -699 nether_brick 0 replace air 0
fill 362 74 -697 362 82 -697 nether_brick 0 replace air 0
fill 362 74 -700 362 74 -700 nether_brick 0 replace air 0
fill 362 75 -700 362 75 -700 stonebrick 0 replace air 0
fill 362 76 -700 362 76 -700 nether_brick 0 replace air 0
fill 362 77 -700 362 79 -700 stonebrick 0 replace air 0
fill 362 80 -700 362 80 -700 nether_brick 0 replace air 0
fill 362 81 -700 362 81 -700 stonebrick 0 replace air 0
fill 362 82 -700 362 82 -700 nether_brick 0 replace air 0
fill 362 74 -698 362 74 -698 nether_brick 0 replace air 0
fill 362 75 -698 362 75 -698 stonebrick 0 replace air 0
fill 362 76 -698 362 76 -698 nether_brick 0 replace air 0
fill 362 77 -698 362 79 -698 stonebrick 0 replace air 0
fill 362 80 -698 362 80 -698 nether_brick 0 replace air 0
fill 362 81 -698 362 81 -698 stonebrick 0 replace air 0
fill 362 82 -698 362 82 -698 nether_brick 0 replace air 0

#Lights in Control Room
fill 349 84 -678 349 84 -678 redstone_block 0 replace air 0
fill 340 84 -678 340 84 -678 redstone_block 0 replace air 0
fill 351 77 -678 351 77 -678 redstone_block 0 replace air 0




scoreboard players set @e[tag=power_zone_math] zone2loaded 6
tickingarea remove indominus
tickingarea add 288 99 -764 323 120 -797 powstation