#=========================== poweronmain - turn on aviary_monorail lights =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Aviary Monorail On

#lights
fill 707 55 -387 708 55 -388 sealantern 0 replace air 0
fill 707 55 -398 708 55 -399 sealantern 0 replace air 0

scoreboard players set @e[tag=power_zone_math] zone3loaded 2
tickingarea remove aviarymono
tickingarea add 463 46 -455 476 52 -440 galligates