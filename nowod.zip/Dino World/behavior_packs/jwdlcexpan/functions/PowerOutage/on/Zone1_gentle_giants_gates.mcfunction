#=========================== poweroffmain - turn on gentle giants gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Gentle Giants On

#gates
fill 459 48 -310 459 48 -310 acacia_fence_gate 3 replace acacia_fence_gate 7
fill 451 48 -331 451 48 -332 acacia_fence_gate 1 replace acacia_fence_gate 5

#monorail stations
fill 471 60 -338 470 60 -339 sealantern 0 replace air 0
fill 471 60 -327 470 60 -328 sealantern 0 replace air 0

#Medical Building
fill 465 53 -326 465 52 -325 redstone_lamp 0 replace concrete 15

#exhibit lights
fill 421 52 -327 421 52 -325 end_rod 5
fill 420 52 -327 420 52 -325 end_rod 4

scoreboard players set @e[tag=power_zone_math] zone1loaded 10
tickingarea remove gentlegs
tickingarea add 222 55 -359 190 55 -325 z1_acu