#=========================== poweronmain - turn on gyro_monorail lights =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Treehouse Monorail On

#lights
fill 329 57 -617 331 57 -618 sealantern 0 replace concrete 15
fill 325 70 -618 324 70 -619 sealantern 0 replace air 0
fill 335 70 -618 336 70 -619 sealantern 0 replace air 0

scoreboard players set @e[tag=power_zone_math] zone2loaded 10
tickingarea remove treestation