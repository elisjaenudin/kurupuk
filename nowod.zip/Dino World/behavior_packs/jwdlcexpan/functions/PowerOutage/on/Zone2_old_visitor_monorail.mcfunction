#=========================== poweronmain - turn on old_visitor lights =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Old Vistor Monorail On

#lights
fill 195 70 -491 194 70 -490 sealantern 0 replace air 0
fill 195 70 -501 194 70 -502 sealantern 0 replace air 0



scoreboard players set @e[tag=power_zone_math] zone2loaded 2
tickingarea remove gryobracigates
tickingarea add 157 53 -608 140 54 -642 gyromono

