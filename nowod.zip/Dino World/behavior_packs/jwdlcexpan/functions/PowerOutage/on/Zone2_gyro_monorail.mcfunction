#=========================== poweronmain - turn on gyro_monorail lights =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Gyro Monorail On

#lights
fill 148 57 -619 147 57 -618 sealantern 0 replace air 0
fill 148 57 -629 147 57 -630 sealantern 0 replace air 0



scoreboard players set @e[tag=power_zone_math] zone2loaded 4
tickingarea remove gyromono
tickingarea add 373 79 -715 328 83 -665 indominus
