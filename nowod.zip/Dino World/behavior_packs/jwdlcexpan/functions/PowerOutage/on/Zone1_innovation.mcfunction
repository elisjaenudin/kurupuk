#==========================Innovation center=====================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Innovation Center On

setblock 394 55 -366 glowstone
fill 395 51 -359 400 51 -359 glowstone
setblock 399 51 -355 redstone_block
setblock 407 51 -354 redstone_block

setblock 385 54 -356 redstone_block
setblock 385 54 -358 redstone_block
setblock 385 54 -360 redstone_block
setblock 385 54 -362 redstone_block
setblock 385 54 -364 redstone_block

setblock 394 54 -356 redstone_block
setblock 394 54 -358 redstone_block
setblock 394 54 -360 redstone_block
setblock 394 54 -362 redstone_block
setblock 394 54 -364 redstone_block


setblock 373 53 -366 redstone_block
setblock 373 53 -374 redstone_block

setblock 373 53 -385 redstone_block

setblock 373 53 -393 redstone_block

setblock 406 53 -393 redstone_block
setblock 406 53 -385 redstone_block
setblock 406 53 -374 redstone_block

setblock 406 53 -366 redstone_block

setblock 386 50 -376 redstone_block
setblock 393 50 -376 redstone_block
setblock 386 50 -383 redstone_block
setblock 393 50 -383 redstone_block
fill 389 50 -379 390 50 -380 redstone_block

setblock 380 53 -370 light_block 15
setblock 376 53 -377 light_block 15
setblock 376 53 -382 light_block 15
setblock 380 53 -389 light_block 15
setblock 387 53 -393 light_block 15
setblock 392 53 -393 light_block 15
setblock 399 53 -389 light_block 15
setblock 403 53 -389 light_block 15
setblock 403 53 -377 light_block 15
setblock 401 53 -372 light_block 15
setblock 397 53 -368 light_block 15

# second floor
setblock 403 54 -364 redstone_block
setblock 399 54 -361 redstone_block

setblock 403 54 -395 redstone_block
setblock 399 54 -398 redstone_block

setblock 380 54 -398 redstone_block
setblock 376 54 -395 redstone_block

setblock 380 54 -361 redstone_block
setblock 376 54 -364 redstone_block

#third floor
setblock 386 74 -375 redstone_block
setblock 393 74 -375 redstone_block
setblock 393 74 -384 redstone_block
setblock 386 74 -384 redstone_block

#lab + hallway to lab
setblock 385 55 -400 redstone_block
setblock 394 55 -400 redstone_block

fill 395 57 -406 399 57 -410 redstone_block

fill 396 57 -413 400 57 -417 redstone_block


fill 395 57 -420 399 57 -426 redstone_block

#setblock 398 55 -406 end_rod 0
setblock 398 55 -406 nether_brick_fence

setblock 398 55 -409 nether_brick_fence

setblock 399 55 -414 nether_brick_fence
setblock 399 55 -416 nether_brick_fence

setblock 396 55 -414 nether_brick_fence
setblock 396 55 -416 nether_brick_fence

setblock 398 55 -421 nether_brick_fence
setblock 398 55 -424 nether_brick_fence

#redstone
setblock 394 57 -412 redstone_block
setblock 394 57 -418 redstone_block
setblock 377 57 -420 redstone_block

fill 390 56 -424 389 56 -424 redstone_block
fill 390 56 -421 389 56 -421 redstone_block
fill 390 57 -418 389 57 -418 redstone_block
fill 390 57 -412 389 57 -412 redstone_block
fill 390 56 -406 389 56 -406 redstone_block

fill 383 56 -424 383 56 -426 redstone_block
fill 377 57 -424 377 57 -426 redstone_block
fill 374 56 -424 374 56 -426 redstone_block
fill 371 56 -424 371 56 -426 redstone_block
fill 368 56 -424 368 56 -426 redstone_block

fill 364 51 -431 393 51 -431 redstone_block
fill 364 54 -431 393 55 -431 redstone_block

fill 364 52 -431 364 53 -431 redstone_block
fill 368 52 -431 368 53 -431 redstone_block
fill 374 52 -431 374 53 -431 redstone_block
fill 380 52 -431 380 53 -431 redstone_block
fill 386 52 -431 386 53 -431 redstone_block
fill 393 52 -431 393 53 -431 redstone_block

fill 384 57 -410 380 57 -406 redstone_block

setblock 385 57 -412 redstone_block

fill 402 53 -415 402 51 -413 redstone_block

fill 403 56 -410 402 56 -410 redstone_block

fill 403 56 -407 402 56 -407 redstone_block


fill 379 57 -419 384 57 -414 redstone_block

fill 375 57 -415 370 57 -419 redstone_block

fill 363 57 -415 368 57 -419 redstone_block


setblock 396 55 -431 redstone_block


fill 358 55 -410 358 55 -411 redstone_block
fill 358 55 -421 358 55 -420 redstone_block
fill 359 57 -415 357 57 -416 redstone_block

#Egg room lights
 
fill 344 55 -402 376 58 -410 redstone_block 0 replace concrete 9
fill 341 48 -400 364 48 -411 sealantern 0 replace concrete 10
fill 340 48 -400 340 53 -410 sealantern 0 replace concrete 10
setblock 345 51 -399 sealantern
setblock 366 48 -406 sealantern
setblock 366 48 -404 sealantern
setblock 366 48 -402 sealantern

setblock 367 49 -406 redstone_block
setblock 379 49 -405 redstone_block

#elevators
#fill 352 54 -415 351 54 -415 end_rod 3
#fill 352 54 -416 351 54 -416 end_rod 2


#fill 351 59 -415 351 59 -416 end_rod 4
#fill 352 59 -415 352 59 -416 end_rod 5

#fill 351 72 -415 351 72 -416 end_rod 4
#fill 352 72 -415 352 72 -416 end_rod 5

#fill 352 78 -415 351 78 -415 end_rod 3
#fill 352 78 -416 351 78 -416 end_rod 2

#control room
#fill 336 62 -419 347 62 -420 redstone_block
#fill 348 62 -420 354 62 -420 redstone_block

#fill 336 63 -422 333 63 -422 redstone_block

#fill 330 60 -424 330 60 -436 redstone_block
#fill 330 55 -424 330 55 -436 redstone_block

#fill 342 53 -426 345 53 -426 redstone_block

#fill 355 54 -429 355 54 -437 redstone_block

#fill 358 62 -437 358 62 -426 redstone_block

#setblock 357 62 -425 redstone_block
#setblock 356 62 -424 redstone_block
#fill 355 62 -423 355 62 -422 redstone_block

#setblock 348 58 -419 redstone_block

#fill 336 53 -426 338 53 -426 redstone_block

#fill 336 52 -431 337 52 -431 redstone_block
#fill 340 52 -431 341 52 -431 redstone_block
#fill 344 52 -431 345 52 -431 redstone_block

#fill 336 51 -436 337 51 -436 redstone_block
#fill 340 51 -436 341 51 -436 redstone_block
#fill 344 51 -436 345 51 -436 redstone_block


#fill 334 62 -442 352 54 -442 sealantern

#setblock 361 60 -434 lantern 1

#setblock 361 60 -429 lantern 1

scoreboard players set @e[tag=power_zone_math] zone1loaded 4
tickingarea remove innopow
tickingarea add 273 48 -280 362 49 -380 trexgates