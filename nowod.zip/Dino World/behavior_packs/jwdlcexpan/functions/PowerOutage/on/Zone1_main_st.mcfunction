#=========================== poweroffmain - turn off main street power =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Main St On

setblock 377 59 -297 daylight_detector_inverted
#redstone block
setblock 377 52 -297 redstone_block
setblock 371 52 -299 redstone_block
setblock 372 52 -303 redstone_block
setblock 376 53 -303 redstone_block

setblock 404 59 -302 daylight_detector_inverted
#glowstone
fill 408 48 -306 408 48 -308 glowstone
fill 409 49 -306 409 51 -308 glowstone

#end_rod 1 (bottom) end_rod 0 (top)
setblock 385 50 -302 end_rod 1
setblock 385 51 -302 end_rod 0

setblock 385 50 -313 end_rod 1
setblock 385 51 -313 end_rod 0

setblock 385 50 -331 end_rod 1
setblock 385 51 -331 end_rod 0

setblock 394 50 -302 end_rod 1
setblock 394 51 -302 end_rod 0

setblock 394 50 -313 end_rod 1
setblock 394 51 -313 end_rod 0

setblock 394 50 -331 end_rod 1
setblock 394 51 -331 end_rod 0

#redstone_block
setblock 369 52 -309 redstone_block
setblock 374 52 -309 redstone_block

setblock 376 52 -328 redstone_block
setblock 373 52 -328 redstone_block
setblock 370 52 -328 redstone_block

#campfire 1
setblock 378 48 -325 campfire 1

fill 403 57 -329 402 57 -330 redstone_block

setblock 408 57 -325 daylight_detector_inverted

setblock 406 57 -310 campfire 1

setblock 373 57 -327 campfire 1

#next to theatre
setblock 363 52 -296 redstone_block
setblock 363 52 -299 redstone_block
setblock 363 52 -302 redstone_block
setblock 365 52 -296 redstone_block
setblock 365 52 -299 redstone_block
setblock 365 52 -302 redstone_block

setblock 363 46 -298 air
setblock 363 46 -301 air
setblock 365 46 -298 air
setblock 365 46 -301 air

#yellow and white
setblock 420 50 -299 redstone_block
setblock 425 50 -299 redstone_block

setblock 420 56 -295 daylight_detector_inverted
setblock 420 56 -297 daylight_detector_inverted
setblock 425 56 -295 daylight_detector_inverted
setblock 425 56 -297 daylight_detector_inverted

setblock 429 57 -294 daylight_detector_inverted
setblock 431 57 -292 daylight_detector_inverted
setblock 431 51 -300 redstone_block

scoreboard players set @e[tag=power_zone_math] zone1loaded 2
tickingarea remove mainstpow
tickingarea add 413 46 -450 330 86 -349 innopow

#Switch Sparks
#kill @e[tag=POZ1_Sparks1]