#=========================== poweronmain - turn on  =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Power Station On

#Lights
fill 305 97 -772 305 97 -772 end_rod 5 replace air 0
fill 304 97 -772 304 97 -772 end_rod 4 replace air 0
fill 303 97 -772 303 97 -772 end_rod 4 replace air 0
fill 311 99 -779 311 99 -779 end_rod 4 replace air 0
fill 312 99 -779 312 99 -779 end_rod 5 replace air 0
fill 312 99 -784 312 99 -784 end_rod 4 replace air 0
fill 313 99 -784 313 99 -784 end_rod 5 replace air 0
fill 313 99 -790 313 99 -790 end_rod 5 replace air 0
fill 312 99 -790 312 99 -790 end_rod 4 replace air 0
fill 301 97 -782 301 97 -782 end_rod 3 replace air 0
fill 301 97 -783 301 97 -783 end_rod 2 replace air 0
fill 306 102 -792 307 102 -792 end_rod 2 replace air 0
fill 306 102 -791 307 102 -791 end_rod 3 replace air 0
fill 306 102 -790 307 102 -790 end_rod 2 replace air 0
fill 306 102 -789 307 102 -789 end_rod 3 replace air 0
fill 306 102 -788 307 102 -788 end_rod 2 replace air 0
fill 306 102 -787 307 102 -787 end_rod 3 replace air 0
fill 306 102 -786 307 102 -786 end_rod 2 replace air 0
fill 306 102 -785 307 102 -785 end_rod 3 replace air 0
fill 306 102 -784 307 102 -784 end_rod 2 replace air 0
fill 306 102 -783 307 102 -783 end_rod 3 replace air 0
fill 306 102 -782 307 102 -782 end_rod 2 replace air 0
fill 306 102 -781 307 102 -781 end_rod 3 replace air 0
fill 306 102 -780 307 102 -780 end_rod 2 replace air 0
fill 306 102 -779 307 102 -779 end_rod 3 replace air 0
fill 306 102 -778 307 102 -778 end_rod 2 replace air 0
fill 306 102 -777 307 102 -777 end_rod 3 replace air 0
fill 306 102 -776 307 102 -776 end_rod 2 replace air 0
fill 306 102 -775 307 102 -775 end_rod 3 replace air 0
fill 306 102 -774 307 102 -774 end_rod 2 replace air 0
fill 306 102 -773 307 102 -773 end_rod 3 replace air 0

fill 313 97 -772 312 97 -772 end_rod 5
setblock 311 97 -772 end_rod 4

fill 301 102 -782 301 102 -783 end_rod 3
setblock 301 102 -784 end_rod  2

#make sure levers are set
setblock 311 95 -774 lever 12
setblock 302 100 -784 lever 9

tp @e[tag=po2_dino_escaped] 403 1 -479
kill @e[tag=po2_dino_escaped,x=403,y=1,z=-479,r=10]


scoreboard players set @e[tag=power_zone_math] zone2loaded 8
tickingarea remove powstation
tickingarea add 313 65 -604 348 70 -625 treestation