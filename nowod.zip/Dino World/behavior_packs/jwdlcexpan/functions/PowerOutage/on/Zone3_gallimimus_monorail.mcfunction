#=========================== poweroffmain - turn on gallimimus monorail lights =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Gallimimus Monorail On

#Medical Building
fill 515 47 -613 516 47 -614 redstone_lamp 0 replace concrete 15

#Lights
fill 507 60 -613 506 60 -614 sealantern 0 replace air 0
fill 517 60 -613 518 60 -614 sealantern 0 replace air 0
fill 502 50 -609 502 50 -609 lantern 1 replace air 0
fill 502 50 -617 502 50 -617 lantern 1 replace air 0
fill 495 50 -617 495 50 -617 lantern 1 replace air 0
fill 494 50 -611 494 50 -611 lantern 1 replace air 0
fill 508 45 -618 508 45 -618 lantern 1 replace air 0
fill 490 45 -621 490 45 -621 lantern 0 replace air 0


