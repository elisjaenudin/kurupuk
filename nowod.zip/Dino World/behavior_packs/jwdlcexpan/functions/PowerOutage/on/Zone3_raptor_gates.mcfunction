#=========================== poweroffmain - turn on raptor gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Raptor Gates on

#Gate
function Gates/RaptorClose

#Lights
fill 849 57 -469 849 57 -473 redstone_block 0 replace air 0
fill 854 57 -469 854 57 -473 redstone_block 0 replace air 0
fill 838 66 -489 838 66 -489 daylight_detector_inverted 0 replace air 0
fill 838 66 -493 838 66 -493 daylight_detector_inverted 0 replace air 0
fill 838 66 -503 838 66 -503 daylight_detector_inverted 0 replace air 0
fill 838 66 -507 838 66 -507 daylight_detector_inverted 0 replace air 0
fill 829 66 -515 829 66 -515 daylight_detector_inverted 0 replace air 0
fill 825 66 -515 825 66 -515 daylight_detector_inverted 0 replace air 0
fill 817 66 -515 817 66 -515 daylight_detector_inverted 0 replace air 0
fill 813 66 -515 813 66 -515 daylight_detector_inverted 0 replace air 0
fill 804 66 -506 804 66 -506 daylight_detector_inverted 0 replace air 0
fill 804 66 -502 804 66 -502 daylight_detector_inverted 0 replace air 0
fill 804 66 -494 804 66 -494 daylight_detector_inverted 0 replace air 0
fill 804 66 -490 804 66 -490 daylight_detector_inverted 0 replace air 0
fill 812 66 -481 812 66 -481 daylight_detector_inverted 0 replace air 0
fill 816 66 -481 816 66 -481 daylight_detector_inverted 0 replace air 0
fill 826 66 -481 826 66 -481 daylight_detector_inverted 0 replace air 0
fill 830 66 -481 830 66 -481 daylight_detector_inverted 0 replace air 0

#turn lever back on
setblock 857 55 -470 lever 10

scoreboard players set @e[tag=power_zone_math] zone3loaded 8
tickingarea remove raptorpad