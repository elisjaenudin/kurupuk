#=========================== poweronmain - turn on zone 1 Maintanence =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Maintenance On

#Lights
fill 253 48 -355 253 48 -355 end_rod 2 replace air 0
fill 253 48 -354 253 48 -354 end_rod 3 replace air 0
fill 253 48 -349 253 48 -349 end_rod 2 replace air 0
fill 253 48 -348 253 48 -348 end_rod 3 replace air 0




scoreboard players set @e[tag=power_zone_math] zone1loaded 8
tickingarea remove maintenance
tickingarea add 416 55 -353 482 57 -303 gentlegs


