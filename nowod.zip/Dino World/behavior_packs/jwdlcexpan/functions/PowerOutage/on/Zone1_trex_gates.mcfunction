#=========================== poweroffmain - turn on T-Rex gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Trex On

#Gate
function Gates/TrexClose

#Lights
fill 336 49 -325 336 49 -327 redstone_block 0 replace air 0
fill 318 47 -307 318 47 -307 redstone_block 0 replace air 0
fill 318 49 -307 317 49 -307 redstone_block 0 replace air 0
fill 307 49 -307 309 49 -307 redstone_block 0 replace air 0
fill 293 55 -308 293 55 -308 redstone_block 0 replace air 0
fill 297 55 -304 297 55 -304 redstone_block 0 replace air 0
fill 289 55 -312 289 55 -312 redstone_block 0 replace air 0
fill 285 55 -316 285 55 -316 redstone_block 0 replace air 0
fill 281 55 -320 281 55 -320 redstone_block 0 replace air 0
fill 281 49 -339 281 49 -341 redstone_block 0 replace air 0
fill 278 55 -347 278 55 -347 redstone_block 0 replace air 0
fill 282 55 -351 282 55 -351 redstone_block 0 replace air 0
fill 286 55 -355 286 55 -355 redstone_block 0 replace air 0
fill 290 55 -359 290 55 -359 redstone_block 0 replace air 0
fill 294 55 -363 294 55 -363 redstone_block 0 replace air 0
fill 313 49 -363 315 49 -363 redstone_block 0 replace air 0
fill 324 55 -365 324 55 -365 redstone_block 0 replace air 0
fill 328 55 -361 328 55 -361 redstone_block 0 replace air 0
fill 332 55 -357 332 55 -357 redstone_block 0 replace air 0
fill 336 55 -353 336 55 -353 redstone_block 0 replace air 0
fill 335 48 -345 335 52 -345 redstone_block 0 replace air 0
fill 335 48 -337 335 52 -337 redstone_block 0 replace air 0
fill 330 51 -312 330 51 -312 end_rod 4 replace air 0
fill 329 51 -311 329 51 -311 end_rod 2 replace air 0 
fill 289 48 -352 289 48 -352 campfire 0 replace air 0
fill 290 51 -354 290 51 -354 end_rod 2 replace air 0
fill 290 51 -353 290 51 -353 end_rod 3 replace air 0
fill 288 51 -351 288 51 -351 end_rod 5 replace air 0
fill 287 51 -351 287 51 -351 end_rod 4 replace air 0
fill 328 51 -355 328 51 -355 end_rod 3 replace air 0
fill 329 51 -354 329 51 -354 end_rod 4 replace air 0
fill 325 52 -341 325 52 -341 lantern 1 replace air 0
fill 328 52 -341 328 52 -341 lantern 1 replace air 0
fill 331 52 -341 331 52 -341 lantern 1 replace air 0
fill 316 50 -308 316 50 -308 redstone_block 0 replace air 0
fill 305 49 -363 307 49 -363 redstone_block 0 replace air 0
fill 297 55 -366 297 55 -366 redstone_block 0 replace air 0
fill 289 48 -352 289 48 -352 campfire 0 replace air 0
fill 281 49 -330 281 49 -332 redstone_block 0 replace air 0
fill 328 55 -304 328 55 -304 redstone_block 0 replace air 0
fill 332 55 -308 332 55 -308 redstone_block 0 replace air 0
fill 336 55 -312 336 55 -312 redstone_block 0 replace air 0

#Medical Building
fill 302 52 -296 301 52 -295 redstone_lamp 0 replace concrete 15

#Theater
fill 323 51 -292 323 51 -292 redstone_block 0 replace air 0
fill 319 51 -290 319 51 -290 redstone_block 0 replace air 0
fill 327 55 -293 327 55 -293 redstone_block 0 replace air 0
fill 331 55 -293 331 55 -293 redstone_block 0 replace air 0
fill 337 53 -290 337 53 -290 redstone_block 0 replace air 0

fill 319 58 -294 319 58 -294 daylight_detector 0 replace air 0
fill 319 58 -290 319 58 -290 daylight_detector 0 replace air 0
fill 321 54 -286 321 54 -286 daylight_detector 0 replace air 0
fill 325 55 -292 325 55 -292 daylight_detector 0 replace air 0
fill 325 55 -290 325 55 -290 daylight_detector 0 replace air 0
fill 325 53 -287 325 53 -287 daylight_detector 0 replace air 0
fill 327 53 -286 327 53 -286 daylight_detector 0 replace air 0
fill 331 53 -286 331 53 -286 daylight_detector 0 replace air 0
fill 333 53 -287 333 53 -287 daylight_detector 0 replace air 0
fill 333 55 -290 333 55 -290 daylight_detector 0 replace air 0
fill 333 55 -292 333 55 -292 daylight_detector 0 replace air 0
fill 337 54 -286 337 54 -286 daylight_detector 0 replace air 0
fill 339 58 -294 339 58 -294 daylight_detector 0 replace air 0
fill 339 58 -290 339 58 -290 daylight_detector 0 replace air 0

setblock 345 53 -302 redstone_block
setblock 348 53 -302 redstone_block
setblock 353 53 -302 redstone_block
setblock 357 53 -302 redstone_block
setblock 345 53 -298 redstone_block
setblock 357 53 -298 redstone_block

setblock 349 52 -296 redstone_block
setblock 352 52 -296 redstone_block

#monorail
setblock 340 59 -367 end_rod 4
setblock 341 59 -367 end_rod 5
setblock 342 59 -367 end_rod 4
setblock 343 59 -367 end_rod 5
setblock 344 59 -367 end_rod 4
setblock 345 59 -367 end_rod 5
setblock 346 59 -367 end_rod 4
setblock 347 59 -367 end_rod 5
setblock 348 59 -367 end_rod 4
setblock 349 59 -367 end_rod 5
setblock 350 59 -367 end_rod 4

setblock 340 59 -364 end_rod 4
setblock 341 59 -364 end_rod 5
setblock 342 59 -364 end_rod 4
setblock 343 59 -364 end_rod 5
setblock 344 59 -364 end_rod 4
setblock 345 59 -364 end_rod 5
setblock 346 59 -364 end_rod 4
setblock 347 59 -364 end_rod 5
setblock 348 59 -364 end_rod 4
setblock 349 59 -364 end_rod 5
setblock 350 59 -364 end_rod 4

fill 341 54 -366 340 54 -365 sealantern

#lever
setblock 353 49 -310 lever 11

scoreboard players set @e[tag=power_zone_math] zone1loaded 6
tickingarea remove trexgates
tickingarea add 247 43 -344 259 46 -359 maintenance