
execute @e[tag=power_zone_math, scores={zone3loaded=0}] ~ ~ ~ detect 710 51 -386 stone 3 /scoreboard players set @e[tag=power_zone_math] zone3loaded 1

execute @e[tag=power_zone_math,scores={zone3loaded=1}] ~ ~ ~ /function PowerOutage/on/Zone3_aviary_monorail

#------------------------------------------------------------------------------------

execute @e[tag=power_zone_math, scores={zone3loaded=2}] ~ ~ ~ detect 470 46 -448 stone 3 /scoreboard players set @e[tag=power_zone_math] zone3loaded 3
execute @e[tag=power_zone_math,scores={zone3loaded=3}] ~ ~ ~ /function PowerOutage/on/Zone3_gallimimus_gates


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math, scores={zone3loaded=4}] ~ ~ ~ detect 548 54 -600 stone 3 /scoreboard players set @e[tag=power_zone_math] zone3loaded 5
execute @e[tag=power_zone_math,scores={zone3loaded=5}] ~ ~ ~ /function PowerOutage/on/Zone3_gallimimus_monorail
execute @e[tag=power_zone_math,scores={zone3loaded=5}] ~ ~ ~ /function PowerOutage/on/Zone3_Maintanence

#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math, scores={zone3loaded=6}] ~ ~ ~ detect 838 58 -489 stone 3  /scoreboard players set @e[tag=power_zone_math] zone3loaded 7
execute @e[tag=power_zone_math,scores={zone3loaded=7}] ~ ~ ~ /function PowerOutage/on/Zone3_raptor_gates


# aviary monorail 716 48 -377 694 54 -414 aviarymono
#galli gates  463 46 -455 476 52 -440 galligates 

#galli monorail 491 56 -591 574 67 -622 gallimain
#maintenance  

#raptor gates 794 66 -528 870 66 -456 raptorpad
