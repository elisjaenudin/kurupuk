
execute @e[tag=power_zone_math, scores={zone2loaded=0}] ~ ~ ~ detect 191 50 -533 stone 3 /scoreboard players set @e[tag=power_zone_math] zone2loaded 1

execute @e[tag=power_zone_math,scores={zone2loaded=1}] ~ ~ ~ /function PowerOutage/on/Zone2_gyro_braci_gates
execute @e[tag=power_zone_math,scores={zone2loaded=1}] ~ ~ ~ /function PowerOutage/on/Zone2_Maintanence
execute @e[tag=power_zone_math,scores={zone2loaded=1}] ~ ~ ~ /function PowerOutage/on/Zone2_old_visitor_monorail

#------------------------------------------------------------------------------------

execute @e[tag=power_zone_math, scores={zone2loaded=2}] ~ ~ ~ detect 150 53 -618 stone 3 /scoreboard players set @e[tag=power_zone_math] zone2loaded 3
execute @e[tag=power_zone_math,scores={zone2loaded=3}] ~ ~ ~ /function PowerOutage/on/Zone2_gyro_monorail


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math, scores={zone2loaded=4}] ~ ~ ~ detect 363 80 -710 stone 3 /scoreboard players set @e[tag=power_zone_math] zone2loaded 5
execute @e[tag=power_zone_math,scores={zone2loaded=5}] ~ ~ ~ /function PowerOutage/on/Zone2_indominus


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math, scores={zone2loaded=6}] ~ ~ ~ detect 294 94 -779 stone 3 /scoreboard players set @e[tag=power_zone_math] zone2loaded 7
execute @e[tag=power_zone_math,scores={zone2loaded=7}] ~ ~ ~ /function PowerOutage/on/Zone2_power_station


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math, scores={zone2loaded=8}] ~ ~ ~ detect 324 66 -616 stone 3 /scoreboard players set @e[tag=power_zone_math] zone2loaded 9
execute @e[tag=power_zone_math,scores={zone2loaded=9}] ~ ~ ~ /function PowerOutage/on/Zone2_treehouse_monorail



#braci gates 180 48 -539 269 71 -478
# #maintenance
# old visitor mono


#gyro mono 157 53 -608 140 54 -642
#indominus 373 79 -715 328 83 -665

#power station 288 99 -764 323 120 -797

#treehouse mono 313 65 -604 348 70 -625