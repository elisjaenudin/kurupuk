#create the ticking zone
tickingarea add 417 48 -291 365 60 -339 mainstpow

#turn off block for finding power outage disaster
setblock 346 1 -479 air

#activate the redstone block
setblock 346 1 -476 redstone_block

#reset zone1loaded
scoreboard players set @e[tag=power_zone_math] zone1loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=power_zone_math] zonePicked 1

#add entity from the map
summon jw:disaster 348.2 57.8 -441
execute @e[type=jw:disaster,x=348.2,y=57.1,z=-441,r=1] 348.2 57.1 -441 tag @s add dis_power_z1

#add indicator
clone 365 1 -425 372 15 -432 351 140 -312 replace force

#play disaster sound
playsound stinger.disaster.01 @a