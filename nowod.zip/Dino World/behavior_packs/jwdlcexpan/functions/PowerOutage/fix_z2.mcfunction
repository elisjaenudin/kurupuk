#===Fix it===
#if we aren't active, turn off the redstone block for this command block
execute @e[tag=power_zone_math,scores={z2_power_active=0}] ~ ~ ~ /setblock 344 1 -463 air
#turn off reset block
execute @e[tag=power_zone_math,scores={z2_power_active=0}] ~ ~ ~ /setblock 344 1 -453 air
#turn off solution check
execute @e[tag=power_zone_math,scores={z2_power_active=0}] ~ ~ ~ /setblock 346 1 -464 air

#create the ticking zone for zone2
execute @e[tag=power_zone_math,scores={zone2loaded=0,z2_power_active=1}] ~ ~ ~ /tickingarea add 180 48 -539 269 71 -478 gryobracigates

#turn on power
execute @e[tag=power_zone_math,scores={zone2loaded=!10,z2_power_active=1}] ~ ~ ~ /function PowerOutage/z2_load_on

#remove indicator
clone 367 1 -434 374 15 -441 296 140 -786 replace force

#fix message
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.pow2fix.subtitle"}]}
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a
	
#turn off solution check
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1}] ~ ~ ~ /setblock 346 1 -464 air

#turn off this block
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1}] ~ ~ ~ /setblock 344 1 -463 air

#turn off reset block
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /setblock 344 1 -453 air

#remove this from total disaster count
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#reset ticking areas
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1}] ~ ~ ~ /setblock 346 1 -454 redstone_block

#reset zone2loaded
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zone2loaded 0

#mark zone 2 power inactive
execute @e[tag=power_zone_math,scores={zone2loaded=0,z2_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] z2_power_active 0

#remove entity from the map
kill @e[tag=dis_power_z2]