
execute @e[tag=power_zone_math,scores={zone1loaded=0}] ~ ~ ~ detect 391 47 -315 concrete 8 /scoreboard players set @e[tag=power_zone_math] zone1loaded 1

execute @e[tag=power_zone_math,scores={zone1loaded=1}] ~ ~ ~ /function PowerOutage/on/Zone1_main_st

#------------------------------------------------------------------------------------

execute @e[tag=power_zone_math,scores={zone1loaded=2}] ~ ~ ~ detect 386 50 -394 stone 5 /scoreboard players set @e[tag=power_zone_math] zone1loaded 3
execute @e[tag=power_zone_math,scores={zone1loaded=3}] ~ ~ ~ /function PowerOutage/on/Zone1_innovation


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math,scores={zone1loaded=4}] ~ ~ ~ detect 313 49 -339 stone 5 /scoreboard players set @e[tag=power_zone_math] zone1loaded 5
execute @e[tag=power_zone_math,scores={zone1loaded=5}] ~ ~ ~ /function PowerOutage/on/Zone1_trex_gates


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math,scores={zone1loaded=6}] ~ ~ ~ detect 249 43 -353 concrete 8 /scoreboard players set @e[tag=power_zone_math] zone1loaded 7
execute @e[tag=power_zone_math,scores={zone1loaded=7}] ~ ~ ~ /function PowerOutage/on/Zone1_Maintanence


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math,scores={zone1loaded=8}] ~ ~ ~ detect 460 47 -319 grass 0 /scoreboard players set @e[tag=power_zone_math] zone1loaded 9
execute @e[tag=power_zone_math,scores={zone1loaded=9}] ~ ~ ~ /function PowerOutage/on/Zone1_gentle_giants_gates


#------------------------------------------------------------------------------------
execute @e[tag=power_zone_math, scores={zone1loaded=10}] ~ ~ ~ detect 211 46 -349 grass 0 /scoreboard players set @e[tag=power_zone_math] zone1loaded 11
execute @e[tag=power_zone_math,scores={zone1loaded=11}] ~ ~ ~ /function PowerOutage/on/Zone1_ACU


# z1 acu 207 51 -345
# z1 gentle giants 458 49 -310 
# z1 maintenence 253 48 -355
# trex 273 48 -299 347 49 -373