#create the ticking zone
tickingarea add 180 48 -539 269 71 -478 gryobracigates

#turn off block for finding power outage disaster
setblock 346 1 -479 air

#activate the redstone block
setblock 346 1 -472 redstone_block

#reset zone2loaded
scoreboard players set @e[tag=power_zone_math] zone2loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=power_zone_math] zonePicked 1

#add entity from the map
summon jw:disaster 347.9 61 -441
execute @e[type=jw:disaster,x=347.9,y=61,z=-441,r=1] 347.9 61 -441 tag @s add dis_power_z2

#add indicator
clone 365 1 -425 372 15 -432 296 140 -786 replace force

#play disaster sound
playsound stinger.disaster.01 @a