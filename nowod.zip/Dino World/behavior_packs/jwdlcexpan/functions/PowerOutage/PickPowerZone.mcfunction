#debug
#say Power Outage

#=======================================================
#check if all zones are active, and if they are, call a different disaster
execute @e[tag=power_zone_math,scores={z1_power_active=1,z2_power_active=1,z3_power_active=1,zonePicked=0}] ~ ~ ~ /function PowerOutage/CheckActive
#=======================================================

#loop if zones arent full, until we choose a zone thats not populated
scoreboard players random @e[tag=power_zone_math] zone_random 1 3

#===zone1===
#if zone 1 chosen and not already active, power the command block with /function z1_power_outage
#execute @e[tag=power_zone_math,scores={zone_random=1..1,z1_power_active=0,zonePicked=0}] ~ ~ ~ /function PowerOutage/z1_power_outage

#start loading the area, then start the power outage function command block
execute @e[tag=power_zone_math,scores={zone_random=1..1,z1_power_active=0,zonePicked=0}] ~ ~ ~ /function PowerOutage/cause_z1_power



#===zone2===
#if zone 2 chosen and not already active, power the command block with /function z2_power_outage
#execute @e[tag=power_zone_math,scores={zone_random=2..2,z2_power_active=0,zonePicked=0}] ~ ~ ~ /function PowerOutage/z2_power_outage

#start loading the area, then start the power outage function command block
execute @e[tag=power_zone_math,scores={zone_random=2..2,z2_power_active=0,zonePicked=0}] ~ ~ ~ /function PowerOutage/cause_z2_power

#===zone3===
#if zone 3 chosen and not already active, power the command block with /function z3_power_outage
#execute @e[tag=power_zone_math,scores={zone_random=3..3,z3_power_active=0,zonePicked=0}] ~ ~ ~ /function PowerOutage/z3_power_outage

execute @e[tag=power_zone_math,scores={zone_random=3..3,z3_power_active=0,zonePicked=0}] ~ ~ ~ /function PowerOutage/cause_z3_power




