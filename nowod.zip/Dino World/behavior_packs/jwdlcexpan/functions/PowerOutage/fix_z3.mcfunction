#===Fix it===
#if we aren't active, turn off the redstone block for this command block
execute @e[tag=power_zone_math,scores={z3_power_active=0}] ~ ~ ~ /setblock 344 1 -459 air
#turn off reset block
execute @e[tag=power_zone_math,scores={z3_power_active=0}] ~ ~ ~ /setblock 344 1 -450 air
#turn off solution check
execute @e[tag=power_zone_math,scores={z3_power_active=0}] ~ ~ ~ /setblock 346 1 -460 air

#create the ticking zone for zone3
execute @e[tag=power_zone_math,scores={zone3loaded=0,z3_power_active=1}] ~ ~ ~ /tickingarea add 716 48 -377 694 54 -414 aviarymono

#turn on power
execute @e[tag=power_zone_math,scores={zone3loaded=!8,z3_power_active=1}] ~ ~ ~ /function PowerOutage/z3_load_on

#remove indicator
clone 367 1 -434 374 15 -441 849 140 -473 replace force

#Fixed message
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.pow3fix.subtitle"}]}
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#turn off solution check
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1}] ~ ~ ~ /setblock 346 1 -460 air

#turn off this block
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1}] ~ ~ ~ /setblock 344 1 -459 air

#turn off reset block
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /setblock 344 1 -450 air

#remove this from total disaster count
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#reset ticking areas
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1}] ~ ~ ~ /setblock 346 1 -451 redstone_block

#reset zone3loaded
execute @e[tag=power_zone_math,scores={zone3loaded=8,z3_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zone3loaded 0

#mark zone 3 power inactive
execute @e[tag=power_zone_math,scores={zone3loaded=0,z3_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] z3_power_active 0

#remove entity from the map
kill @e[tag=dis_power_z3]