tickingarea remove treestation
tickingarea remove powstation
tickingarea remove gryobracigates
tickingarea remove gyromono
tickingarea remove indominus

#turn off this block
setblock 346 1 -454 air