tickingarea remove innopow
tickingarea remove mainstpow
tickingarea remove trexgates
tickingarea remove z1_acu
tickingarea remove gentlegs
tickingarea remove maintenance

#turn off this block
setblock 346 1 -457 air