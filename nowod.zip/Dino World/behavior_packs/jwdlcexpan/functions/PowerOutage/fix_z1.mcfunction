#===Fix it===
#if we aren't active, turn off the redstone block for this command block
execute @e[tag=power_zone_math,scores={z1_power_active=0}] ~ ~ ~ /setblock 344 1 -467 air
#turn off reset block
execute @e[tag=power_zone_math,scores={z1_power_active=0}] ~ ~ ~ /setblock 344 1 -456 air
#turn off solution check
execute @e[tag=power_zone_math,scores={z1_power_active=0}] ~ ~ ~ /setblock 346 1 -468 air

#create the ticking zone for zone1
execute @e[tag=power_zone_math,scores={zone1loaded=0,z1_power_active=1}] ~ ~ ~ /tickingarea add 417 48 -291 365 60 -339 mainstpow

#turn on power
execute @e[tag=power_zone_math,scores={zone1loaded=!12,z1_power_active=1}] ~ ~ ~ /function PowerOutage/z1_load_on

#remove indicator
clone 367 1 -434 374 15 -441 351 140 -312 replace force

#fix message
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a subtitle {"rawtext":[{"translate":"jw.pow1fix.subtitle"}]}
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1,no_fix_msg=0}] ~ ~ ~ /titleraw @a title {"rawtext":[{"translate":"jw.disasterfixed.title"}]}

#play stinger
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1,no_fix_msg=0}] ~ ~ ~ /playsound stinger.epic.01 @a

#turn off solution check
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /setblock 346 1 -468 air

#turn off this block
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /setblock 344 1 -467 air

#turn off reset block
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /setblock 344 1 -456 air

#remove this from total disaster count
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /scoreboard players remove @e[tag=disaster_system] disaster_count 1

#disasters left message
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1,no_fix_msg=0}] ~ ~ ~ /function DisastersLeftMessage

#set off delayed remove ticking areas just in case
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /setblock 346 1 -457 redstone_block

#reset zone1loaded
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zone1loaded 0

#mark zone 1 power inactive
execute @e[tag=power_zone_math,scores={zone1loaded=0,z1_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] z1_power_active 0

#remove entity from the map
kill @e[tag=dis_power_z1]

