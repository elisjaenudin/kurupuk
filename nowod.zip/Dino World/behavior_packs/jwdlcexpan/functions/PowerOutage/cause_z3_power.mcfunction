#create the ticking zone
tickingarea add 716 48 -377 694 54 -414 aviarymono

#turn off block for finding power outage disaster
setblock 346 1 -479 air

#activate the redstone block
setblock 344 1 -473 redstone_block

#reset zone3loaded
scoreboard players set @e[tag=power_zone_math] zone3loaded 0

#prevent redstone retriggering zone selection
scoreboard players set @e[tag=power_zone_math] zonePicked 1

#add entity from the map
summon jw:disaster 351.8 58.6 -441
execute @e[type=jw:disaster,x=351.8,y=58.6,z=-441,r=1] 351.8 58.6 -441 tag @s add dis_power_z3

#add indicator
clone 365 1 -425 372 15 -432 849 140 -473 replace force

#play disaster sound
playsound stinger.disaster.01 @a