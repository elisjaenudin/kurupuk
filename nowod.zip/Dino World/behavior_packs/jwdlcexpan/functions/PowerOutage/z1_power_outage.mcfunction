#debug
#execute @e[tag=disaster_system,scores={randomDisaster=1..,debug=1}] ~ ~ ~ /say Zone 1 Power Outage

#prevent redstone retriggering zone selection
execute @e[tag=power_zone_math,scores={z1_power_active=0}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zonePicked 1

# a zone was chosen so stop looking for a zone
execute @e[tag=power_zone_math,scores={zone1loaded=0,z1_power_active=0}] ~ ~ ~ /setblock 346 1 -479 air

#add disaster points
execute @e[tag=power_zone_math,scores={zone1loaded=0,z1_power_active=0}] ~ ~ ~ /scoreboard players operation @e[tag=disaster_system] tierPoints += power_outage_points tierPoints

#turn off power
execute @e[tag=power_zone_math,scores={zone1loaded=!12,z1_power_active=0}] ~ ~ ~ /function PowerOutage/z1_load_off


#message Sector 1 disaster
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.pow1event.chat"}]}

#make check for solution active
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=0}] ~ ~ ~ /setblock 346 1 -468 redstone_block

#----------------turn off this block

execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=0}] ~ ~ ~ /setblock 346 1 -476 air

#add this to total disaster count
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=0}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] z1_power_active 1

execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /tickingarea remove innopow
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /tickingarea remove mainstpow
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /tickingarea remove trexgates
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /tickingarea remove z1_acu
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /tickingarea remove gentlegs
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /tickingarea remove maintenance

execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /setblock 346 1 -457 redstone_block

#reset zone1loaded
execute @e[tag=power_zone_math,scores={zone1loaded=12,z1_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zone1loaded 0

