#reset function
#say power outage reset

#suppress the messaging for fixing disasters
scoreboard players set @e[tag=power_zone_math] no_fix_msg 1

#trigger series of delayed command blocks to undo the disasters in a staged order
setblock 344 1 -456 redstone_block
setblock 344 1 -453 redstone_block
setblock 344 1 -450 redstone_block
setblock 344 1 -447 redstone_block

#get rid of dinosaur