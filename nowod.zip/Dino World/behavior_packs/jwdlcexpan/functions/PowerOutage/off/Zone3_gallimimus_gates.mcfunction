#=========================== poweroffmain - turn off gallimimus side gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Gallimimus Gates Off

#gates
fill 469 42 -451 472 39 -447 air 0 replace stained_hardened_clay 13

scoreboard players set @e[tag=power_zone_math] zone3loaded 4
tickingarea remove galligates
tickingarea add 491 56 -591 574 67 -622 gallimain