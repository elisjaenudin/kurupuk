#==========================Innovation center=====================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Innovation Center Off

setblock 394 55 -366 air
fill 395 51 -359 400 51 -359 air
setblock 399 51 -355 air
setblock 407 51 -354 air

setblock 385 54 -356 air
setblock 385 54 -358 air
setblock 385 54 -360 air
setblock 385 54 -362 air
setblock 385 54 -364 air

setblock 394 54 -356 air
setblock 394 54 -358 air
setblock 394 54 -360 air
setblock 394 54 -362 air
setblock 394 54 -364 air

setblock 373 53 -366 air
setblock 373 53 -374 air

setblock 373 53 -385 air

setblock 373 53 -393 air

setblock 406 53 -393 air
setblock 406 53 -385 air
setblock 406 53 -374 air

setblock 406 53 -366 air

setblock 386 50 -376 air
setblock 393 50 -376 air
setblock 386 50 -383 air
setblock 393 50 -383 air
fill 389 50 -379 390 50 -380 air

setblock 380 53 -370 air
setblock 376 53 -377 air
setblock 376 53 -382 air
setblock 380 53 -389 air
setblock 387 53 -393 air
setblock 392 53 -393 air
setblock 399 53 -389 air
setblock 403 53 -389 air
setblock 403 53 -377 air
setblock 401 53 -372 air
setblock 397 53 -368 air

# second floor
setblock 403 54 -364 air
setblock 399 54 -361 air

setblock 403 54 -395 air
setblock 399 54 -398 air

setblock 380 54 -398 air
setblock 376 54 -395 air

setblock 380 54 -361 air
setblock 376 54 -364 air

#third floor
setblock 386 74 -375 air
setblock 393 74 -375 air
setblock 393 74 -384 air
setblock 386 74 -384 air

#lab + hallway to lab
setblock 385 55 -400 air
setblock 394 55 -400 air

fill 395 57 -406 399 57 -410 air

fill 396 57 -413 400 57 -417 air


fill 395 57 -420 399 57 -426 air

#setblock 398 55 -406 end_rod 0
setblock 398 55 -406 nether_brick_fence

setblock 398 55 -409 nether_brick_fence

setblock 399 55 -414 nether_brick_fence
setblock 399 55 -416 nether_brick_fence

setblock 396 55 -414 nether_brick_fence
setblock 396 55 -416 nether_brick_fence

setblock 398 55 -421 nether_brick_fence
setblock 398 55 -424 nether_brick_fence

#redstone
setblock 394 57 -412 air
setblock 394 57 -418 air
setblock 377 57 -420 air

fill 390 56 -424 389 56 -424 air
fill 390 56 -421 389 56 -421 air
fill 390 57 -418 389 57 -418 air
fill 390 57 -412 389 57 -412 air
fill 390 56 -406 389 56 -406 air

fill 383 56 -424 383 56 -426 air
fill 377 57 -424 377 57 -426 air
fill 374 56 -424 374 56 -426 air
fill 371 56 -424 371 56 -426 air
fill 368 56 -424 368 56 -426 air

fill 364 51 -431 393 51 -431 air
fill 364 54 -431 393 55 -431 air

fill 364 52 -431 364 53 -431 air
fill 368 52 -431 368 53 -431 air
fill 374 52 -431 374 53 -431 air
fill 380 52 -431 380 53 -431 air
fill 386 52 -431 386 53 -431 air
fill 393 52 -431 393 53 -431 air

fill 384 57 -410 380 57 -406 air

setblock 385 57 -412 air

fill 402 53 -415 402 51 -413 air

fill 403 56 -410 402 56 -410 air

fill 403 56 -407 402 56 -407 air

fill 379 57 -419 384 57 -414 air

fill 375 57 -415 370 57 -419 air

fill 363 57 -415 368 57 -419 air


setblock 396 55 -431 air


fill 358 55 -410 358 55 -411 air
fill 358 55 -421 358 55 -420 air
fill 359 57 -415 357 57 -416 air

#Egg Room Lights
fill 344 55 -402 376 58 -410 concrete 9 replace redstone_block
fill 341 48 -400 364 48 -411 concrete 10 replace sealantern
fill 340 48 -400 340 53 -410 concrete 10 replace sealantern
setblock 345 51 -399 concrete 10
setblock 366 48 -406 concrete 10
setblock 366 48 -404 concrete 10
setblock 366 48 -402 concrete 10

setblock 367 49 -406 air
setblock 379 49 -405 air

#elevators
#fill 352 54 -416 351 54 -415 air

#fill 352 59 -416 351 59 -415 air

#fill 352 72 -416 351 72 -415 air

#fill 352 78 -416 351 78 -415 air


#control room
#fill 336 62 -419 347 62 -420 air
#fill 348 62 -420 354 62 -420 air

#fill 336 63 -422 333 63 -422 air

#fill 330 60 -424 330 60 -436 air
#fill 330 55 -424 330 55 -436 air

#fill 342 53 -426 345 53 -426 concrete 15

#fill 355 54 -429 355 54 -437 concrete 15

#fill 358 62 -437 358 62 -426 air

#setblock 357 62 -425 air
#setblock 356 62 -424 air
#fill 355 62 -423 355 62 -422 air

#setblock 348 58 -419 air

#fill 336 53 -426 338 53 -426 concrete 15

#fill 336 52 -431 337 52 -431 air
#fill 340 52 -431 341 52 -431 air
#fill 344 52 -431 345 52 -431 air

#fill 336 51 -436 337 51 -436 air
#fill 340 51 -436 341 51 -436 air
#fill 344 51 -436 345 51 -436 air

#fill 334 62 -442 352 54 -442 concrete 15

#setblock 361 60 -434 air

#setblock 361 60 -429 air

#fill 345 51 -432 344 51 -432 concrete 15
#fill 341 51 -432 340 51 -432 concrete 15
#fill 337 51 -432 336 51 -432 concrete 15

scoreboard players set @e[tag=power_zone_math] zone1loaded 4
tickingarea remove innopow
tickingarea add 273 48 -280 362 49 -380 trexgates



