#=========================== poweroffmain - turn off power station =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Power Station off

#Lights
fill 305 97 -772 305 97 -772 air 0 replace end_rod 5
fill 304 97 -772 304 97 -772 air 0 replace end_rod 4
fill 303 97 -772 303 97 -772 air 0 replace end_rod 4
fill 311 99 -779 311 99 -779 air 0 replace end_rod 4
fill 312 99 -779 312 99 -779 air 0 replace end_rod 5
fill 312 99 -784 312 99 -784 air 0 replace end_rod 4
fill 313 99 -784 313 99 -784 air 0 replace end_rod 5
fill 313 99 -784 313 99 -784 air 0 replace end_rod 5
fill 312 99 -790 312 99 -790 air 0 replace end_rod 4
fill 313 99 -790 313 99 -790 air 0 replace end_rod 5
fill 301 97 -782 301 97 -782 air 0 replace end_rod 3
fill 301 97 -783 301 97 -783 air 0 replace end_rod 2
fill 306 102 -792 307 102 -792 air 0 replace end_rod 2
fill 306 102 -791 307 102 -791 air 0 replace end_rod 3
fill 306 102 -790 307 102 -790 air 0 replace end_rod 2
fill 306 102 -789 307 102 -789 air 0 replace end_rod 3
fill 306 102 -788 307 102 -788 air 0 replace end_rod 2
fill 306 102 -787 307 102 -787 air 0 replace end_rod 3
fill 306 102 -786 307 102 -786 air 0 replace end_rod 2
fill 306 102 -785 307 102 -785 air 0 replace end_rod 3
fill 306 102 -784 307 102 -784 air 0 replace end_rod 2
fill 306 102 -783 307 102 -783 air 0 replace end_rod 3
fill 306 102 -782 307 102 -782 air 0 replace end_rod 2
fill 306 102 -781 307 102 -781 air 0 replace end_rod 3
fill 306 102 -780 307 102 -780 air 0 replace end_rod 2
fill 306 102 -779 307 102 -779 air 0 replace end_rod 3
fill 306 102 -778 307 102 -778 air 0 replace end_rod 2
fill 306 102 -777 307 102 -777 air 0 replace end_rod 3
fill 306 102 -776 307 102 -776 air 0 replace end_rod 2
fill 306 102 -775 307 102 -775 air 0 replace end_rod 3
fill 306 102 -774 307 102 -774 air 0 replace end_rod 2
fill 306 102 -773 307 102 -773 air 0 replace end_rod 3

#fill 301 102 -782 301 102 -784 air

#fill 313 97 -772 311 97 -772 air 0 replace end_rod

#make sure levers are set
setblock 311 95 -774 lever 4
setblock 302 100 -784 lever 1

#dino spawn
summon jurassic_world:velociraptor 332 94 -786 jw:adult
execute @e[type=jurassic_world:velociraptor,x=332,y=94,z=-786,r=2] 332 94 -786 tag @e[type=jurassic_world:velociraptor] add po2_dino_escaped



scoreboard players set @e[tag=power_zone_math] zone2loaded 8
tickingarea remove powstation
tickingarea add 313 65 -604 348 70 -625 treestation

#Switch Sparks 1
summon jw:sparks 312 94.9 -773.1
summon jw:sparks 312 96.9 -773.1
summon jw:sparks 313 95.9 -773.1
execute @e[type=jw:sparks,x=312,y=95,z=-773,r=3] 312 95 -773 tag @s add POZ2_Sparks1

#Switch Sparks 2
summon jw:sparks 302.1 99.9 -783
summon jw:sparks 302.1 101.9 -783
summon jw:sparks 302.1 100.9 -782
execute @e[type=jw:sparks,x=302,y=100,z=-783,r=3] 302 99 -783 tag @s add POZ2_Sparks2