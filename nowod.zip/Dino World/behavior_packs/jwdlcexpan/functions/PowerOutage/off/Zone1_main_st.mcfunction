#=========================== poweroffmain - turn off main street power =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Main Off

setblock 377 59 -297 air 0
#redstone block
setblock 377 52 -297 air
setblock 371 52 -299 air
setblock 372 52 -303 air
setblock 376 53 -303 air

setblock 404 59 -302 air 0
#glowstone
fill 408 48 -306 408 48 -308 air
fill 409 49 -306 409 51 -308 air

#end_rod 1 (bottom) end_rod 0 (top)
setblock 385 50 -302 nether_brick_fence
setblock 385 51 -302 nether_brick_fence

setblock 385 50 -313 nether_brick_fence
setblock 385 51 -313 nether_brick_fence

setblock 385 50 -331 nether_brick_fence
setblock 385 51 -331 nether_brick_fence

setblock 394 50 -302 nether_brick_fence
setblock 394 51 -302 nether_brick_fence

setblock 394 50 -313 nether_brick_fence
setblock 394 51 -313 nether_brick_fence

setblock 394 50 -331 nether_brick_fence
setblock 394 51 -331 nether_brick_fence

#redstone_block
setblock 369 52 -309 air
setblock 374 52 -309 air

setblock 376 52 -328 air
setblock 373 52 -328 air
setblock 370 52 -328 air

#campfire 1
setblock 378 48 -325 campfire 5

#fill 395 48 -325 395 48 -326 glowstone


#fill 403 57 -329 402 57 -330 redstone_block
fill 403 57 -329 402 57 -330 air

#setblock 408 57 -325 daylight_detector_inverted
setblock 408 57 -325 air 0

#setblock 406 57 -310 campfire 1
setblock 406 57 -310 campfire 5

#setblock 373 57 -327 campfire 1
setblock 373 57 -327 campfire 5

#next to theatre
setblock 363 52 -296 air
setblock 363 52 -299 air
setblock 363 52 -302 air
setblock 365 52 -296 air
setblock 365 52 -299 air
setblock 365 52 -302 air

setblock 363 46 -298 air
setblock 363 46 -301 air
setblock 365 46 -298 air
setblock 365 46 -301 air


#yellow and white
setblock 420 50 -299 concrete 15
setblock 425 50 -299 concrete 15

setblock 420 56 -295 air 0
setblock 420 56 -297 air 0
setblock 425 56 -295 air 0
setblock 425 56 -297 air 0

setblock 429 57 -294 air 0
setblock 431 57 -292 air 0
setblock 431 51 -300 air

scoreboard players set @e[tag=power_zone_math] zone1loaded 2
tickingarea remove mainstpow
tickingarea add 413 46 -450 330 86 -349 innopow

#Switch Sparks
summon jw:sparks 352 50.8 -309.9
summon jw:sparks 353 50.8 -309.9
execute @e[type=jw:sparks,x=352,y=50.8,z=-309.8,r=2] 352 50.8 -309.9 tag @s add POZ1_Sparks
