#=========================== poweroffmain - turn off gallimimus monorail lights =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Gallimimus Monorail Off

#Medical Building
fill 515 47 -613 516 47 -614 concrete 15 replace redstone_lamp 0

#Lights
fill 507 60 -613 506 60 -614 air 0 replace sealantern 0
fill 517 60 -613 518 60 -614 air 0 replace sealantern 0
fill 502 50 -609 502 50 -609 air 0 replace lantern 1
fill 502 50 -617 502 50 -617 air 0 replace lantern 1
fill 495 50 -617 495 50 -617 air 0 replace lantern 1
fill 494 50 -611 494 50 -611 air 0 replace lantern 1
fill 508 45 -618 508 45 -618 air 0 replace lantern 1
fill 490 45 -621 490 45 -621 air 0 replace lantern 0