#=========================== poweroffmain - turn off indominus paddock =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Indominus off

#gates

fill 362 74 -697 362 82 -701 air 0 replace nether_brick
fill 362 74 -697 362 82 -701 air 0 replace stonebrick
fill 362 74 -706 362 82 -706 nether_brick 0 replace air 0
fill 362 74 -704 362 82 -704 nether_brick 0 replace air 0
fill 362 74 -702 362 82 -702 nether_brick 0 replace air 0
fill 362 74 -705 362 74 -705 nether_brick 0 replace air 0
fill 362 75 -705 362 75 -705 stonebrick 0 replace air 0
fill 362 76 -705 362 76 -705 nether_brick 0 replace air 0
fill 362 77 -705 362 79 -705 stonebrick 0 replace air 0
fill 362 80 -705 362 80 -705 nether_brick 0 replace air 0
fill 362 81 -705 362 81 -705 stonebrick 0 replace air 0
fill 362 82 -705 362 82 -705 nether_brick 0 replace air 0
fill 362 74 -703 362 74 -703 nether_brick 0 replace air 0
fill 362 75 -703 362 75 -703 stonebrick 0 replace air 0
fill 362 76 -703 362 76 -703 nether_brick 0 replace air 0
fill 362 77 -703 362 79 -703 stonebrick 0 replace air 0
fill 362 80 -703 362 80 -703 nether_brick 0 replace air 0
fill 362 81 -703 362 81 -703 stonebrick 0 replace air 0
fill 362 82 -703 362 82 -703 nether_brick 0 replace air 0

#Control room lights
fill 349 84 -678 349 84 -678 air 0 replace redstone_block 0
fill 340 84 -678 340 84 -678 air 0 replace redstone_block 0
fill 351 77 -678 351 77 -678 air 0 replace redstone_block 0


scoreboard players set @e[tag=power_zone_math] zone2loaded 6
tickingarea remove indominus
tickingarea add 288 99 -764 323 120 -797 powstation