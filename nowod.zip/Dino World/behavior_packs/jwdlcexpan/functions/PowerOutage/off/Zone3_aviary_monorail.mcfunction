#=========================== poweroffmain - turn off Aviary Monorail =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Aviary Monorail Off

#Lights
fill 707 55 -387 708 55 -388 air 0 replace sealantern 0
fill 707 55 -398 708 55 -399 air 0 replace sealantern 0

scoreboard players set @e[tag=power_zone_math] zone3loaded 2
tickingarea remove aviarymono
tickingarea add 463 46 -455 476 52 -440 galligates