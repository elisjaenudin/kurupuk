#=========================== poweroffmain - turn off gyro & braci gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Gyro Braci Gates off

#gates
fill 242 53 -510 245 56 -506 air 0 replace stained_hardened_clay 13
fill 192 43 -533 188 46 -530 air 0 replace stained_hardened_clay 13