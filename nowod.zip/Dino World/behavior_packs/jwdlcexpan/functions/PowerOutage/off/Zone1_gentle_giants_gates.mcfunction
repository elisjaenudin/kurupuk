#=========================== poweroffmain - turn off gentle giants gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Gentle Giants Off
#gates
fill 459 48 -310 459 48 -310 acacia_fence_gate 7 replace acacia_fence_gate 3
fill 451 48 -331 451 48 -332 acacia_fence_gate 5 replace acacia_fence_gate 1

#Monorail station
fill 471 60 -338 470 60 -339 air 0 replace sealantern 0
fill 471 60 -327 470 60 -328 air 0 replace sealantern 0 

#Medical Building
fill 465 53 -326 465 52 -325 concrete 15 replace redstone_lamp 0

#exhibit lights
fill 421 52 -327 421 52 -325 air
fill 420 52 -327 420 52 -325 air

scoreboard players set @e[tag=power_zone_math] zone1loaded 10
tickingarea remove gentlegs
tickingarea add 222 55 -359 190 55 -325 z1_acu