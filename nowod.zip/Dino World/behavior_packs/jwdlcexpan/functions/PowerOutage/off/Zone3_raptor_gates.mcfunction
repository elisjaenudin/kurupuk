#=========================== poweroffmain - turn off Raptor Gates =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Raptor Gates off

#gates
function Gates/RaptorOpen

#Lights
fill 849 57 -469 849 57 -473 air 0 replace redstone_block 0
fill 854 57 -469 854 57 -473 air 0 replace redstone_block 0
fill 838 66 -489 838 66 -489 air 0 replace daylight_detector_inverted
fill 838 66 -493 838 66 -493 air 0 replace daylight_detector_inverted
fill 838 66 -503 838 66 -503 air 0 replace daylight_detector_inverted
fill 838 66 -507 838 66 -507 air 0 replace daylight_detector_inverted
fill 829 66 -515 829 66 -515 air 0 replace daylight_detector_inverted
fill 825 66 -515 825 66 -515 air 0 replace daylight_detector_inverted
fill 817 66 -515 817 66 -515 air 0 replace daylight_detector_inverted
fill 813 66 -515 813 66 -515 air 0 replace daylight_detector_inverted
fill 804 66 -506 804 66 -506 air 0 replace daylight_detector_inverted
fill 804 66 -502 804 66 -502 air 0 replace daylight_detector_inverted
fill 804 66 -494 804 66 -494 air 0 replace daylight_detector_inverted
fill 804 66 -490 804 66 -490 air 0 replace daylight_detector_inverted
fill 812 66 -481 812 66 -481 air 0 replace daylight_detector_inverted
fill 816 66 -481 816 66 -481 air 0 replace daylight_detector_inverted
fill 826 66 -481 826 66 -481 air 0 replace daylight_detector_inverted
fill 830 66 -481 830 66 -481 air 0 replace daylight_detector_inverted

#turn lever back off
setblock 857 55 -470 lever 2

scoreboard players set @e[tag=power_zone_math] zone3loaded 8
tickingarea remove raptorpad

#Switch Sparks
summon jw:sparks 857.9 54.9 -470
execute @e[type=jw:sparks,x=857.9,y=54.9,z=-470,r=1] 857.9 54.9 -470 tag @s add POZ3_Sparks