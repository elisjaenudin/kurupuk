#=========================== poweronmain - turn on zone 3 Maintanence =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 3 Maintenance Off

#Lights
fill 545 52 -612 545 52 -612 air 0 replace end_rod  2
fill 545 52 -611 545 52 -611 air 0 replace end_rod 3 
fill 537 52 -611 537 52 -611 air 0 replace end_rod 3
fill 537 52 -612 537 52 -612 air 0 replace end_rod 2

#lights acu
fill 567 53 -614 567 53 -614 air 0 replace end_rod 5
fill 566 53 -614 566 53 -614 air 0 replace end_rod 4
fill 561 53 -614 561 53 -614 air 0 replace end_rod 5
fill 560 53 -614 560 53 -614 air 0 replace end_rod 4
fill 560 53 -602 560 53 -602 air 0 replace end_rod 4
fill 561 53 -602 561 53 -602 air 0 replace end_rod 5
fill 566 53 -602 566 53 -602 air 0 replace end_rod 4
fill 567 53 -602 567 53 -602 air 0 replace end_rod 5

#gate
fill 550 47 -598 554 50 -600 air 0 replace stained_hardened_clay 13

scoreboard players set @e[tag=power_zone_math] zone3loaded 6
tickingarea remove gallimain
tickingarea add 794 66 -528 870 66 -456 raptorpad

