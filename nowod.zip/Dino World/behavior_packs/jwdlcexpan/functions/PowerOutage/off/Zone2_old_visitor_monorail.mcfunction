#=========================== poweroffmain - turn off Old_visitor Monorail =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Old Visitor Monorail off
#Lights
fill 195 70 -491 194 70 -490 air 0 replace sealantern 0
fill 195 70 -501 194 70 -502 air 0 replace sealantern 0



scoreboard players set @e[tag=power_zone_math] zone2loaded 2
tickingarea remove gryobracigates
tickingarea add 157 53 -608 140 54 -642 gyromono



