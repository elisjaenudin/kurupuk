#=========================== poweroffmain - turn off Tree_house Monorail =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 treehouse monorail off

#Lights
fill 329 57 -617 331 57 -618 concrete 15 replace sealantern 0
fill 325 70 -618 324 70 -619 air 0 replace sealantern 0
fill 335 70 -618 336 70 -619 air 0 replace sealantern 0

scoreboard players set @e[tag=power_zone_math] zone2loaded 10
tickingarea remove treestation






