#=========================== poweroffmain - turn off Zone2_ACU_Aux =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 2 Maintenance Off

#Lights
fill 256 66 -500 256 66 -500 air 0 replace end_rod 4
fill 257 66 -500 257 66 -500 air 0 replace end_rod 5
fill 262 66 -500 262 66 -500 air 0 replace end_rod 4
fill 263 66 -500 263 66 -500 air 0 replace end_rod 5



