#=========================== poweroffmain - turn off Zone1_ACU_Aux =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 ACU Off

#Lights
fill 202 50 -346 202 50 -346 air 0 replace end_rod 2
fill 202 50 -345 202 50 -345 air 0 replace end_rod 3
fill 202 50 -340 202 50 -340 air 0 replace end_rod 2
fill 202 50 -339 202 50 -339 air 0 replace end_rod 3
fill 200 50 -351 200 50 -351 air 0 replace end_rod 3
fill 200 50 -352 200 50 -352 air 0 replace end_rod 2
fill 208 50 -352 208 50 -352 air 0 replace end_rod 2
fill 208 50 -351 208 50 -351 air 0 replace end_rod 3
fill 214 50 -345 214 50 -345 air 0 replace end_rod 3
fill 214 50 -346 214 50 -346 air 0 replace end_rod 2
fill 214 50 -340 214 50 -340 air 0 replace end_rod 2
fill 214 50 -339 214 50 -339 air 0 replace end_rod 3

scoreboard players set @e[tag=power_zone_math] zone1loaded 12
tickingarea remove z1_acu


