#=========================== poweroffmain - turn off Zone1_ACU_Aux =================
#execute @e[tag=disaster_system,scores={debug=1}] ~ ~ ~ /say Zone 1 Maintenance Off

#Lights
fill 253 48 -355 253 48 -355 air 0 replace end_rod 2
fill 253 48 -354 253 48 -354 air 0 replace end_rod 3
fill 253 48 -349 253 48 -349 air 0 replace end_rod 2
fill 253 48 -348 253 48 -348 air 0 replace end_rod 3




scoreboard players set @e[tag=power_zone_math] zone1loaded 8
tickingarea remove maintenance
tickingarea add 416 55 -353 482 57 -303 gentlegs
