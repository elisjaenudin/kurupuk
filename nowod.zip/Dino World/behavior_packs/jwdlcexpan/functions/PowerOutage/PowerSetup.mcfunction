#power setup
scoreboard objectives add z1_power_active dummy
scoreboard objectives add z2_power_active dummy
scoreboard objectives add z3_power_active dummy
scoreboard objectives add chance_break dummy
scoreboard objectives add lever1chk dummy
scoreboard objectives add lever2chk dummy

scoreboard players set @e[tag=power_zone_math] z1_power_active 0
scoreboard players set @e[tag=power_zone_math] z2_power_active 0
scoreboard players set @e[tag=power_zone_math] z3_power_active 0
scoreboard players set @e[tag=power_zone_math] zonePicked 0
scoreboard players set @e[tag=power_zone_math] zone_random 0
scoreboard players set @e[tag=power_zone_math] lever1chk 0
scoreboard players set @e[tag=power_zone_math] lever2chk 0

scoreboard players set power_outage_points tierPoints 3

scoreboard players set @e[tag=power_zone_math] no_fix_msg 0

