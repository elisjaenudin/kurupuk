#off = lever 2

#if lever is in fixed position, turn on the fix block
execute @e[tag=power_zone_math,scores={z3_power_active=1}] ~ ~ ~ detect 857 55 -470 lever 10 /setblock 344 1 -459 redstone_block
execute @e[tag=POZ3_Sparks] ~ ~ ~ detect 857 55 -470 lever 10 /tp @e[tag=POZ3_Sparks] 390 1 -466
execute @e[tag=POZ3_Sparks] ~ ~ ~ detect 857 55 -470 lever 10 /kill @e[tag=POZ3_Sparks]
