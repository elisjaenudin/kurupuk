#off = lever 3

#if lever is in fixed position, turn on the fix block
execute @e[tag=power_zone_math,scores={z1_power_active=1}] ~ ~ ~ detect 353 49 -310 lever 11 /setblock 344 1 -467 redstone_block
execute @e[tag=POZ1_Sparks] ~ ~ ~ detect 353 49 -310 lever 11 /tp @e[tag=POZ1_Sparks] 390 1 -466
execute @e[tag=POZ1_Sparks] ~ ~ ~ detect 353 49 -310 lever 11 /kill @e[tag=POZ1_Sparks]
