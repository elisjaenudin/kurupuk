#debug
#execute @e[tag=disaster_system,scores={randomDisaster=1..,debug=1}] ~ ~ ~ /say Zone 2 Power Outage

#prevent redstone retriggering zone selection
execute @e[tag=power_zone_math,scores={z2_power_active=0}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zonePicked 1

# a zone was chosen so stop looking for a zone
execute @e[tag=power_zone_math,scores={zone2loaded=0,z2_power_active=0}] ~ ~ ~ /setblock 346 1 -479 air

#add disaster points
execute @e[tag=power_zone_math,scores={zone2loaded=0,z2_power_active=0}] ~ ~ ~ /scoreboard players operation @e[tag=disaster_system] tierPoints += power_outage_points tierPoints

#turn off power
execute @e[tag=power_zone_math,scores={zone2loaded=!10,z2_power_active=0}] ~ ~ ~ /function PowerOutage/z2_load_off


#message Sector 2 disaster
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.pow2event.chat"}]}

#make check for solution active
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=0}] ~ ~ ~ /setblock 346 1 -464 redstone_block

#----------------turn off this block

execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=0}] ~ ~ ~ /setblock 346 1 -472 air

#add this to total disaster count
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=0}] ~ ~ ~ /scoreboard players add @e[tag=disaster_system] disaster_count 1

#mark this zone active
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=0}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] z2_power_active 1


#turn off ticking areas
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1}] ~ ~ ~ /setblock 346 1 -454 redstone_block

#reset zone2loaded
execute @e[tag=power_zone_math,scores={zone2loaded=10,z2_power_active=1}] ~ ~ ~ /scoreboard players set @e[tag=power_zone_math] zone2loaded 0



