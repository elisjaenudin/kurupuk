#off = lever 4
#off = lever 1 for upper switch

#check if just turned on
#lever1chk 0 but detected and lever2 is not on
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever1chk=0,lever2chk=0}] ~ ~ ~ detect 311 95 -774 lever 12 /tellraw @a {"rawtext":[{"translate":"jw.1lever.chat"}]}
execute @e[tag=POZ2_Sparks1] ~ ~ ~ detect 311 95 -774 lever 12 /tp @e[tag=POZ2_Sparks1] 390 1 -466
execute @e[tag=POZ2_Sparks1] ~ ~ ~ detect 311 95 -774 lever 12 /kill @e[tag=POZ2_Sparks1]

#lever2chk 0 but detected and lever1 is not on
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever1chk=0,lever2chk=0}] ~ ~ ~ detect 302 100 -784 lever 9 /tellraw @a {"rawtext":[{"translate":"jw.1lever.chat"}]}
execute @e[tag=POZ2_Sparks2] ~ ~ ~ detect 302 100 -784 lever 9 /tp @e[tag=POZ2_Sparks2] 390 1 -466
execute @e[tag=POZ2_Sparks2] ~ ~ ~ detect 302 100 -784 lever 9 /kill @e[tag=POZ2_Sparks2]

#off
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever1chk=1}] ~ ~ ~ detect 311 95 -774 lever 4 /scoreboard players set @e[tag=power_zone_math] lever1chk 0
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever2chk=1}] ~ ~ ~ detect 302 100 -784 lever 1 /scoreboard players set @e[tag=power_zone_math] lever2chk 0

#on
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever1chk=0}] ~ ~ ~ detect 311 95 -774 lever 12 /scoreboard players set @e[tag=power_zone_math] lever1chk 1
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever2chk=0}] ~ ~ ~ detect 302 100 -784 lever 9 /scoreboard players set @e[tag=power_zone_math] lever2chk 1

#remove tag so that it won't get killed if you solve the disaster manually and have teleported the dinosaur
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever1chk=1,lever2chk=1}] ~ ~ ~ /tag @e[tag=po2_dino_escaped] remove po2_dino_escaped


#if both levers are in fixed position, turn on the fix block
execute @e[tag=power_zone_math,scores={z2_power_active=1,lever1chk=1,lever2chk=1}] ~ ~ ~ /setblock 344 1 -463 redstone_block




