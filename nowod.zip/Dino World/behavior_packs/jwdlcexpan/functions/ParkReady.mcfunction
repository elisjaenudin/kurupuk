# Shows the player a celebration when the park can be opened 

titleraw @a subtitle {"rawtext":[{"translate":"jw.progress.park_ready"}]}
titleraw @a title {"rawtext":[{"translate":" "}]}
tellraw @a {"rawtext":[{"translate":"jw.progress.park_ready_long"}]}
summon jw:breadcrumb 342 55 -432
