#Security Storm and Saboteurs

#if security team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z3_security_time=1..}] ~ ~ ~ /tag @s add Security3_Busy

#zone 3 has saboteur
execute @e[tag=sabo_zone_math,scores={z3_sabo_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Security3_Busy] add SendSecurity
execute @e[tag=SendSecurity] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security3.saboteurs"}]}
execute @e[tag=SendSecurity] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z3_security_time 600
execute @e[tag=SendSecurity] ~ ~ ~ /execute @e[tag=sabo_zone_math,scores={z3_sabo_active=1}] ~ ~ ~ /setblock 364 1 -445 redstone_block
execute @e[tag=SendSecurity] ~ ~ ~ /summon jw:busy 552 57 -598
execute @e[type=jw:busy,x=552,y=57,z=-598,r=2] 552 57 -598 tag @s add Security3busy_particals

#zone 3 doesn't have saboteur active
execute @e[tag=sabo_zone_math,scores={z3_sabo_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Security3_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security3.noz3sabos"}]}

#otherwise if Security team is busy, output busy message
execute @e[tag=disaster_system,tag=Security3_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security3.busy"}]}

execute @e[tag=SendSecurity] ~ ~ ~ /tag @s remove SendSecurity