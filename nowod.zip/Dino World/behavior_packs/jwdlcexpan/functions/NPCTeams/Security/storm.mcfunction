#Security Storm and Saboteurs

#if security team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z2_security_time=1..}] ~ ~ ~ /tag @s add Security2_Busy

#zone 1 has fire active
execute @e[tag=storm_zone_math,scores={storm_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Security2_Busy] add SendSecurity
execute @e[tag=SendSecurity] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security2.storm"}]}
execute @e[tag=SendSecurity] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z2_security_time 600
execute @e[tag=SendSecurity] ~ ~ ~ /execute @e[tag=storm_zone_math,scores={storm_active=1}] ~ ~ ~ /setblock 348 1 -469 redstone_block
execute @e[tag=SendSecurity] ~ ~ ~ /summon jw:busy 190 53 -530
execute @e[type=jw:busy,x=190,y=53,z=-530,r=2] 190 53 -530 tag @s add Security2busy_particals

#zone 1 doesn't have fire active
execute @e[tag=storm_zone_math,scores={storm_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Security2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security2.nostorm"}]}

#otherwise if Security team is busy, output busy message
execute @e[tag=disaster_system,tag=Security2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security2.busy"}]}

execute @e[tag=SendSecurity] ~ ~ ~ /tag @s remove SendSecurity