#Security Storm and Saboteurs

#if security team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z1_security_time=1..}] ~ ~ ~ /tag @s add Security1_Busy

#zone 1 has saboteur
execute @e[tag=sabo_zone_math,scores={z1_sabo_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Security1_Busy] add SendSecurity
execute @e[tag=SendSecurity] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security1.saboteurs"}]}
execute @e[tag=SendSecurity] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z1_security_time 600
execute @e[tag=SendSecurity] ~ ~ ~ /execute @e[tag=sabo_zone_math,scores={z1_sabo_active=1}] ~ ~ ~ /setblock 364 1 -469 redstone_block
execute @e[tag=SendSecurity] ~ ~ ~ /summon jw:busy 470 49 -449
execute @e[type=jw:busy,x=478,y=49,z=-333,r=2] 478 49 -333 tag @s add Security1busy_particals
execute @e[tag=SendSecurity] ~ ~ ~ /summon jw:busy 470 49 -449
execute @e[type=jw:busy,x=351,y=50,z=-346,r=2] 351 50 -346 tag @s add Security1busy_particals

#zone 1 doesn't have saboteur active
execute @e[tag=sabo_zone_math,scores={z1_sabo_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Security1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security1.noz1sabos"}]}

#otherwise if Security team is busy, output busy message
execute @e[tag=disaster_system,tag=Security1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security1.busy"}]}

execute @e[tag=SendSecurity] ~ ~ ~ /tag @s remove SendSecurity
