#Security Storm and Saboteurs

#if security team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z2_security_time=1..}] ~ ~ ~ /tag @s add Security2_Busy

#zone 2 has saboteur
execute @e[tag=sabo_zone_math,scores={z2_sabo_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Security2_Busy] add SendSecurity
execute @e[tag=SendSecurity] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security2.saboteurs"}]}
execute @e[tag=SendSecurity] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z2_security_time 600
execute @e[tag=SendSecurity] ~ ~ ~ /execute @e[tag=sabo_zone_math,scores={z2_sabo_active=1}] ~ ~ ~ /setblock 364 1 -457 redstone_block
execute @e[tag=SendSecurity] ~ ~ ~ /summon jw:busy 190 53 -530
execute @e[type=jw:busy,x=190,y=53,z=-530,r=2] 190 53 -530 tag @s add Security2busy_particals
execute @e[tag=SendSecurity] ~ ~ ~ /summon jw:busy 254 45 -354
execute @e[type=jw:busy,x=254,y=45,z=-354,r=2] 254 45 -354 tag @s add Security2busy_particals

#zone 2 doesn't have saboteur active
execute @e[tag=sabo_zone_math,scores={z2_sabo_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Security2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security2.noz2sabos"}]}

#otherwise if Security team is busy, output busy message
execute @e[tag=disaster_system,tag=Security2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security2.busy"}]}

execute @e[tag=SendSecurity] ~ ~ ~ /tag @s remove SendSecurity
