#ACU team - Exhibit and Dino

#if acu is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z2_ACU_time=1..}] ~ ~ ~ /tag @s add ACU2_Busy


#zone 2 has dino active
execute @e[tag=dino_zone_math,scores={z2_dino_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!ACU2_Busy] add SendACU
execute @e[tag=SendACU] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU2.dinos"}]}
execute @e[tag=SendACU] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z2_ACU_time 600
execute @e[tag=SendACU] ~ ~ ~ /execute @e[tag=dino_zone_math,scores={z2_dino_active=1}] ~ ~ ~ /setblock 360 1 -457 redstone_block
execute @e[tag=SendACU] ~ ~ ~ /summon jw:busy 210 49 -342
execute @e[type=jw:busy,x=212,y=49,z=-342,r=2] 212 49 -342 tag @s add ACU2busy_particals
execute @e[tag=ACU2_Busy] ~ ~ ~ /summon jw:busy 337 56 -431
execute @e[type=jw:busy,x=337,y=56,z=-431,r=2] 337 56 -431 tag @s add ACU2busy_particals

#zone 2 doesn't have dino active
execute @e[tag=dino_zone_math,scores={z2_dino_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!ACU2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU2.noz2dinos"}]}

#otherwise if ACU team is busy, output busy message
execute @e[tag=disaster_system,tag=ACU2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU2.busy"}]}


execute @e[tag=SendACU] ~ ~ ~ /tag @s remove SendACU