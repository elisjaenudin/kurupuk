#ACU team - Exhibit and Dino

#if acu is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z1_ACU_time=1..}] ~ ~ ~ /tag @s add ACU1_Busy


#zone 1 has exhibit active
execute @e[tag=exhibit_zone_math,scores={z1_exhbt_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!ACU1_Busy] add SendACU
execute @e[tag=SendACU] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU1.exhibit"}]}
execute @e[tag=SendACU] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z1_ACU_time 600
execute @e[tag=SendACU] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={z1_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -469 redstone_block
execute @e[tag=SendACU] ~ ~ ~ /summon jw:busy 481 37 -80
execute @e[type=jw:busy,x=481,y=37,z=-80,r=2] 481 37 -80 tag @s add ACU1busy_particals

#zone 1 doesn't have exhibit active
execute @e[tag=exhibit_zone_math,scores={z1_exhbt_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!ACU1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU1.noz1exhibit"}]}

#otherwise if ACU team is busy, output busy message
execute @e[tag=disaster_system,tag=ACU1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU1.busy"}]}


execute @e[tag=SendACU] ~ ~ ~ /tag @s remove SendACU