#ACU team - Exhibit and Dino

#if acu is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z3_ACU_time=1..}] ~ ~ ~ /tag @s add ACU3_Busy


#zone 3 has exhibit active
execute @e[tag=exhibit_zone_math,scores={z3_exhbt_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!ACU3_Busy] add SendACU
execute @e[tag=SendACU] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU3.exhibit"}]}
execute @e[tag=SendACU] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z3_ACU_time 600
execute @e[tag=SendACU] ~ ~ ~ /execute @e[tag=exhibit_zone_math,scores={z3_exhbt_active=1}] ~ ~ ~ /setblock 356 1 -445 redstone_block
execute @e[tag=SendACU] ~ ~ ~ /summon jw:busy 563 52 -604
execute @e[type=jw:busy,x=563,y=52,z=-604,r=2] 563 52 -604 tag @s add ACU3busy_particals

#zone 3 doesn't have exhibit active
execute @e[tag=exhibit_zone_math,scores={z3_exhbt_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!ACU3_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU3.noz3exhibit"}]}

#otherwise if ACU team is busy, output busy message
execute @e[tag=disaster_system,tag=ACU3_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU3.busy"}]}

execute @e[tag=SendACU] ~ ~ ~ /tag @s remove SendACU