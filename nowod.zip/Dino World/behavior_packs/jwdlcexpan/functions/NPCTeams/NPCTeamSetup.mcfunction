scoreboard objectives add z1_ACU_time dummy
scoreboard objectives add z2_ACU_time dummy
scoreboard objectives add z3_ACU_time dummy
scoreboard objectives add z1_security_time dummy
scoreboard objectives add z2_security_time dummy
scoreboard objectives add z3_security_time dummy
scoreboard objectives add z1_repair_time dummy
scoreboard objectives add z2_repair_time dummy
scoreboard objectives add z3_repair_time dummy
scoreboard objectives add time_test dummy

scoreboard players set @e[tag=disaster_system] time_test 0
scoreboard players set @e[tag=disaster_system] z1_ACU_time 0
scoreboard players set @e[tag=disaster_system] z2_ACU_time 0
scoreboard players set @e[tag=disaster_system] z3_ACU_time 0
scoreboard players set @e[tag=disaster_system] z1_security_time 0
scoreboard players set @e[tag=disaster_system] z2_security_time 0
scoreboard players set @e[tag=disaster_system] z3_security_time 0
scoreboard players set @e[tag=disaster_system] z1_repair_time 0
scoreboard players set @e[tag=disaster_system] z2_repair_time 0
scoreboard players set @e[tag=disaster_system] z3_repair_time 0

