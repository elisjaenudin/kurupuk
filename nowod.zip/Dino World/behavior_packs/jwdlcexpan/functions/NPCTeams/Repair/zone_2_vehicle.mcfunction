#repair team - vehicle and power outage

#if Repair team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z2_repair_time=1..}] ~ ~ ~ /tag @s add Repair2_Busy

#zone 2 has vehicle active
execute @e[tag=vehi_zone_math,scores={z2_vehi_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Repair2_Busy] add SendRepair
execute @e[tag=SendRepair] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair2.vehicle"}]}
execute @e[tag=SendRepair] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z2_repair_time 600
execute @e[tag=SendRepair] ~ ~ ~ /execute @e[tag=vehi_zone_math,scores={z2_vehi_active=1}] ~ ~ ~ /setblock 350 1 -457 redstone_block
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 262 63 -500
execute @e[type=jw:busy,x=262,y=63,z=-500,r=2] 262 63 -500 tag @s add Repair2busy_particals
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 340 56 -431
execute @e[type=jw:busy,x=340,y=56,z=-431,r=2] 340 56 -431 tag @s add Repair2busy_particals

#zone 2 doesn't have vehicle active
execute @e[tag=vehi_zone_math,scores={z2_vehi_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Repair2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair2.noz2vehicle"}]}

#otherwise if Repair team is busy, output busy message
execute @e[tag=disaster_system,tag=Repair2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair2.busy"}]}


execute @e[tag=SendRepair] ~ ~ ~ /tag @s remove SendRepair