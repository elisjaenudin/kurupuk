#repair team - vehicle and power outage

#if Repair team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z2_repair_time=1..}] ~ ~ ~ /tag @s add Repair2_Busy

#zone 2 has Power active
execute @e[tag=power_zone_math,scores={z2_power_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Repair2_Busy] add SendRepair
execute @e[tag=SendRepair] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair2.power"}]}
execute @e[tag=SendRepair] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z2_repair_time 600
execute @e[tag=SendRepair] ~ ~ ~ /execute @e[tag=power_zone_math,scores={z2_power_active=1}] ~ ~ ~ /setblock 344 1 -463 redstone_block
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 262 63 -500
execute @e[type=jw:busy,x=262,y=63,z=-500,r=2] 262 63 -500 tag @s add Repair2busy_particals

#zone 2 doesn't have Power active
execute @e[tag=power_zone_math,scores={z2_power_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Repair2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair2.noz2power"}]}

#otherwise if Repair team is busy, output busy message
execute @e[tag=disaster_system,tag=Repair2_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair2.busy"}]}


execute @e[tag=SendRepair] ~ ~ ~ /tag @s remove SendRepair