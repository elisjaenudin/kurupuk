#repair team - vehicle and power outage

#if Repair team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z3_repair_time=1..}] ~ ~ ~ /tag @s add Repair3_Busy

#zone 3 has vehicle active
execute @e[tag=vehi_zone_math,scores={z3_vehi_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Repair3_Busy] add SendRepair
execute @e[tag=SendRepair] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair3.vehicle"}]}
execute @e[tag=SendRepair] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z3_repair_time 600
execute @e[tag=SendRepair] ~ ~ ~ /execute @e[tag=vehi_zone_math,scores={z3_vehi_active=1}] ~ ~ ~ /setblock 350 1 -445 redstone_block
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 547 52 -617
execute @e[type=jw:busy,x=547,y=52,z=-617,r=2] 547 52 -617 tag @s add Repair3busy_particals
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 340 56 -431
execute @e[type=jw:busy,x=340,y=56,z=-431,r=2] 340 56 -431 tag @s add Repair3busy_particals

#zone 3 doesn't have vehicle active
execute @e[tag=vehi_zone_math,scores={z3_vehi_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Repair3_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair3.noz3vehicle"}]}

#otherwise if Repair team is busy, output busy message
execute @e[tag=disaster_system,tag=Repair3_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair3.busy"}]}



execute @e[tag=SendRepair] ~ ~ ~ /tag @s remove SendRepair