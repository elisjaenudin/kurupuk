#repair team - vehicle and power outage

#if Repair team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z1_repair_time=1..}] ~ ~ ~ /tag @s add Repair1_Busy

#zone 1 has Power active
execute @e[tag=power_zone_math,scores={z1_power_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Repair1_Busy] add SendRepair
execute @e[tag=SendRepair] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair1.power"}]}
execute @e[tag=SendRepair] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z1_repair_time 600
execute @e[tag=SendRepair] ~ ~ ~ /execute @e[tag=power_zone_math,scores={z1_power_active=1}] ~ ~ ~ /setblock 344 1 -467 redstone_block
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 478 49 -333
execute @e[type=jw:busy,x=478,y=49,z=-333,r=2] 478 49 -333 tag @s add Repair1busy_particals
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 357 44 -409
execute @e[type=jw:busy,x=357,y=44,z=-409,r=2] 357 44 -409 tag @s add Repair1busy_particals
#zone 1 doesn't have Power active
execute @e[tag=power_zone_math,scores={z1_power_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Repair1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair1.noz1power"}]}

#otherwise if Repair team is busy, output busy message
execute @e[tag=disaster_system,tag=Repair1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair1.busy"}]}


execute @e[tag=SendRepair] ~ ~ ~ /tag @s remove SendRepair