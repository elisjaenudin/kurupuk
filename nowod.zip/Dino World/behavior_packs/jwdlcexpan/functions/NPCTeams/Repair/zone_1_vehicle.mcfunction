#repair team - vehicle and power outage

#if Repair team is already busy ignore the rest of this file.
execute @e[tag=disaster_system,scores={z1_repair_time=1..}] ~ ~ ~ /tag @s add Repair1_Busy

#zone 1 has vehicle active
execute @e[tag=vehi_zone_math,scores={z1_vehi_active=1}] ~ ~ ~ /tag @e[tag=disaster_system,tag=!Repair1_Busy] add SendRepair
execute @e[tag=SendRepair] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair1.vehicle"}]}
execute @e[tag=SendRepair] ~ ~ ~ /scoreboard players set @e[tag=disaster_system] z1_repair_time 600
execute @e[tag=SendRepair] ~ ~ ~ /execute @e[tag=vehi_zone_math,scores={z1_vehi_active=1}] ~ ~ ~ /setblock 350 1 -469 redstone_block
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 478 49 -333
execute @e[type=jw:busy,x=357,y=44,z=-409,r=2] 357 44 -409 tag @s add Repair1busy_particals
execute @e[tag=SendRepair] ~ ~ ~ /summon jw:busy 340 56 -431
execute @e[type=jw:busy,x=340,y=56,z=-431,r=2] 340 56 -431 tag @s add Repair1busy_particals

#zone 1 doesn't have vehicle active
execute @e[tag=vehi_zone_math,scores={z1_vehi_active=0}] ~ ~ ~ /execute @e[tag=disaster_system,tag=!Repair1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair1.noz1vehicle"}]}

#otherwise if Repair team is busy, output busy message
execute @e[tag=disaster_system,tag=Repair1_Busy] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair1.busy"}]}


execute @e[tag=SendRepair] ~ ~ ~ /tag @s remove SendRepair