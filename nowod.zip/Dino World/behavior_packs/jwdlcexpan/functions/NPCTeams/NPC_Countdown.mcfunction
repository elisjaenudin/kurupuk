#==============ACU 1=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z1_ACU_time
scoreboard players remove @e[tag=disaster_system,scores={z1_ACU_time=!0}] z1_ACU_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z1_ACU_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU1.return"}]}

#Reset busy status
execute @e[tag=ACU1_Busy] ~ ~ ~ /tag @s remove ACU1_Busy
execute @e[tag=ACU1busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=ACU1busy_particals] ~ ~ ~ /kill @s

#==============ACU 2=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z2_ACU_time
scoreboard players remove @e[tag=disaster_system,scores={z2_ACU_time=!0}] z2_ACU_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z2_ACU_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU2.return"}]}

#Reset busy status
execute @e[tag=ACU2_Busy] ~ ~ ~ /tag @s remove ACU2_Busy
execute @e[tag=ACU2busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=ACU2busy_particals] ~ ~ ~ /kill @s

#==============ACU 3=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z3_ACU_time
scoreboard players remove @e[tag=disaster_system,scores={z3_ACU_time=!0}] z3_ACU_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z3_ACU_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.ACU3.return"}]}

#Reset busy status
execute @e[tag=ACU3_Busy] ~ ~ ~ /tag @s remove ACU3_Busy
execute @e[tag=ACU3busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=ACU3busy_particals] ~ ~ ~ /kill @s


#==============Repair 1=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z1_repair_time
scoreboard players remove @e[tag=disaster_system,scores={z1_repair_time=!0}] z1_repair_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z1_repair_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair1.return"}]}

#Reset busy status
execute @e[tag=Repair1_Busy] ~ ~ ~ /tag @s remove Repair1_Busy
execute @e[tag=Repair1busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=Repair1busy_particals] ~ ~ ~ /kill @s

#==============Repair 2=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z2_repair_time
scoreboard players remove @e[tag=disaster_system,scores={z2_repair_time=!0}] z2_repair_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z2_repair_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair2.return"}]}

#Reset busy status
execute @e[tag=Repair2_Busy] ~ ~ ~ /tag @s remove Repair2_Busy
execute @e[tag=Repair2busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=Repair2busy_particals] ~ ~ ~ /kill @s

#==============Repair 3=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z3_repair_time
scoreboard players remove @e[tag=disaster_system,scores={z3_repair_time=!0}] z3_repair_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z3_repair_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.repair3.return"}]}

#Reset busy status
execute @e[tag=Repair3_Busy] ~ ~ ~ /tag @s remove Repair3_Busy
execute @e[tag=Repair3busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=Repair3busy_particals] ~ ~ ~ /kill @s



#==============Security=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z1_security_time
scoreboard players remove @e[tag=disaster_system,scores={z1_security_time=!0}] z1_security_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z1_security_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security1.return"}]}

#Reset busy status
execute @e[tag=Security1_Busy] ~ ~ ~ /tag @s remove Security1_Busy
execute @e[tag=Security1busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=Security1busy_particals] ~ ~ ~ /kill @s

#==============Security=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z2_security_time
scoreboard players remove @e[tag=disaster_system,scores={z2_security_time=!0}] z2_security_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z2_security_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security2.return"}]}

#Reset busy status
execute @e[tag=Security2_Busy] ~ ~ ~ /tag @s remove Security2_Busy
execute @e[tag=Security2busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=Security2busy_particals] ~ ~ ~ /kill @s

#==============Security=========================
scoreboard players operation @e[tag=disaster_system] time_test = @e[tag=disaster_system] z3_security_time
scoreboard players remove @e[tag=disaster_system,scores={z3_security_time=!0}] z3_security_time 1
execute @e[tag=disaster_system,scores={time_test=!0,z3_security_time=0}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"jw.security3.return"}]}

#Reset busy status
execute @e[tag=Security3_Busy] ~ ~ ~ /tag @s remove Security3_Busy
execute @e[tag=Security3busy_particals] ~ ~ ~ /tp @s 390 1 -466
execute @e[tag=Security3busy_particals] ~ ~ ~ /kill @s
