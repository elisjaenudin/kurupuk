# Show the player progress toward building all of the quickbuilds
#say DEBUG quickbuild progress

execute @a[scores={quickbuild=1}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"1 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=2}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"2 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=3}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"3 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=4}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"4 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=5}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"5 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=6}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"6 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=7}] ~ ~ ~ /titleraw @s actionbar {"rawtext":[{"translate":"7 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=1}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"1 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=2}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"2 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=3}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"3 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=4}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"4 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=5}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"5 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=6}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"6 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=7}] ~ ~ ~ /tellraw @a {"rawtext":[{"translate":"7 / 7"},{"translate":"jw.progress.quickbuld"}]}
execute @a[scores={quickbuild=7}] ~ ~ ~ /setblock 344 8 -428 redstone_block
execute @a[scores={quickbuild=7}] ~ ~ ~ /setblock 356 50 -421 hopper
execute @a[scores={quickbuild=7}] ~ ~ ~ /scoreboard players add @a quickbuild 1

execute @e[tag=disaster_system] ~ ~ ~ detect 342 55 -432 lever 5 /fill 344 8 -424 344 8 -424 redstone_block 0 replace air