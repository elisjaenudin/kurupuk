scoreboard players remove @s[scores={uorb_energy=1..}] uorb_energy 10

event entity @s[tag=uo_trinity,scores={uorb_energy=40..60}] minecraft:uo_trinity
event entity @s[tag=uo_trinity,scores={uorb_energy=40..60}] minecraft:default_var
event entity @s[scores={uorb_energy=..600}] minecraft:orb_on_lowenergy
event entity @s[scores={uorb_energy=..0}] minecraft:orb_untransform