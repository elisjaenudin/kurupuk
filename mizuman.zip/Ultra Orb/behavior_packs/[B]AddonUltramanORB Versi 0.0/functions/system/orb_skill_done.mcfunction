tag @s add skill_done
tag @s remove skill_done
event entity @s minecraft:default_var
event entity @s minecraft:ultraman_res