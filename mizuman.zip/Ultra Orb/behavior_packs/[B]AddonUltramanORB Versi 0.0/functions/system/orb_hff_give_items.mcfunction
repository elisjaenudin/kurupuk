clear @s item:orb_untransform
give @s item:orb_untransform 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}