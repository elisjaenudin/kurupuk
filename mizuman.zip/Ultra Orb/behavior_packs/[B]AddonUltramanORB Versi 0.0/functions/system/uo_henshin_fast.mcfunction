give @s[tag=uo_spacium_zeperion] item:orb_card_ultraman
give @s[tag=uo_spacium_zeperion] item:orb_card_ultraman_tiga

give @s[tag=uo_burnmite] item:orb_card_ultraman_taro
give @s[tag=uo_burnmite] item:orb_card_ultraman_mebius

give @s[tag=uo_hurricane_slash] item:orb_card_ultraman_jack
give @s[tag=uo_hurricane_slash] item:orb_card_ultraman_zero

give @s[tag=uo_thunder_breastar] item:orb_card_ultraman_zoffy
give @s[tag=uo_thunder_breastar] item:orb_card_ultraman_belial

give @s[tag=uo_origin] item:orb_card_orb_origin

give @s[tag=uo_trinity] item:orb_card_ultraman_ginga
give @s[tag=uo_trinity] item:orb_card_ultraman_victory
give @s[tag=uo_trinity] item:orb_card_ultraman_x

give @s[tag=uo_lightning_attacker] item:orb_card_ultraman_ginga
give @s[tag=uo_lightning_attacker] item:orb_card_ultraman_x

give @s[tag=uo_emerium_slugger] item:orb_card_ultraseven
give @s[tag=uo_emerium_slugger] item:orb_card_ultraman_zero

give @s[tag=uo_origin_the_first] item:orb_calibur_pure

tag @s remove uo_spacium_zeperion
tag @s remove uo_burnmite
tag @s remove uo_hurricane_slash
tag @s remove uo_thunder_breastar
tag @s remove uo_origin
tag @s remove uo_trinity
tag @s remove uo_lightning_attacker
tag @s remove uo_emerium_slugger
tag @s remove uo_origin_the_first

tag @s[tag=uo_spacium_zeperion_hf] add uo_spacium_zeperion
tag @s[tag=uo_burnmite_hf] add uo_burnmite
tag @s[tag=uo_hurricane_slash_hf] add uo_hurricane_slash
tag @s[tag=uo_thunder_breastar_hf] add uo_thunder_breastar
tag @s[tag=uo_origin_hf] add uo_origin
tag @s[tag=uo_trinity_hf] add uo_trinity
tag @s[tag=uo_lightning_attacker_hf] add uo_lightning_attacker
tag @s[tag=uo_emerium_slugger_hf] add uo_emerium_slugger

tag @s remove orb_on_slugger

scoreboard players set @s[tag=uo_hurricane_slash,tag=!orb_on_slugger] orb_slugger 2
tag @s[tag=uo_hurricane_slash] add orb_on_slugger

scoreboard players set @s[tag=uo_emerium_slugger,tag=!orb_on_slugger] orb_slugger 2
tag @s[tag=uo_emerium_slugger] add orb_on_slugger

event entity @s minecraft:ultraman_res

event entity @s[tag=uo_spacium_zeperion_hf] minecraft:uo_spacium_zeperion
event entity @s[tag=uo_burnmite_hf] minecraft:uo_burnmite
event entity @s[tag=uo_hurricane_slash_hf] minecraft:uo_hurricane_slash
event entity @s[tag=uo_thunder_breastar_hf] minecraft:uo_thunder_breastar
event entity @s[tag=uo_origin_hf] minecraft:uo_origin
event entity @s[tag=uo_trinity_hf] minecraft:uo_trinity
event entity @s[tag=uo_lightning_attacker_hf] minecraft:uo_lightning_attacker
event entity @s[tag=uo_emerium_slugger_hf] minecraft:uo_emerium_slugger

tag @s[tag=uo_spacium_zeperion_hf] remove uo_spacium_zeperion_hf
tag @s[tag=uo_burnmite_hf] remove uo_burnmite_hf
tag @s[tag=uo_hurricane_slash_hf] remove uo_hurricane_slash_hf
tag @s[tag=uo_thunder_breastar_hf] remove uo_thunder_breastar_hf
tag @s[tag=uo_origin_hf] remove uo_origin_hf
tag @s[tag=uo_trinity_hf] remove uo_trinity_hf
tag @s[tag=uo_lightning_attacker_hf] remove uo_lightning_attacker_hf
tag @s[tag=uo_emerium_slugger_hf] remove uo_emerium_slugger_hf