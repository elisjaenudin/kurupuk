clear @s item:orb_untransform
clear @s item:orb_sz_sparion_light_ring
clear @s item:orb_sz_sparion_beam

clear @s item:orb_b_stobium_burst
clear @s item:orb_b_stobium_beam

clear @s item:orb_hs_orb_slugger
clear @s item:orb_slugger_lance

clear @s item:orb_tb_energy_slicer
clear @s item:orb_tb_zettcium_beam

clear @s item:orb_calibur
clear @s item:orb_o_origium_beam

clear @s item:orb_slasher
clear @s item:orb_slasher_trinitium_giga_slash
clear @s item:orb_t_ex_red_king_knuckle
clear @s item:orb_t_ex_red_king_knuckle_attack
clear @s item:orb_t_cyber_gomora_armor
clear @s item:orb_t_cyber_gomora_armor_cross_slash

clear @s item:orb_la_lightning_attack
clear @s item:orb_la_attacker_ginga_x

clear @s item:orb_es_orb_slugger
clear @s item:orb_es_wide_slugger_shot
clear @s item:orb_es_triple_emerium_beam

clear @s item:orb_otf_orb_light_ring
clear @s item:orb_otf_orb_boomerang
clear @s item:orb_otf_origium_beam

event entity @s minecraft:ultraman_res
event entity @s minecraft:orbsupremecalibur_stop
event entity @s minecraft:default_res
event entity @s minecraft:default_skid
event entity @s minecraft:orb_rlowenergy
event entity @s minecraft:default_player

give @s[tag=uo_spacium_zeperion] item:orb_card_ultraman
give @s[tag=uo_spacium_zeperion] item:orb_card_ultraman_tiga

give @s[tag=uo_burnmite] item:orb_card_ultraman_taro
give @s[tag=uo_burnmite] item:orb_card_ultraman_mebius

give @s[tag=uo_hurricane_slash] item:orb_card_ultraman_jack
give @s[tag=uo_hurricane_slash] item:orb_card_ultraman_zero

give @s[tag=uo_thunder_breastar] item:orb_card_ultraman_zoffy
give @s[tag=uo_thunder_breastar] item:orb_card_ultraman_belial

give @s[tag=uo_origin] item:orb_card_orb_origin

give @s[tag=uo_trinity] item:orb_card_ultraman_ginga
give @s[tag=uo_trinity] item:orb_card_ultraman_victory
give @s[tag=uo_trinity] item:orb_card_ultraman_x

give @s[tag=uo_lightning_attacker] item:orb_card_ultraman_ginga
give @s[tag=uo_lightning_attacker] item:orb_card_ultraman_x

give @s[tag=uo_emerium_slugger] item:orb_card_ultraseven
give @s[tag=uo_emerium_slugger] item:orb_card_ultraman_zero

give @s[tag=uo_origin_the_first] item:orb_calibur_pure

scoreboard players set @s[tag=uo_hurricane_slash] orb_slugger 0
scoreboard players set @s[tag=uo_emerium_slugger] orb_slugger 0

tag @s remove orb_on_slugger

tag @s remove uo_spacium_zeperion
tag @s remove uo_burnmite
tag @s remove uo_hurricane_slash
tag @s remove uo_thunder_breastar
tag @s remove uo_origin
tag @s remove uo_trinity
tag @s remove uo_lightning_attacker
tag @s remove uo_emerium_slugger
tag @s remove uo_origin_the_first