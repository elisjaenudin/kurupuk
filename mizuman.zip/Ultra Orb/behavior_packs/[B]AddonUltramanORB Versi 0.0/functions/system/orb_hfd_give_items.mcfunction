clear @s item:orb_untransform
clear @s item:orb_card_ultraman_belial_pure

give @s item:orb_untransform 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
kill @e[type=item,name="Untransform"]

give @s item:orb_card_ultraman_belial_pure 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}