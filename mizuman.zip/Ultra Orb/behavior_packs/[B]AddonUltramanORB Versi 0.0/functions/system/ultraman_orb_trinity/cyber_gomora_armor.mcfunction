replaceitem entity @s slot.weapon.mainhand 0 item:orb_t_cyber_gomora_armor 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:orb_t_ex_red_king_knuckle
clear @s item:orb_t_ex_red_king_knuckle_attack