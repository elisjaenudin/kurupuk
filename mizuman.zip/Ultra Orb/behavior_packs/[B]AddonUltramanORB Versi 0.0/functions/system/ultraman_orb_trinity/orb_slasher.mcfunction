replaceitem entity @s slot.weapon.mainhand 0 item:orb_slasher 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:orb_t_cyber_gomora_armor
clear @s item:orb_t_cyber_gomora_armor_cross_slash