replaceitem entity @s slot.weapon.mainhand 0 item:orb_t_ex_red_king_knuckle 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
clear @s item:orb_slasher_trinitium_giga_slash