clear @s item:orb_untransform

clear @s item:orb_sz_sparion_light_ring
clear @s item:orb_sz_sparion_beam

clear @s item:orb_b_stobium_burst
clear @s item:orb_b_stobium_beam

clear @s item:orb_hs_orb_slugger
clear @s item:orb_slugger_lance

clear @s item:orb_tb_energy_slicer
clear @s item:orb_tb_zettcium_beam

clear @s item:orb_calibur
clear @s item:orb_o_origium_beam

clear @s item:orb_slasher
clear @s item:orb_slasher_trinitium_giga_slash
clear @s item:orb_t_ex_red_king_knuckle
clear @s item:orb_t_ex_red_king_knuckle_attack
clear @s item:orb_t_cyber_gomora_armor
clear @s item:orb_t_cyber_gomora_armor_cross_slash

clear @s item:orb_la_lightning_attack
clear @s item:orb_la_attacker_ginga_x

clear @s item:orb_es_orb_slugger
clear @s item:orb_es_wide_slugger_shot
clear @s item:orb_es_triple_emerium_beam

clear @s item:orb_otf_orb_light_ring
clear @s item:orb_otf_orb_boomerang
clear @s item:orb_otf_origium_beam

scoreboard objectives add orb_slugger dummy

give @s item:orb_untransform 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
kill @e[type=item,name="Untransform"]

give @s[tag=uo_spacium_zeperion] item:orb_sz_sparion_light_ring 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_spacium_zeperion] item:orb_sz_sparion_beam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

give @s[tag=uo_burnmite] item:orb_b_stobium_burst 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_burnmite] item:orb_b_stobium_beam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

give @s[tag=uo_hurricane_slash] item:orb_hs_orb_slugger 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_hurricane_slash] item:orb_slugger_lance 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
scoreboard players set @s[tag=uo_hurricane_slash,tag=!orb_on_slugger] orb_slugger 2
tag @s[tag=uo_hurricane_slash] add orb_on_slugger

give @s[tag=uo_thunder_breastar] item:orb_tb_energy_slicer 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_thunder_breastar] item:orb_tb_zettcium_beam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

give @s[tag=uo_origin] item:orb_calibur 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_origin] item:orb_o_origium_beam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

give @s[tag=uo_trinity] item:orb_slasher 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

give @s[tag=uo_lightning_attacker] item:orb_la_lightning_attack 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_lightning_attacker] item:orb_la_attacker_ginga_x 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

give @s[tag=uo_emerium_slugger] item:orb_es_orb_slugger 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_emerium_slugger] item:orb_es_wide_slugger_shot 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_emerium_slugger] item:orb_es_triple_emerium_beam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
scoreboard players set @s[tag=uo_emerium_slugger,tag=!orb_on_slugger] orb_slugger 2
tag @s[tag=uo_emerium_slugger] add orb_on_slugger

give @s[tag=uo_origin_the_first] item:orb_otf_orb_light_ring 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_origin_the_first] item:orb_otf_orb_boomerang 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=uo_origin_the_first] item:orb_otf_origium_beam 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

gamerule commandblockoutput false
gamerule sendcommandfeedback false
gamerule showtags false

event entity @s minecraft:default_var
event entity @s minecraft:orb_on_transform
event entity @s minecraft:ultraman_res
event entity @s minecraft:water_res