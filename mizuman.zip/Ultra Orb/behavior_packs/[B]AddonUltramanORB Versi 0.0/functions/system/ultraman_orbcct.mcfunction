scoreboard objectives add uorb_energy dummy
scoreboard players add @s[scores={uorb_energy=..2399}] uorb_energy 1

event entity @s[scores={uorb_energy=..0}] minecraft:orb_untransform