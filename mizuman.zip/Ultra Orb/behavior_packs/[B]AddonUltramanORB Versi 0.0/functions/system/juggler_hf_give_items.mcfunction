clear @s item:orb_untransform

clear @s item:zeppandon_fire_bullet
clear @s item:zeppandon_shield
clear @s item:zeppandon_giant_fireball
clear @s item:zeppandon_teleportation

give @s item:orb_untransform 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
kill @e[type=item,name="Untransform"]

give @s[tag=jj_zeppandon] item:zeppandon_fire_bullet 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=jj_zeppandon] item:zeppandon_shield 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=jj_zeppandon] item:zeppandon_giant_fireball 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}
give @s[tag=jj_zeppandon] item:zeppandon_teleportation 1 0 {"keep_on_death": {},"item_lock": {"mode": "lock_in_inventory"}}

gamerule commandblockoutput false
gamerule sendcommandfeedback false
gamerule showtags false

event entity @s minecraft:ultraman_res
event entity @s minecraft:water_res