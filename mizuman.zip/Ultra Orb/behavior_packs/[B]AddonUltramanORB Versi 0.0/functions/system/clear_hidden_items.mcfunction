clear @s item:orb_untransform

clear @s item:orb_sz_sparion_light_ring
clear @s item:orb_sz_sparion_beam

clear @s item:orb_b_stobium_burst
clear @s item:orb_b_stobium_beam

clear @s item:orb_hs_orb_slugger
clear @s item:orb_slugger_lance

clear @s item:orb_tb_energy_slicer
clear @s item:orb_tb_zettcium_beam

clear @s item:orb_calibur
clear @s item:orb_o_origium_beam

clear @s item:orb_slasher
clear @s item:orb_slasher_trinitium_giga_slash
clear @s item:orb_t_ex_red_king_knuckle
clear @s item:orb_t_ex_red_king_knuckle_attack
clear @s item:orb_t_cyber_gomora_armor
clear @s item:orb_t_cyber_gomora_armor_cross_slash

clear @s item:orb_la_lightning_attack
clear @s item:orb_la_attacker_ginga_x

clear @s item:orb_es_orb_slugger
clear @s item:orb_es_wide_slugger_shot
clear @s item:orb_es_triple_emerium_beam

clear @s item:orb_otf_orb_light_ring
clear @s item:orb_otf_orb_boomerang
clear @s item:orb_otf_origium_beam

clear @s item:zeppandon_fire_bullet
clear @s item:zeppandon_shield
clear @s item:zeppandon_giant_fireball
clear @s item:zeppandon_teleportation