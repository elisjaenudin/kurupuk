clear @s item:orb_untransform

clear @s item:zeppandon_fire_bullet
clear @s item:zeppandon_shield
clear @s item:zeppandon_giant_fireball
clear @s item:zeppandon_teleportation

event entity @s minecraft:default_res
event entity @s minecraft:default_skid
event entity @s minecraft:default_player

give @s[tag=jj_zeppandon] item:kaiju_card_zetton
give @s[tag=jj_zeppandon] item:kaiju_card_pandon

tag @s remove jj_zeppandon