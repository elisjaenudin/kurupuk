event entity @s ug_piston

execute @s[family=upgrade] ~~~ fill ~~~ ~~-1~ air