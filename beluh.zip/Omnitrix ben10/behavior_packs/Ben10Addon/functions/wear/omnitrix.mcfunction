clear @s[family=!omnitrix,family=!alien] omni:omnitrix 0 1

event entity @s[family=!omnitrix,family=!alien] omnitrix

event entity @s[family=!omnitrix,family=!alien] omnitrix

scoreboard objectives add aliens dummy
scoreboard players add @s aliens 0
scoreboard players add @s[scores={aliens=0},tag=!aliens_locked] aliens 10