scoreboard players add @s aliens 12
title @s actionbar §r§eAll Aliens Unlocked
