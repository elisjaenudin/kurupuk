execute @s[family=irongolem] ~~~ summon iron_golem ~~~
execute @s[family=boat] ~~~ summon boat ~~~
execute @s[family=minecart] ~~~ summon minecart ~~~
execute @s[family=furnace] ~~~ setblock ~~~ furnace
execute @s[family=noteblock] ~~~ setblock ~~~ noteblock
execute @s[family=piston] ~~~ setblock ~~~ piston

tag @s remove jump

playsound omni.off @s[family=alien]

event entity @s[m=c] reset
event entity @s[m=c] omnitrix

scoreboard players reset @s ripjaws

ride @s stop_riding
ride @e[r=2] stop_riding

effect @s clear

execute @s[family=waybig] ~~~ event entity @e[c=1,type=player:waybig_height] despawn

execute @s[family=ditto] ~~~ event entity @e[type=omni:ditto_clone] despawn

scoreboard players reset @s[m=!c,family=alien] omni_off
scoreboard players add @s[m=!c,family=alien] omni_off 4000

tag @s[m=s] add ms
tag @s[m=a] add ma
tag @s remove using
gamemode c
gamemode s @s[tag=ms]
gamemode a @s[tag=ma]
tag @s remove ms
tag @s remove ma
tag @s remove randomt