
scoreboard players reset @s[m=c] omni_off
scoreboard players add @s[m=!c,scores={omni_off=0..}] omni_off 1
playsound omni.off @s[scores={omni_off=4000}]
tag @s[scores={omni_charge=390..}] add randomt

title @s[scores={omni_off=1..200}] actionbar Battery : §l§a||||||||||||||||||||
title @s[scores={omni_off=200..400}] actionbar Battery : §l§a|||||||||||||||||||§l§7|
title @s[scores={omni_off=400..600}] actionbar Battery : §l§a||||||||||||||||||§l§7||
title @s[scores={omni_off=600..800}] actionbar Battery : §l§a|||||||||||||||||§l§7|||
title @s[scores={omni_off=800..1000}] actionbar Battery : §l§a||||||||||||||||§l§7||||
title @s[scores={omni_off=1000..1200}] actionbar Battery : §l§a|||||||||||||||§l§7|||||
title @s[scores={omni_off=1200..1400}] actionbar Battery : §l§a||||||||||||||§l§7||||||
title @s[scores={omni_off=1400..1600}] actionbar Battery : §l§a|||||||||||||§l§7|||||||
title @s[scores={omni_off=1600..1800}] actionbar Battery : §l§a||||||||||||§l§7||||||||
title @s[scores={omni_off=1800..2000}] actionbar Battery : §l§a|||||||||||§l§7|||||||||
title @s[scores={omni_off=2000..2200}] actionbar Battery : §l§a||||||||||§l§7||||||||||
title @s[scores={omni_off=2200..2400}] actionbar Battery : §l§a|||||||||§l§7|||||||||||
title @s[scores={omni_off=2400..2600}] actionbar Battery : §l§a||||||||§l§7||||||||||||
title @s[scores={omni_off=2600..2800}] actionbar Battery : §l§a|||||||§l§7|||||||||||||
title @s[scores={omni_off=2800..3000}] actionbar Battery : §l§e||||||§l§7||||||||||||||
title @s[scores={omni_off=3000..3200}] actionbar Battery : §l§e|||||§l§7|||||||||||||||
title @s[scores={omni_off=3200..3400}] actionbar Battery : §l§e||||§l§7||||||||||||||||
title @s[scores={omni_off=3400..3600}] actionbar Battery : §l§c|||§l§7|||||||||||||||||
title @s[scores={omni_off=3600..3800}] actionbar Battery : §l§c||§l§7||||||||||||||||||
title @s[scores={omni_off=3800..4000}] actionbar Battery : §l§c|§l§7|||||||||||||||||||
title @s[scores={omni_off=4000..}] actionbar Battery : §l§7|||||||||||||||||||| 

event entity @s[scores={omni_off=4000..}] omnitrix_off

scoreboard players add @s[scores={omni_off=4000..}] omni_charge 1

scoreboard players reset @s[scores={omni_off=4000..}] omni_off

scoreboard players add @s[scores={omni_charge=0..}] omni_charge 1
execute @s[m=c,scores={omni_charge=0..}] ~~~ function omni/charge

title @s[scores={omni_charge=0..10}] actionbar Battery : §l§7||||||||||||||||||||
title @s[scores={omni_charge=10..30}] actionbar Battery : §l§a|§l§7|||||||||||||||||||
title @s[scores={omni_charge=30..50}] actionbar Battery : §l§a||§l§7||||||||||||||||||
title @s[scores={omni_charge=50..70}] actionbar Battery : §l§a|||§l§7|||||||||||||||||
title @s[scores={omni_charge=70..90}] actionbar Battery : §l§a||||§l§7||||||||||||||||
title @s[scores={omni_charge=90..110}] actionbar Battery : §l§a|||||§l§7|||||||||||||||
title @s[scores={omni_charge=110..130}] actionbar Battery : §l§a||||||§l§7||||||||||||||
title @s[scores={omni_charge=130..150}] actionbar Battery : §l§a|||||||§l§7|||||||||||||
title @s[scores={omni_charge=150..170}] actionbar Battery : §l§a||||||||§l§7||||||||||||
title @s[scores={omni_charge=170..190}] actionbar Battery : §l§a|||||||||§l§7|||||||||||
title @s[scores={omni_charge=190..210}] actionbar Battery : §l§a||||||||||§l§7||||||||||
title @s[scores={omni_charge=210..230}] actionbar Battery : §l§a|||||||||||§l§7|||||||||
title @s[scores={omni_charge=230..250}] actionbar Battery : §l§a||||||||||||§l§7||||||||
title @s[scores={omni_charge=250..270}] actionbar Battery : §l§a|||||||||||||§l§7|||||||
title @s[scores={omni_charge=270..290}] actionbar Battery : §l§a||||||||||||||§l§7||||||
title @s[scores={omni_charge=290..310}] actionbar Battery : §l§a|||||||||||||||§l§7|||||
title @s[scores={omni_charge=310..330}] actionbar Battery : §l§a||||||||||||||||§l§7||||
title @s[scores={omni_charge=330..350}] actionbar Battery : §l§a|||||||||||||||||§l§7|||
title @s[scores={omni_charge=350..370}] actionbar Battery : §l§a||||||||||||||||||§l§7||
title @s[scores={omni_charge=370..390}] actionbar Battery : §l§a|||||||||||||||||||§l§7|
title @s[scores={omni_charge=390..}] actionbar Battery : §l§a||||||||||||||||||||

event entity @s[scores={omni_charge=390..}] omnitrix

scoreboard players reset @s[scores={omni_charge=390..}] omni_charge