event entity @s ug_furnace

execute @s[family=upgrade] ~~~ fill ~~~ ~~-1~ air