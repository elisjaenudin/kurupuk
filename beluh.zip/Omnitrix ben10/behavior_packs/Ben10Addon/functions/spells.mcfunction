title @s[scores={spells=1}] actionbar §bEnergy blast
title @s[scores={spells=2}] actionbar §bEnergy shield
title @s[scores={spells=3}] actionbar §bTelekinesis
title @s[scores={spells=4}] actionbar §bLevitate