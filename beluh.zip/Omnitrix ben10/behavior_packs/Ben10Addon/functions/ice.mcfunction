event entity @e[r=2,type=power:arc_ice2] despawn

fill ~3~3~3 ~-3 ~-3 ~-3 ice 0 replace Water

fill ~2~2~2 ~-2 ~-2 ~-2 air 0 replace fire

execute @e[type=power:arc_ice] ~~~ execute @e[r=2,type=!power:arc_ice,type=!power:arc_ice2,family=!arctiguana,family=!npc,type=!item] ~~~ summon power:arc_ice2

kill @e[type=power:arc_ice, r=1]