event entity @s ug_noteblock

execute @s[family=upgrade] ~~~ fill ~~~ ~~-1~ air