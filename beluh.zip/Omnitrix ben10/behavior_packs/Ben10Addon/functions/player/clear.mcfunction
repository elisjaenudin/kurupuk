tag @s[family=!omni_inuse] remove omni_using
tag @s[scores={aliens=1..}] remove aliens_locked
tag @s remove alien

clear @s[family=!omnitrix] omni:omni_icon
clear @s omni:omni_off
clear @s[family=!omnitrix] omni:omni_random
clear @s power:fire_ball
clear @s power:dh_crystal
clear @s power:dh_spike
clear @s power:sf_slime
clear @s power:wv_plant
clear @s power:wv_seeds
clear @s power:wv_stretch
clear @s power:bw_howl
clear @s power:bm_stretch
clear @s power:bm_grapple
clear @s power:bv_lightning
clear @s power:bv_electrokinesis
clear @s power:up_tongue
clear @s power:ug_laser
clear @s power:ug_laser2
clear @s power:ug_jump
clear @s power:ug_sonar
clear @s power:ug_bomb
clear @s power:upgrade
clear @s power:eyelaser
clear @s power:eyefire
clear @s power:eyeice
clear @s power:clock_beam
clear @s power:clock_time
clear @s power:clock_stop
clear @s power:dt_clone
clear @s power:arc_ice
clear @s power:wb_stomp
clear @s power:wb_ray