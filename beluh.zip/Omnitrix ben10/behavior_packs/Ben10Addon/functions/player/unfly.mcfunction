tag @s remove flying
tag @s remove jump

tag @s[m=s] add ms
tag @s[m=a] add ma
tag @s remove using
gamemode c
gamemode s @s[tag=ms]
gamemode a @s[tag=ma]
tag @s remove ms
tag @s remove ma
tag @s remove randomt
abbility @s mayfly false