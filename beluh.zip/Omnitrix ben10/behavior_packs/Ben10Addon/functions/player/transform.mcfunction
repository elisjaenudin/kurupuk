tag @s remove omni_using
clear @s omni:omni_icon
particle minecraft:totem_particle ~ ~1 ~
particle minecraft:totem_particle ~ ~1 ~
particle minecraft:totem_particle ~ ~1 ~
particle minecraft:totem_particle ~ ~1 ~


event entity @s[tag=random] random_alien
event entity @s[family=omni_waybig,tag=!random] waybig
event entity @s[family=omni_clockwork,tag=!random] clockwork
event entity @s[family=omni_arctiguana,tag=!random] arctiguana
event entity @s[family=omni_eyeguy,tag=!random] eyeguy
event entity @s[family=omni_ditto,tag=!random] ditto
event entity @s[family=omni_upchuck,tag=!random] upchuck
event entity @s[family=omni_benvictor,tag=!random] benvictor
event entity @s[family=omni_benmummy,tag=!random] benmummy
event entity @s[family=omni_benwolf,tag=!random] benwolf
event entity @s[family=omni_wildvine,tag=!random] wildvine
event entity @s[family=omni_cannonbolt,tag=!random] cannonbolt
event entity @s[family=omni_ghostfreak,tag=!random] ghostfreak
event entity @s[family=omni_upgrade,tag=!random] upgrade
event entity @s[family=omni_ripjaws,tag=!random] ripjaws
event entity @s[family=omni_stinkfly,tag=!random] stinkfly
event entity @s[family=omni_fourarms,tag=!random] fourarms
event entity @s[family=omni_greymatter,tag=!random] greymatter
event entity @s[family=omni_xlr8,tag=!random] xlr8
event entity @s[family=omni_diamondhead,tag=!random] diamondhead
event entity @s[family=omni_wildmutt,tag=!random] wildmutt
event entity @s[family=omni_heatblast,tag=!random] heatblast
scoreboard objectives add ripjaws dummy


scoreboard objectives add omni_off dummy
scoreboard players add @s omni_off 0
scoreboard objectives add omni_charge dummy