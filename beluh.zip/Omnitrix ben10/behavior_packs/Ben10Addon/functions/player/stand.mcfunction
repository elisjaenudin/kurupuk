event entity @s[family=omni_inuse,tag=sneaking] omnitrix_use

scoreboard players add @s[lm=10,scores={omni_menu_option=2}] aliens 1
xp -10l @s[lm=10,scores={omni_menu_option=2}]

execute @s[scores={omni_menu_option=3}] ~~~ function reset
give @s[scores={omni_menu_option=3}] omni:omnitrix

tag @s[scores={omni_menu_option=4}] remove master_control
scoreboard players reset @s[scores={omni_menu_option=4}] aliens
tag @s[scores={omni_menu_option=4}] add aliens_locked

execute @s[scores={omni_menu_option=5}] ~~~ function omni/destruct

execute @s[lm=30,scores={omni_menu_option=6}] ~~~ tag @s add master_control

xp -301 @s[lm=30,scores={omni_menu_option=6}]

scoreboard players reset @s[scores={omni_menu_option=1..}] omni_menu_option

tag @s remove sneaking
tag @s remove omni_menu