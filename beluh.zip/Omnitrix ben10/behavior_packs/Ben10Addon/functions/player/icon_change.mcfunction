playsound omni.opt_change @s[family=omnitrix,family=!alien]

event entity @s[scores={aliens=21..},family=omni_waybig] omnitrix

event entity @s[scores={aliens=!21..},family=omni_clockwork] omnitrix
event entity @s[scores={aliens=21..},family=omni_clockwork] omni_waybig

event entity @s[scores={aliens=!20..},family=omni_arctiguana] omnitrix
event entity @s[scores={aliens=20..},family=omni_arctiguana] omni_clockwork

event entity @s[scores={aliens=!19..},family=omni_eyeguy] omnitrix
event entity @s[scores={aliens=19..},family=omni_eyeguy] omni_arctiguana

event entity @s[scores={aliens=!18..},family=omni_ditto] omnitrix
event entity @s[scores={aliens=18..},family=omni_ditto] omni_eyeguy

event entity @s[scores={aliens=!17..},family=omni_upchuck] omnitrix
event entity @s[scores={aliens=17..},family=omni_upchuck] omni_ditto

event entity @s[scores={aliens=!16..},family=omni_benvictor] omnitrix
event entity @s[scores={aliens=16..},family=omni_benvictor] omni_upchuck

event entity @s[scores={aliens=!15..},family=omni_benmummy] omnitrix
event entity @s[scores={aliens=15..},family=omni_benmummy] omni_benvictor

event entity @s[scores={aliens=!14..},family=omni_benwolf] omnitrix
event entity @s[scores={aliens=14..},family=omni_benwolf] omni_benmummy

event entity @s[scores={aliens=!13..},family=omni_wildvine] omnitrix
event entity @s[scores={aliens=13..},family=omni_wildvine] omni_benwolf

event entity @s[scores={aliens=!12..},family=omni_cannonbolt] omnitrix
event entity @s[scores={aliens=12..},family=omni_cannonbolt] omni_wildvine

event entity @s[scores={aliens=!11..},family=omni_ghostfreak] omnitrix
event entity @s[scores={aliens=11..},family=omni_ghostfreak] omni_cannonbolt

event entity @s[scores={aliens=!10..},family=omni_ripjaws] omnitrix
event entity @s[scores={aliens=10..},family=omni_ripjaws] omni_ghostfreak

event entity @s[scores={aliens=!9..},family=omni_upgrade] omnitrix
event entity @s[scores={aliens=9..},family=omni_upgrade] omni_ripjaws

event entity @s[scores={aliens=!8..},family=omni_stinkfly] omnitrix
event entity @s[scores={aliens=8..},family=omni_stinkfly] omni_upgrade

event entity @s[scores={aliens=!7..},family=omni_fourarms] omnitrix
event entity @s[scores={aliens=7..},family=omni_fourarms] omni_stinkfly

event entity @s[scores={aliens=!6..},family=omni_greymatter] omnitrix
event entity @s[scores={aliens=6..},family=omni_greymatter] omni_fourarms

event entity @s[scores={aliens=!5..},family=omni_xlr8] omnitrix
event entity @s[scores={aliens=5..},family=omni_xlr8] omni_greymatter

event entity @s[scores={aliens=!4..},family=omni_diamondhead] omnitrix
event entity @s[scores={aliens=4..},family=omni_diamondhead] omni_xlr8

event entity @s[scores={aliens=!3..},family=omni_wildmutt] omnitrix
event entity @s[scores={aliens=3..},family=omni_wildmutt] omni_diamondhead

event entity @s[scores={aliens=!2..},family=omni_heatblast] omnitrix
event entity @s[scores={aliens=2..},family=omni_heatblast] omni_wildmutt

event entity @s[scores={aliens=!1..},family=omni_unused] omnitrix
event entity @s[scores={aliens=1..},family=omni_unused] omni_heatblast

title @s[tag=aliens_locked,family=omni_unused] actionbar §r§cAliens are locked