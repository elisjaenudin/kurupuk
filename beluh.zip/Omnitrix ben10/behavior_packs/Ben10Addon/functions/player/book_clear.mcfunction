clear @s power:spell_blast
clear @s power:spell_shield
clear @s power:spell_levi
scoreboard players reset @s spells
clear @s power:spell_fly
tag @s remove spell