execute @s ~~~ detect ~0~1~-1 air 0 tag @s add s1
execute @s ~~~ detect ~1~1~0 air 0 tag @s add s2
execute @s ~~~ detect ~0~1~1 air 0 tag @s add s3
execute @s ~~~ detect ~-1~1~0 air 0 tag @s add s4
execute @s[tag=s1] ~~~ execute @s[tag=s2] ~~~ execute @s[tag=s3] ~~~ execute @s[tag=s4] ~~~ tag @s add cant_climb
tag @s remove s1
tag @s remove s2
tag @s remove s3
tag @s remove s4
execute @s ~~~ effect @s[tag=!cant_climb] levitation 1 2 true
tag @s remove cant_climb