tag @s[family=alien] add alien

ability @s[family=stinkfly] mayfly true
ability @s[family=ghostfreak] mayfly true