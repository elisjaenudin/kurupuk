execute @s[family=irongolem] ~~~ summon iron_golem ~~~
execute @s[family=boat] ~~~ summon boat ~~~
execute @s[family=minecart] ~~~ summon minecart ~~~
execute @s[family=furnace] ~~~ setblock ~~~ furnace
execute @s[family=noteblock] ~~~ setblock ~~~ noteblock
execute @s[family=piston] ~~~ setblock ~~~ piston
                          
event entity @s[family=upgrade] upgrade