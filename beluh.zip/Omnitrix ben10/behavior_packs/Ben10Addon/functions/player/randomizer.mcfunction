effect @s clear
tag @s remove omni_using
ride @s stop_riding
clear @s power:fire_ball
clear @s power:dh_crystal
clear @s power:dh_spike
clear @s power:sf_slime
clear @s power:wv_plant
clear @s power:wv_seeds
clear @s power:wv_stretch
clear @s power:bw_howl
clear @s power:bm_stretch
clear @s power:bm_grapple
clear @s power:bv_lightning
clear @s power:bv_electrokinesis
clear @s power:up_tongue
clear @s power:ug_laser
clear @s power:ug_laser2
clear @s power:ug_jump
clear @s power:ug_sonar
clear @s power:ug_bomb
clear @s power:upgrade
clear @s power:eyelaser
clear @s power:eyefire
clear @s power:eyeice
clear @s power:clock_beam
clear @s power:clock_time
clear @s power:clock_stop
clear @s power:dt_clone
clear @s power:arc_ice
clear @s power:wb_stomp
clear @s power:wb_ray
tag @s remove omni_using
clear @s omni:omni_icon
effect @s clear
particle minecraft:totem_particle ~ ~1 ~
particle minecraft:totem_particle ~ ~1 ~
particle minecraft:totem_particle ~ ~1 ~
particle minecraft:totem_particle ~ ~1 ~
function player/unfly

event entity @s random_alien
playsound omni.used @s[tag=!omni_using]
scoreboard objectives add ripjaws dummy
scoreboard objectives add omni_off dummy
scoreboard players add @s omni_off 0
scoreboard objectives add omni_charge dummy