execute @e[type=iron_golem,r=2] ~~~ execute @p[family=!irongolem,r=2] ~~~ function 1
execute @e[type=boat,r=2] ~~~ execute @p[family=!boat,r=2] ~~~ function 2
execute @e[type=minecart,r=2] ~~~ execute @p[family=!minecart,r=2] ~~~ function 4
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ furnace 0 function 3
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ furnace 1 function 3
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ furnace 2 function 3
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ furnace 3 function 3
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ furnace 4 function 3
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ furnace 5 function 3
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ noteblock 0 function 5
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ noteblock 1 function 5
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ noteblock 2 function 5
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ noteblock 3 function 5
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ noteblock 4 function 5
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ noteblock 5 function 5
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ piston 0 function 6
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ piston 1 function 6
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ piston 2 function 6
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ piston 3 function 6
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ piston 4 function 6
execute @s[family=upgrade] ~ ~ ~ detect ~ ~-1 ~ piston 5 function 6