event entity @e[r=2,type=power:eyeice2] despawn

execute @e[type=power:eyeice] ~~~ execute @e[r=2,type=!power:eyeice,type=!power:eyeice2,family=!eyeguy,family=!npc,type=!item] ~~~ summon power:eyeice2

kill @e[type=power:eyeice, r=1]