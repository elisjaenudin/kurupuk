execute @e[type=power:bv_lightning2] ~~~ effect @e[r=3,family=monster] wither 4 2 true

execute @e[type=power:bv_lightning2] ~~~ summon lightning_bolt ~~~

kill @e[type=power:bv_lightning2, r=1]