particle minecraft:lava_particle ^ ^ ^-2.3
particle minecraft:lava_particle ^ ^ ^2.3

particle hcycle:burning_smoke ^ ^ ^-2.1
particle hcycle:burning_smoke ^ ^ ^2.1

particle minecraft:basic_smoke_particle ^ ^ ^-2.1
particle minecraft:basic_smoke_particle ^ ^ ^2.1

setblock ^ ^ ^-3 fire 0 replace

effect @p[c=1,r=1] fire_resistance 20 1 true
effect @p[c=1,r=1] night_vision 20 1 true
effect @p[c=1,r=1] strength 15 2 true

