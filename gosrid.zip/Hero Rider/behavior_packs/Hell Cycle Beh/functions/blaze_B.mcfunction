particle minecraft:blue_flame_particle ^ ^ ^-3
particle minecraft:blue_flame_particle ^ ^ ^2.3
particle minecraft:blue_flame_particle ^ ^0.3 ^-2.6
particle minecraft:blue_flame_particle ^ ^0.3 ^2.6
particle minecraft:blue_flame_particle ^ ^0.1 ^-2.2
particle minecraft:blue_flame_particle ^ ^0.1 ^2.2

particle hcycle:burning_smoke ^ ^ ^-2.1
particle hcycle:burning_smoke ^ ^ ^2.1

setblock ^ ^ ^-2.5 hcycle:blue_fire

effect @p fire_resistance 20 1 true
effect @p night_vision 20 1 true
effect @p strength 15 2 true

