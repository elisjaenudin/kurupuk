particle minecraft:lava_particle ^ ^ ^-1.5
particle minecraft:lava_particle ^ ^ ^1.5

particle hcycle:burning_smoke ^ ^ ^-1.5
particle hcycle:burning_smoke ^ ^ ^1.5

particle minecraft:basic_smoke_particle ^ ^ ^-1.5
particle minecraft:basic_smoke_particle ^ ^ ^1.5

setblock ^ ^ ^-2 fire 0 keep

effect @p fire_resistance 20 1 true
effect @p night_vision 20 1 true
effect @p strength 15 2 true

