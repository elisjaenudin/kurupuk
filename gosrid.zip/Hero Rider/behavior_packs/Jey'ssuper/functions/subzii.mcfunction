execute @e [type=!player,r=5] ~~~ particle jeys:subzerofour ~~~
execute @e [type=!player,r=5] ~~~ summon mc:subfang ~~~