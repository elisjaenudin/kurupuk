execute @e [type=!player,r=4] ~~~ effect @p levitation 1 9 true
execute @e [r=5] ~~~ particle jeys:scorpfour ~~~