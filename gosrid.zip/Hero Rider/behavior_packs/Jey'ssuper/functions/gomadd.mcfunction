execute @p [scores={gan=1}] ~~~ replaceitem entity @p slot.weapon.mainhand 0 mc:gauntletspace 1 0 {"item_lock":{"mode":"lock_in_slot"}}
execute @p [scores={gan=2}] ~~~ replaceitem entity @p slot.weapon.mainhand 0 mc:gauntletmind 1 0 {"item_lock":{"mode":"lock_in_slot"}}
execute @p [scores={gan=3}] ~~~ replaceitem entity @p slot.weapon.mainhand 0 mc:gauntletsoul 1 0 {"item_lock":{"mode":"lock_in_slot"}}
execute @p [scores={gan=4}] ~~~ replaceitem entity @p slot.weapon.mainhand 0 mc:gauntletreality 1 0 {"item_lock":{"mode":"lock_in_slot"}}
execute @p [scores={gan=5}] ~~~ replaceitem entity @p slot.weapon.mainhand 0 mc:gauntletpower 1 0 {"item_lock":{"mode":"lock_in_slot"}}
execute @p [scores={gan=6}] ~~~ replaceitem entity @p slot.weapon.mainhand 0 mc:gauntlettime 1 0 {"item_lock":{"mode":"lock_in_slot"}}
camera @p fade color 255 255 255




camera @p clear







execute @p [scores={gan=1..10}] ~~~ scoreboard players set @p gan 0

