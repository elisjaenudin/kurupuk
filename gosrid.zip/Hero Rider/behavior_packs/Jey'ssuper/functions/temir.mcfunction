execute @p [scores={menu=10}] ~~~ give @p js:repulsor
execute @p [scores={menu=20}] ~~~ scoreboard players set @p mask 60
execute @p [scores={menu=20}] ~~~ say sneak to activate the shield

execute @p [scores={menu=30}] ~~~ scoreboard players set @p mask 70
execute @p [scores={menu=40}] ~~~ give @p mc:unmask
execute @p [scores={menu=10}] ~~~ scoreboard players set @p mask 0
execute @p [scores={menu=40}] ~~~ scoreboard players set @p mask 0
