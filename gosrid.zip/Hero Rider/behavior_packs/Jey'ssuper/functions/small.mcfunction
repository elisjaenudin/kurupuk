replaceitem entity @p slot.armor.head 0 js:antmanmini
scoreboard players set @p menu 0
tag @p add small