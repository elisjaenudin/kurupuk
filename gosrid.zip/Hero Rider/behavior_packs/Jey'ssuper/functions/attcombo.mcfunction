scoreboard objectives add comb dummy comb
scoreboard players add @p comb 1
scoreboard players set @p [scores={comb=101..1000}] comb 0


execute @s [scores={comb=10}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=20}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=30}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=40}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=50}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=60}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=70}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=90}] ~~~ summon mc:comb ~~~


execute @s [tag=!spider,scores={comb=10}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo
execute @s [tag=!spider,scores={comb=20}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo2
execute @s [tag=!spider,scores={comb=30}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo3
execute @s [tag=!spider,scores={comb=40}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo4
execute @s [tag=!spider,scores={comb=50}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo5
execute @s [tag=!spider,scores={comb=60}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo6
execute @s [tag=!spider,scores={comb=70}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo7
execute @s [tag=!spider,scores={comb=80}] ~~~ playanimation @p [tag=!spider] animation.jeys.combo8

execute @s [scores={comb=80}] ~~~ effect @e [type=!player,r=3] levitation 1 5 true

execute @s [scores={comb=40}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=50}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=70}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=30}] ~~~ camerashake add @p 1 1 

