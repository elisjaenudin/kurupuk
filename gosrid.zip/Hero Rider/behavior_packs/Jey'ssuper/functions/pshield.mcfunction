give @p mc:sheld 
say sneak to activate
scoreboard players set @p menu 0