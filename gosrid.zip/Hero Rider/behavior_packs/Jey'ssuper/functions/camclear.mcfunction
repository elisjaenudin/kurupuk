tag @p remove arrocam
camera @p clear