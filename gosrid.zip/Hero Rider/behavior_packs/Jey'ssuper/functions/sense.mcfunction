tp @p ^2^1^ 
playanimation @p animation.spidey.sense null