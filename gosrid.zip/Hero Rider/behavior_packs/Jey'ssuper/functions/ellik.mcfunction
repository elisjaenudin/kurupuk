function js_ironmann
replaceitem entity @p slot.hotbar 6 mc:unsuit
tag @p remove mark50