kill @e [type=z:menu]
summon z:menu ~~~ openm
event entity @e openm
scoreboard objectives add menu dummy menu
scoreboard objectives setdisplay belowname menu
scoreboard players set @p menu 100