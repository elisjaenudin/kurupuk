give @s mc:nightwing
