tag @p add spider

replaceitem entity @p slot.hotbar 1 js:karenmenu
replaceitem entity @p slot.hotbar 3 mc:unmask
replaceitem entity @p slot.hotbar 5 js:webswing
replaceitem entity @p slot.hotbar 6 js:venbl

tag @p add spider