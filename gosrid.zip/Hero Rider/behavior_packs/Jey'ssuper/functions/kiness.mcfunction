execute @p ~~~ tp @e [r=3,family=mob] ^ ^0.3 ^1.5 
execute @e [r=3,c=1,type=!player] ~~~ particle jeys:wandahold ~~~