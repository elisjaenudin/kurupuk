replaceitem entity @p slot.hotbar 1 js:jarvis
replaceitem entity @p slot.hotbar 2 mc:centralmode
tag @p add ironman