execute @p [scores={menu=70}] ~~~ replaceitem entity @p slot.armor.head 0 js:spidermanintegrated
execute @p [scores={menu=71}] ~~~ replaceitem entity @p slot.armor.head 0 js:spidermanps4
execute @p [scores={menu=72}] ~~~ replaceitem entity @p slot.armor.head 0 js:spiderman
execute @p [scores={menu=73}] ~~~ replaceitem entity @p slot.armor.head 0 js:spidermansymbiote
execute @p [scores={menu=70}] ~~~ function js_spiderman
execute @p [scores={menu=71}] ~~~ function js_spiderman
execute @p [scores={menu=72}] ~~~ function js_spiderman
execute @p [scores={menu=73}] ~~~ function miles

scoreboard players set @p menu 0



























scoreboard players set @p menu 0 