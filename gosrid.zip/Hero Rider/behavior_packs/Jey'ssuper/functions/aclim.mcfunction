execute @p ~~~ detect ~ ~2 ~ cobblestone 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ cobblestone 0 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ log 0 effect @p levitation 1 1 true



execute @p ~~~ detect ~ ~2 ~ log 0 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ log 1 effect @p levitation 1 1 true



execute @p ~~~ detect ~ ~2 ~ log 1 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ stone 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ stone 0 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ snow 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ snow 0 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ clay 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ clay 0 effect @p slow_falling 1 1 true




execute @p ~~~ detect ~ ~2 ~ stonebrick 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ stonebrick 0 effect @p slow_falling 1 1 true




execute @p ~~~ detect ~ ~2 ~ sand 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ sand 0 effect @p slow_falling 1 1 true




execute @p ~~~ detect ~ ~2 ~ sandstone 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ sandstone 0 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ quartz_block 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ quartz_block 0 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ planks 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ planks 0 effect @p slow_falling 1 1 true





execute @p ~~~ detect ~ ~2 ~ planks 1 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ planks 1 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ planks 2 effect @p levitation 1 1 true


execute @p ~~~ detect ~ ~2 ~ planks 2 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ planks 3 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ planks 3 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ planks 4 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ planks 4 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ planks 5 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ planks 5 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ packed_ice 0 effect @p levitation 1 1 true





execute @p ~~~ detect ~ ~2 ~ packed_ice 0 effect @p slow_falling 1 1 true




execute @p ~~~ detect ~ ~2 ~ ice 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ ice 0 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ obsidian 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ obsidian 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ log 2 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ log 2 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ log 3 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ log 3 effect @p slow_falling 1 1 true


mcjey
execute @p ~~~ detect ~ ~2 ~ log2 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ log2 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ log2 1 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ log2 1 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ gravel 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ gravel 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ glowstone 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ glowstone 0 effect @p slow_falling 1 1 true


mcjey

execute @p ~~~ detect ~ ~2 ~ bedrock 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ bedrock 0 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ diamond_block 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ diamond_block 0 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ diamond_ore 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ diamond_ore 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ redstone_block 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ redstone_block 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ redstone_ore 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ redstone_ore 0 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ slime 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ slime 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ emerald_block 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ emerald_block 0 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ emerald_ore 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ emerald_ore 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ end_stone 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ end_stone 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ glass 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ glass 0 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ stained_glass 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ stained_glass 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ concrete 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 0 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 1 effect @p levitation 1 1 true



execute @p ~~~ detect ~ ~2 ~ concrete 1 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 2 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 2 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 3 effect @p levitation 1 1 true




execute @p ~~~ detect ~ ~2 ~ concrete 3 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 4 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 4 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 5 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 5 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ concrete 6 effect @p levitation 1 1 true




execute @p ~~~ detect ~ ~2 ~ concrete 6 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ concrete 7 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 7 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ concrete 8 effect @p levitation 1 1 true

execute @p ~~~ detect ~ ~2 ~ concrete 8 effect @p slow_falling 1 1 true

mcjey

execute @p ~~~ detect ~ ~2 ~ concrete 9 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 9 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ concrete 10 effect @p levitation 1 1 true

execute @p ~~~ detect ~ ~2 ~ concrete 10 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ concrete 12 effect @p levitation 1 1 true



execute @p ~~~ detect ~ ~2 ~ concrete 12 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ wool 0 effect @p levitation 1 1 true

execute @p ~~~ detect ~ ~2 ~ wool 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ wool 1 effect @p levitation 1 1 true



execute @p ~~~ detect ~ ~2 ~ wool 1 effect @p slow_falling 1 1 true




execute @p ~~~ detect ~ ~2 ~ wool 2 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 2 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 3 effect @p levitation 1 1 true

execute @p ~~~ detect ~ ~2 ~ wool 3 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ wool 4 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 4 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 5 effect @p levitation 1 1 true

mcjey

execute @p ~~~ detect ~ ~2 ~ wool 5 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 6 effect @p levitation 1 1 true

execute @p ~~~ detect ~ ~2 ~ wool 6 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 7 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 7 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 8 effect @p levitation 1 1 true


mcjey mod-z

execute @p ~~~ detect ~ ~2 ~ wool 8 effect @p slow_falling 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 9 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 9 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ wool 10 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 10 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ wool 11 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wool 11 effect @p slow_falling 1 1 true

execute @p ~~~ detect ~ ~2 ~ stone 1 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ stone 1 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ crafting_table 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ crafting_tablel 0 effect @p slow_falling 1 1 true




execute @p ~~~ detect ~ ~2 ~ fence 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ fence 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ glass 2 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ glass 3 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ wood 0 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wood 0 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ wood 1 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wood 1 effect @p slow_falling 1 1 true


execute @p ~~~ detect ~ ~2 ~ wood 2 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wood 2 effect @p slow_falling 1 1 true



execute @p ~~~ detect ~ ~2 ~ wood 3 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wood 3 effect @p slow_falling 1 1 true




execute @p ~~~ detect ~ ~2 ~ wood 4 effect @p levitation 1 1 true
execute @p ~~~ detect ~ ~2 ~ wood 4 effect @p slow_falling 1 1 true

mcjey = do not steal me

