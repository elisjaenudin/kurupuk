particle niki:yerdaolov ~~~ 
setblock ~~~ fire