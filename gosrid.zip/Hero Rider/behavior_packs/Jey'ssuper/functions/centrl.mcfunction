summon ety:mark50
tag @p add mark50
replaceitem entity @p slot.armor.head 0 air