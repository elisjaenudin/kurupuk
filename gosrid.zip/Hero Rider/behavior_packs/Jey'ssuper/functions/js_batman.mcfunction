replaceitem entity @p slot.hotbar 1 js:batmenu
replaceitem entity @p slot.hotbar 3 mc:unmask
replaceitem entity @p slot.hotbar 4 js:batrangsmoke 
replaceitem entity @p slot.hotbar 2 mc:grapplinghook
replaceitem entity @p slot.hotbar 5 mc:batmsummoner

replaceitem entity @p slot.armor.chest 0 elytra
tag @p add batman