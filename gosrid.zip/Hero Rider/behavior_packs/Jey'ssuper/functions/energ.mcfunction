execute @p [scores={energy=100..200}] ~~~ effect @p levitation 1 30 true
execute @p ~~~ tag @p remove sneaked
execute @p [scores={energy=100..200}] ~~~ camerashake add @p 1 0.4
scoreboard players set @p energy 0