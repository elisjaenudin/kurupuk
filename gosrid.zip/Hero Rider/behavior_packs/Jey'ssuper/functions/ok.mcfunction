execute @p [tag=ironman] ~~~ function temir
execute @p [tag=batman] ~~~ function betmen
execute @p [tag=spider] ~~~ function spider
scoreboard players set @p hud 0 