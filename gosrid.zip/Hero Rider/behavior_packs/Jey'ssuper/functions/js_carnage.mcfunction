replaceitem entity @p slot.hotbar 3 mc:unmask
replaceitem entity @p slot.hotbar 2 js:symbioteaxeven