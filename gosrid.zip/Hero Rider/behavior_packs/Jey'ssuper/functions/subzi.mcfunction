summon mc:subfang ^^^1
summon mc:subfang ^^^3
summon mc:subfang ^^^5
summon mc:subfang ^^^7
summon mc:subfang ^^^9
summon mc:subfang ^^^11
summon mc:subfang ^^^-1
summon mc:subfang ^^^-3
summon mc:subfang ^^^-5
summon mc:subfang ^^^-7
execute @e [type=!player,r=4] ~~~ particle jeys:subzerofive ~~~