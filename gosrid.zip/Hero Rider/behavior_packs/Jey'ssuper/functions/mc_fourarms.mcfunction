give @s mc:fourarms
