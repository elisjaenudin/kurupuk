give @s mc:wolverinex
