setblock ~~~ web
