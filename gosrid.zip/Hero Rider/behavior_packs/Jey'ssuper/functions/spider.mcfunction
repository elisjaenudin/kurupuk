execute @p [scores={menu=10}] ~~~ give @p js:webshooter
execute @p [scores={menu=20}] ~~~ give @p js:webomb

execute @p [scores={menu=30}] ~~~ give @p js:webricochet
execute @p [scores={menu=40}] ~~~ give @p js:webfast
