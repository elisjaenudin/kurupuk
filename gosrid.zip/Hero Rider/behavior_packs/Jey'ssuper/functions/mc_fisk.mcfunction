give @s mc:fisk
