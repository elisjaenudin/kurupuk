replaceitem entity @p slot.hotbar 1 nk:lightningdual
replaceitem entity @p slot.hotbar 2 mc:sheld
replaceitem entity @p slot.hotbar 4 nk:lightningblast
replaceitem entity @p slot.hotbar 5 mc:shmashes