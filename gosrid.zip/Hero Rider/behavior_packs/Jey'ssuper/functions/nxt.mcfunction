kill @e [type=z:menu]
summon z:menu ~~~ selectmorph
event entity @e colors 
scoreboard objectives add menu dummy menu
scoreboard objectives setdisplay belowname menu
scoreboard players add @p menu 1
execute @p [scores={menu=74}] ~~~ scoreboard players set @p menu 70 