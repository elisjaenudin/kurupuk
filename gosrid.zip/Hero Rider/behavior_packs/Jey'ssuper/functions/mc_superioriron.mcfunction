give @s mc:superioriron
