execute @p [scores={alien=1}] ~~~ replaceitem entity @p slot.armor.head 0 mc:cannonbolt 1 1 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
execute @p [scores={alien=2}] ~~~ replaceitem entity @p slot.armor.head 0 mc:xrl8 1 1 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
execute @p [scores={alien=3}] ~~~ replaceitem entity @p slot.armor.head 0 mc:diamondhead 1 1 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
execute @p [scores={alien=4}] ~~~ replaceitem entity @p slot.armor.head 0 mc:greymatter 1 1 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
execute @p [scores={alien=5}] ~~~ replaceitem entity @p slot.armor.head 0 mc:heatblast 1 1 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
execute @p [scores={alien=6}] ~~~ replaceitem entity @p slot.armor.head 0 mc:fourarms 1 1 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
execute @p [scores={alien=7}] ~~~ replaceitem entity @p slot.armor.head 0 mc:eyeguy 1 1 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
execute @p [scores={alien=8..100}] ~~~ replaceitem entity @p slot.armor.head 0 air
particle mc:omnip ~~~




camera @p clear







execute @p [scores={alien=1..10}] ~~~ scoreboard players set @p alien 0

