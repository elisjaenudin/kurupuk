replaceitem entity @p slot.armor.head 0 js:spoder
say Hello, i'm Spoder men