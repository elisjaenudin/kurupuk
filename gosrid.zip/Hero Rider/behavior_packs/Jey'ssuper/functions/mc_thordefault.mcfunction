give @s mc:thordefault
