summon mc:uu
camerashake add @a [r=10] 1 2