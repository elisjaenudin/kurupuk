replaceitem entity @p slot.hotbar 1 nk:heatvijn
replaceitem entity @p slot.hotbar 2 mc:unmask
