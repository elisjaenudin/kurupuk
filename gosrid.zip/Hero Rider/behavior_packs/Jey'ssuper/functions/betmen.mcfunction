execute @p [scores={menu=10}] ~~~ give @p js:batrang
execute @p [scores={menu=20}] ~~~ give @p js:batrangex

execute @p [scores={menu=30}] ~~~ give @p js:batice
execute @p [scores={menu=40}] ~~~ give @p js:batrangcryptonite
