replaceitem entity @p slot.hotbar 3 js:symbioteaxeven
replaceitem entity @p slot.hotbar 4 mc:symfang