replaceitem entity @p slot.hotbar 1 mc:sonicpunch
replaceitem entity @p slot.hotbar 3 mc:shmashes
replaceitem entity @p slot.hotbar 2 mc:thunderclap