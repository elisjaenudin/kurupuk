execute @p [scores={mask=0..100}] ~~~ scoreboard players set @p mask 0
scoreboard players add @p mask 300 
execute @e [scores={mask=600}] ~~~ scoreboard players set @p mask 0