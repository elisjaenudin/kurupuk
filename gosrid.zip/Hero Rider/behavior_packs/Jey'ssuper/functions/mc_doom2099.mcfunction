give @s mc:doom2099
