replaceitem entity @p slot.armor.head 0 js:antman 
tp @p [tag=ant] ~~-190~ 
kill @e [type=js:quantumania]