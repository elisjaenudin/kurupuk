particle niki:superblow ~~~ 
camerashake add @a 2 1