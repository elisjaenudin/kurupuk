scoreboard players add @p comb 1

execute @s [scores={comb=10}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=20}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=30}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=40}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=50}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=60}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=70}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=80}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=90}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~
execute @s [scores={comb=100}] ~~~ execute @e [r=5,type=!player] ~~~ summon mc:comb ~~~


execute @s [scores={comb=10}] ~~~ playanimation @p animation.ironman.combo
execute @s [scores={comb=20}] ~~~ playanimation @p animation.jeys.combo2
execute @s [scores={comb=30}] ~~~ playanimation @p animation.jeys.combo3
execute @s [scores={comb=40}] ~~~ playanimation @p animation.ironman.combo2
execute @s [scores={comb=50}] ~~~ playanimation @p animation.ironman.combo
execute @s [scores={comb=60}] ~~~ playanimation @p animation.jeys.combo5
execute @s [scores={comb=70}] ~~~ playanimation @p animation.ironman.combo3
execute @s [scores={comb=80}] ~~~ playanimation @p animation.jeys.combo6
execute @s [scores={comb=90}] ~~~ playanimation @p animation.ironman.combo2
execute @s [scores={comb=100}] ~~~ playanimation @p animation.ironman.combo4

execute @s [scores={comb=100}] ~~~ function tamom

execute @s [scores={comb=40}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=50}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=70}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=100}] ~~~ camerashake add @p 1 1