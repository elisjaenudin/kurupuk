replaceitem entity @p slot.hotbar 1 mc:mysteriomagic
