effect @p blindness 1 1 true

replaceitem entity @p slot.armor.head 0 js:antmanmini
tp @p ~~200~ 
summon js:quantumania 
ride @p start_riding @e [type=js:quantumania] teleport_rider if_group_fits