tag @p add shazam
replaceitem entity @p slot.armor.head 0 js:shazam


replaceitem entity @p slot.hotbar 1 nk:lightningk 1 0 {"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @p slot.hotbar 3 nk:lightningdual 1 0 {"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @p slot.hotbar 4 mc:thunderclap 1 0 {"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @p slot.hotbar 2 nk:lightningblast 1 0 {"item_lock":{"mode":"lock_in_slot"}}
replaceitem entity @p slot.hotbar 5 mc:shmashes
replaceitem entity @p slot.hotbar 6 mc:sheld 1 0
