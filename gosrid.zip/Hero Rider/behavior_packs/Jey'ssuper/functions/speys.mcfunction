tp @p @e [type=mc:gauntletspace,c=1]
particle jeys:spaceteleport ~~~




gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false




kill @e [type=mc:gauntletspace]