execute @p ~~~ summon mc:uchmoq 
ride @p start_riding @e [type=mc:uchmoq] teleport_rider if_group_fits
tag @e [type=mc:uchmoq] add grap 

execute @p [scores={mask=!7}] ~~~ scoreboard players add @p mask 1
execute @p [scores={mask=6}] ~~~ scoreboard players set @p mask 0
