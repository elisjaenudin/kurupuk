execute @p [tag=spider] ~~~ execute @e [tag=sling,r=1] ~~~ tag @e [r=1,tag=sling] remove sling 

execute @p ~~~ tp @e [tag=sling] ^^^0.7 facing @p  

scoreboard objectives add mask dummy mask 
scoreboard objectives setdisplay list mask
scoreboard players set @p [scores={comb=101..1000}] comb 0

execute @e [type=mc:trnsfrm] ~~~ particle mcjey:fleymsrov ~~~

gamerule sendcommandfeedback false

execute @p [scpres={gan=1..10}] ~~~ title @p title §e↓↓↓↓
execute @p [scores={gan=1}] ~~~ title @p actionbar §l§b{1/6}[SPACE STONE]
execute @p [scores={gan=2}] ~~~ title @p actionbar §l§e{2/6}[MIND STONE]
execute @p [scores={gan=3}] ~~~ title @p actionbar §l§6{3/6}[SOUL]
execute @p [scores={gan=4}] ~~~ title @p actionbar §l§c{4/6}[REALITY]
execute @p [scores={gan=5}] ~~~ title @p actionbar §l§d{5/6}[POWER STONE]
execute @p [scores={gan=6}] ~~~ title @p actionbar §l§2{6/6}[TIME STONE]


execute @p [scores={speed=1..50}] ~~~ effect @p speed 2 4 true
execute @p [scores={speed=51..120}] ~~~ effect @p speed 2 9 true
execute @p [scores={speed=121..200}] ~~~ effect @p speed 2 14 true
execute @p [scores={speed=201..300}] ~~~ effect @p speed 2 18 true
execute @p [scores={speed=301..500}] ~~~ effect @p speed 2 22 true
execute @p [scores={speed=501.50000}] ~~~ effect @p speed 2 26 true
execute @p [scores={speed=50001.500000}] ~~~ effect @p speed 2 40 true

execute @p [scores={speed=1..50}] ~~~ title @p actionbar §l§e{SPEED LEVEL:1}
execute @p [scores={speed=51..120}] ~~~ title @p actionbar §l§e{SPEED LEVEL:2}
execute @p [scores={speed=121..200}] ~~~ title @p actionbar §l§e{SPEED LEVEL:3}
execute @p [scores={speed=201..300}] ~~~ title @p actionbar §l§4{SPEED LEVEL:4}
execute @p [scores={speed=301..500}] ~~~ title @p actionbar §l§4{SPEED LEVEL:5}
execute @p [scores={speed=501.50000}] ~~~ title @p actionbar §l§e{SPEED LEVEL:6}
execute @p [scores={speed=50001.500000}] ~~~ title @p actionbar §l§5{SPEED LEVEL:∞}

execute @p [scores={speed=600=50000}] ~~~ set ~~-1~ fire 0


execute @p ~ ~ ~ execute @e [r=1,tag=throw,type=mc:mjolnir] ~ ~ ~ replaceitem entity @p slot.weapon.mainhand 0 mc:mjolnir 
execute @p ~ ~ ~ execute @e [r=1,tag=throw,type=js:stormbreaker] ~ ~ ~ replaceitem entity @p slot.weapon.mainhand 0 js:stormbreaker 
execute @p ~ ~ ~ execute @e [r=1,tag=throw,type=mc:capshield] ~ ~ ~ replaceitem entity @p slot.weapon.mainhand 0 mc:capshield 
execute @p ~ ~ ~ execute @e [r=1,tag=throw,type=mc:ironentity] ~ ~ ~ replaceitem entity @p slot.armor.head 0 mc:ironman2
execute @p ~ ~ ~ execute @e [tag=throw,r=1] ~~~ kill @e [tag=throw]
execute @e [type=mc:grapplinghook] ~ ~ ~ execute @e [tag=grap,r=1] ~~~ function end
execute @e [tag=throw]~~~ tp @e [type=js:stormbreaker,tag=throw] ^^^0.7 facing @p 
execute @e [tag=throw]~~~ tp @e [type=mc:capshield,tag=throw] ^^^0.6 facing @p 
execute @e [tag=throw]~~~ tp @e [type=mc:mjolnir,tag=throw] ^^^0.5 facing @p 
execute @p [rx=20] ~~~ execute @e [tag=grap] ~~~ tp @e [type=mc:uchmoq,tag=grap] ^^0.4^0.7 facing @e [type=mc:grapplinghook] 
execute @p [rxm=20] ~~~ execute @e [tag=grap] ~~~ tp @e [type=mc:uchmoq,tag=grap] ^^-0.2^0.7 facing @e [type=mc:grapplinghook]
execute @p [ry=20] ~~~ execute @e [tag=grap] ~~~ tp @e [type=mc:uchmoq,tag=grap] ^0.6^0.3^0.7 facing @e [type=mc:grapplinghook] 
execute @p [rym=20] ~~~ execute @e [tag=grap] ~~~ tp @e [type=mc:uchmoq,tag=grap] ^-0.6^-0.2^0.7 facing @e [type=mc:grapplinghook]
execute @e [tag=throw]~~~ tp @e [type=mc:ironentity,tag=throw] ^^^0.5 facing @p  
execute @e [type=item,name=mjolnir] ~~~ summon mc:mjolnir
execute @e [type=item,name=mjolnir] ~~~ kill @e [type=item] 

execute @e [type=mc:coldgun] ~~~ particle mcjey:icee ~~~

execute @p [tag=chaos] ~~~ time add 300


execute @p [tag=normal] ~~~ camera set @p clear

execute @e [type=mc:fireshoot] ~~~ particle jeys:scorpone ^^^


execute @p [scores={alien=1}] ~~~ title @p actionbar §l§a{1/8}[CANNONBALT]
execute @p [scores={alien=2}] ~~~ title @p actionbar §l§a{2/8}[XRL8]
execute @p [scores={alien=3}] ~~~ title @p actionbar §l§a{3/8}[DIAMONDHEAD]
execute @p [scores={alien=4}] ~~~ title @p actionbar §l§a{4/8}[GREYMATTER]
execute @p [scores={alien=5}] ~~~ title @p actionbar §l§a{5/8}[HEATBLAST]
execute @p [scores={alien=6}] ~~~ title @p actionbar §l§a{6/8}[FOURARMS]
execute @p [scores={alien=7}] ~~~ title @p actionbar §l§a{7/8}[EYEGUY]
execute @p [scores={alien=8}] ~~~ title @p actionbar §l§e{8/8}[NORMAL]

execute @e [type=mc:centralmode] ~~~ particle mcjey:fleymsrov ~~~

execute @p [tag=chaos] ~~~ particle jeys:strenjinnilik ^^0.1^
execute @p [scores={mk=51..1000}] ~~~ scoreboard players set @p mk 0

execute @p [tag=mark50] ~~~ execute @e [type=ety:mark50,r=1] ~~~ function ellik
execute @p [scores={taym=100..1000}] ~~~ tag @p remove chaos
execute @p [scores={taym=100..1000}] ~~~ scoreboard players set @p taym 0

scoreboard objectives add menu dummy menu
scoreboard objectives add mk dummy mk
scoreboard objectives setdisplay belowname menu
