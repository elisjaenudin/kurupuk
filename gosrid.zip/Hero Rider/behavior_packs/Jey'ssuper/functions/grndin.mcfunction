playanimation @s animation.jeys.grounding
summon mc:smashground ~~~
tag @p remove smeshin