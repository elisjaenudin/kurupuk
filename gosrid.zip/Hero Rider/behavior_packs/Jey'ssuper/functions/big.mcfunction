scoreboard players set @p menu 0 
replaceitem entity @p slot.armor.head 0 js:antmanbig
tag @p add big