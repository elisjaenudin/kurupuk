give @s mc:wolverine
