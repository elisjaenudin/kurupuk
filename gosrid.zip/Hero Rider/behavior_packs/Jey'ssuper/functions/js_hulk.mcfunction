replaceitem entity @p slot.hotbar 1 mc:thunderclap
replaceitem entity @p slot.hotbar 2 mc:sonicpunch
replaceitem entity @p slot.hotbar 3 mc:smashground
replaceitem entity @p slot.hotbar 4 mc:shmashes