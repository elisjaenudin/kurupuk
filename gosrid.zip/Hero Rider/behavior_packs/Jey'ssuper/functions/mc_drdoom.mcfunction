give @s mc:drdoom
