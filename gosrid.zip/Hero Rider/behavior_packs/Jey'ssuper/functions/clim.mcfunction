execute @p ~ ~ ~ detect ~1~~ snow 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ snow 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 snow 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 snow 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 cobblestone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ coal_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ coal_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 coal_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 coal_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ clay 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ clay 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 clay 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 clay 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stonebrick 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stonebrick 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stonebrick 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stonebrick 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stonebrick 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stonebrick 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stonebrick 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stonebrick 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stonebrick 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stonebrick 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stonebrick 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stonebrick 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stonebrick 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stonebrick 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stonebrick 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stonebrick 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ sandstone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ sandstone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 sandstone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 sandstone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ sandstone 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ sandstone 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 sandstone 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 sandstone 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ sandstone 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ sandstone 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 sandstone 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 sandstone 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ sandstone 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ sandstone 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 sandstone 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 sandstone 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ quartz_block 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ quartz_block 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 quartz_block 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 quartz_block 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ quartz_block 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ quartz_block 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 quartz_block 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 quartz_block 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ quartz_block 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ quartz_block 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 quartz_block 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 quartz_block 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ planks 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ planks 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 planks 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 planks 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ planks 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ planks 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 planks 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 planks 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ planks 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ planks 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 planks 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 planks 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ planks 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ planks 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 planks 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 planks 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ planks 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ planks 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 planks 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 planks 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ planks 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ planks 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 planks 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 planks 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ packed_ice 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ packed_ice 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 packed_ice 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 packed_ice 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ mossy_cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ mossy_cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 mossy_cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 mossy_cobblestone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ prismarine 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ prismarine 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 prismarine 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 prismarine 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ prismarine 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ prismarine 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 prismarine 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 prismarine 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ prismarine 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ prismarine 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 prismarine 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 prismarine 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ monster_egg 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ monster_egg 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 monster_egg 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 monster_egg 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ monster_egg 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ monster_egg 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 monster_egg 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 monster_egg 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ monster_egg 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ monster_egg 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 monster_egg 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 monster_egg 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ monster_egg 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ monster_egg 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 monster_egg 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 monster_egg 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ monster_egg 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ monster_egg 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 monster_egg 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 monster_egg 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ monster_egg 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ monster_egg 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 monster_egg 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 monster_egg 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ obisidian 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ obisidian 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 obisidian 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 obisidian 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ log 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ log 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 log 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 log 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ log 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ log 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 log 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 log 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ log 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ log 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 log 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 log 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ log 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ log 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 log 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 log 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ log2 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ log2 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 log2 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 log2 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ log2 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ log2 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 log2 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 log2 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ ice 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ ice 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 ice 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 ice 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ gravel 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ gravel 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 gravel 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 gravel 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glowstone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glowstone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glowstone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glowstone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ emerald_ore 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ emerald_ore 0 effect @s levitation 1 4 true





NtekGames
execute @p ~ ~ ~ detect ~~~1 emerald_ore 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 emerald_ore 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ golden_ore 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ golden_ore 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 golden_ore 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 golden_ore 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ emerald_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ emerald_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 emerald_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 emerald_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ brick_block 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ brick_block 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 brick_block 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 brick_block 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ diamond_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ diamond_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 diamond_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 diamond_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ end_stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ end_stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 end_stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 end_stone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ honeycomb 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ honeycomb 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 honeycomb 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 honeycomb 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ purpur_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ purpur_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 purpur_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 purpur_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ purpur_block 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ purpur_block 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 purpur_block 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 purpur_block 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ double_wooden_slab 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ double_wooden_slab 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 double_wooden_slab 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 double_wooden_slab 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ smooth_stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ smooth_stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 smooth_stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 smooth_stone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ mossy_cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ mossy_cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 mossy_cobblestone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 mossy_cobblestone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ end_bricks 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ end_bricks 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 end_bricks 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 end_bricks 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ gold_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ gold_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 gold_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 gold_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ nether_brick 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ nether_brick 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 nether_brick 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 nether_brick 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ emerald_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ emerald_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 emerald_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 emerald_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ bone_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ bone_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 bone_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 bone_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ lapis_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ lapis_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 lapis_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 lapis_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ iron_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ iron_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 iron_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 iron_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ nether_wart_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ nether_wart_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 nether_wart_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 nether_wart_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ netherrack 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ netherrack 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 netherrack 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 netherrack 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stone 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stone 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stone 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stone 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stone 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stone 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stone 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stone 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stone 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stone 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stone 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stone 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stone 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stone 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stone 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stone 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stone 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stone 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stone 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stone 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stone 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stone 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stone 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stone 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stone 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stone 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ quartz_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ quartz_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 quartz_block 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 quartz_block 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ concrete_powder 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ concrete_powder 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 concrete_powder 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 concrete_powder 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wool 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wool 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wool 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wool 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ glass_pane 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ glass_pane 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 glass_pane 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 glass_pane 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass_pane 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass_pane 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass_pane 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass_pane 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_glass 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_glass 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_glass 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_glass 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 13 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 14 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 14 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 15 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 15 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ stained_hardened_clay 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ stained_hardened_clay 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 stained_hardened_clay 16 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 stained_hardened_clay 16 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 0 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 0 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 1 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 1 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 2 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 2 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 3 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 3 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 4 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 4 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 5 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 5 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 6 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 6 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 7 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 7 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 8 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 8 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 9 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 9 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 10 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 10 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 11 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 11 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 12 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 12 effect @s levitation 1 4 true

execute @p ~ ~ ~ detect ~1~~ wood 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~-1~~ wood 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~1 wood 13 effect @s levitation 1 4 true
execute @p ~ ~ ~ detect ~~~-1 wood 13 effect @s levitation 1 4 true
