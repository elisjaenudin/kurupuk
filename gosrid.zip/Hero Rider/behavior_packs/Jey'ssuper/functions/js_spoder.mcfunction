give @s js:spoder
