replaceitem entity @p slot.hotbar 2 mc:trnsfrm
replaceitem entity @p slot.hotbar 3 mc:sonicpunch