give @p mc:bigsword
give @p mc:blades