execute @p [scores={hero=1}] ~~~ playanimation @p animation.orgimchak.yer
execute @p [scores={hero=2}] ~~~ playanimation @p animation.spider.landing
execute @p [scores={hero=3}] ~~~ playanimation @p animation.orgimchak.yer2
execute @p [scores={hero=4}] ~~~ playanimation @p animation.spider.landing
execute @p [scores={hero=5}] ~~~ playanimation @p animation.orgimchak.yer
execute @p [scores={hero=6}] ~~~ playanimation @p animation.spider.landing
execute @p [scores={hero=7}] ~~~ playanimation @p animation.orgimchak.yer2
execute @p [scores={hero=8}] ~~~ playanimation @p animation.spider.landing
execute @p [scores={hero=9}] ~~~ playanimation @p animation.orgimchak.yer
execute @p [scores={hero=10}] ~~~ playanimation @p animation.spider.landing
execute @p [scores={hero=11}] ~~~ playanimation @p animation.orgimchak.yer2
execute @p [scores={hero=12}] ~~~ playanimation @p animation.spider.landing
execute @p [scores={hero=13}] ~~~ playanimation @p animation.spider.landing
execute @p [scores={hero=14}] ~~~ playanimation @p animation.orgimchak.yer
execute @p [scores={hero=15}] ~~~ playanimation @p animation.orgimchak.yer2
title @p actionbar reset