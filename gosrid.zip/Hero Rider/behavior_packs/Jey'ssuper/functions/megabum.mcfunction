execute @e [type=!player,r=6] ~~~ summon lightning_bolt ~~~ 
execute @p [c=1] ~~~ particle jeys:megabum ~~~
camerashake add @p 1 1
