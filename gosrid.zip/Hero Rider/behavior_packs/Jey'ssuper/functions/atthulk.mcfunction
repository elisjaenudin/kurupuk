scoreboard players add @p comb 1

execute @s [scores={comb=10}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=20}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=30}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=40}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=50}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=60}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=70}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=80}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=90}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=100}] ~~~ summon mc:comb ~~~


execute @s [scores={comb=10}] ~~~ playanimation @p animation.hulk.combo2
execute @s [scores={comb=20}] ~~~ playanimation @p animation.jeys.combo2
execute @s [scores={comb=30}] ~~~ playanimation @p animation.hulk.combo3
execute @s [scores={comb=40}] ~~~ playanimation @p animation.hulk.combo2
execute @s [scores={comb=50}] ~~~ playanimation @p animation.hulk.combo
execute @s [scores={comb=60}] ~~~ playanimation @p animation.jeys.combo5
execute @s [scores={comb=70}] ~~~ playanimation @p animation.hulk.combo
execute @s [scores={comb=80}] ~~~ playanimation @p animation.hulk.combo3
execute @s [scores={comb=90}] ~~~ playanimation @p animation.hulk.combo
execute @s [scores={comb=100}] ~~~ playanimation @p animation.hulk.combo2

execute @s [scores={comb=20}] ~~~ execute @e [type=!player,r=4] ~~~ effect @e [type=!player,r=3] ~~~ levitation 1 9 true
execute @s [scores={comb=50}] ~~~ playanimation @e [r=4,type=!player] animation.opponent.qulash
execute @s [scores={comb=80}] ~~~ playanimation @e [r=4,type=!player] animation.opponent.qulash

execute @s [scores={comb=40}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=50}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=70}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=30}] ~~~ camerashake add @p 1 1