replaceitem entity @p slot.hotbar 1 mc:pistolgun

replaceitem entity @p slot.hotbar 3 mc:dpkatan

