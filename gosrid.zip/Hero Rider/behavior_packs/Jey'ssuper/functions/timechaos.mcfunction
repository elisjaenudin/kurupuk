tag @p add chaos
scoreboard objectives add taym dummy taym
scoreboard players add @p taym 50