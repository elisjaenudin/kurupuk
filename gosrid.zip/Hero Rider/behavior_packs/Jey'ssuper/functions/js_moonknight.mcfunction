playanimation @p animation.moonknight.transform
replaceitem entity @p slot.hotbar 1 mc:darts
replaceitem entity @p slot.hotbar 3 mc:unmask
replaceitem entity @p slot.armor.chest 0 elytra