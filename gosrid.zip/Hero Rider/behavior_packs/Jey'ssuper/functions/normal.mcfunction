replaceitem entity @p slot.armor.head 0 js:antman
scoreboard players set @p menu 0 
tag @p remove small
tag @p remove big
camera set @p clear