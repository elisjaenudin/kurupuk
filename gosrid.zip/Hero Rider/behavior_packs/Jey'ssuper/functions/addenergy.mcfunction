scoreboard objectives add energy dummy energy
execute @p [scores={energy=0..98},tag=sneaked] ~~~ scoreboard players add @p energy 2
execute @p [scores={energy=0..10},tag=sneaked] ~~~ title @p actionbar §l§b[]§f[][][][][][][][][]
execute @p [scores={energy=10..20},tag=sneaked] ~~~ title @p actionbar §l§b[][]§f[][][][][][][][]
execute @p [scores={energy=20..30},tag=sneaked] ~~~ title @p actionbar §l§b[][][]§f[][][][][][][]
execute @p [scores={energy=30..40},tag=sneaked] ~~~ title @p actionbar §l§b[][][][]§f[][][][][][]
execute @p [scores={energy=40..50},tag=sneaked] ~~~ title @p actionbar §l§b[][][][][]§f[][][][][]
execute @p [scores={energy=50..60},tag=sneaked] ~~~ title @p actionbar §l§b[][][][][][]§f[][][][]
execute @p [scores={energy=60..70},tag=sneaked] ~~~ title @p actionbar §l§b[][][][][][][]§f[][][]
execute @p [scores={energy=70..80},tag=sneaked] ~~~ title @p actionbar §l§b[][][][][][][][]§f[][]
execute @p [scores={energy=80..90},tag=sneaked] ~~~ title @p actionbar §l§b[][][][][][][][][]§f[]
execute @p [scores={energy=90..100},tag=sneaked] ~~~ title @p actionbar §l§b[][][][][][][][][][]
effect @p slowness 1 2 true