effect @e [r=3,c=3,type=!player] ~~~ invisiblity 9 5 true
execute @e [type=!player,r=3,c=3] ~~~ particle jeys:dusting ~~~



gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false
gamerule sendcommandfeedback false


kill @e [type=!player,r=3,c=3]
