scoreboard objectives add gan dummy gan
scoreboard players add @p gan 1
execute @p [scores={gan=7..100}] ~~~ scoreboard players set @p gan 0
playanimation @p animation.omnitriks.use
execute as @p anchored eyes at @p run camera @p set minecraft:free ease 0.8 out_cubic pos ~-1 ~1 ~-2 facing @p