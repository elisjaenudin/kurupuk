kill @e [type=z:menu]
summon z:menu ~~~ selectgadget
event entity @e openg 
scoreboard objectives add menu dummy menu
scoreboard objectives setdisplay belowname menu
scoreboard players add @p menu 10
execute @p [scores={menu=50}] ~~~ scoreboard players set @p menu 10 