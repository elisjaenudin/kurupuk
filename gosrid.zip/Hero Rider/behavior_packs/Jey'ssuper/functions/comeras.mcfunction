execute as @p [tag=small] anchored eyes at @p run camera @p [tag=small] set minecraft:free ease 0.3 out_cubic pos ^^0.4^-0.5 facing @p
