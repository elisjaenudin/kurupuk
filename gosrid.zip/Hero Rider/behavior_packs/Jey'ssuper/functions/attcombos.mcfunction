scoreboard players add @p comb 1

execute @s [scores={comb=10}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=20}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=30}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=40}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=50}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=60}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=70}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=80}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=90}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=100}] ~~~ summon mc:comb ~~~


execute @s [scores={comb=10}] ~~~ playanimation @p animation.symbiote.combo
execute @s [scores={comb=20}] ~~~ playanimation @p animation.jeys.combo2
execute @s [scores={comb=30}] ~~~ playanimation @p animation.jeys.combo3
execute @s [scores={comb=40}] ~~~ playanimation @p animation.jeys.combo4
execute @s [scores={comb=50}] ~~~ playanimation @p animation.symbiote.combo2
execute @s [scores={comb=60}] ~~~ playanimation @p animation.jeys.combo5
execute @s [scores={comb=70}] ~~~ playanimation @p animation.symbiote.combo3
execute @s [scores={comb=80}] ~~~ playanimation @p animation.jeys.combo6
execute @s [scores={comb=90}] ~~~ playanimation @p animation.jeys.comb7
execute @s [scores={comb=100}] ~~~ playanimation @p animation.symbiote.combo3

execute @s [scores={comb=20}] ~~~ execute @e [type=!player,r=4] ~~~ summon mc:symfang ~~~
execute @s [scores={comb=50}] ~~~ function symfan
execute @s [scores={comb=80}] ~~~ function symfan

execute @s [scores={comb=40}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=50}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=70}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=30}] ~~~ camerashake add @p 1 1