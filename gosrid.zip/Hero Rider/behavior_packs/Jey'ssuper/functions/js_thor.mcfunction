replaceitem entity @p slot.hotbar 1 mc:mjolnir
replaceitem entity @p slot.hotbar 2 js:stormbreaker
replaceitem entity @p slot.hotbar 3 nk:lightningblue
replaceitem entity @p slot.hotbar 4 mc:thunderclap