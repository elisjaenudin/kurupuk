tag @p add chaos
scoreboard players set @p menu 60