ride @p start_riding @e [type=isla:hook_intermediate] teleport_rider if_group_fits
ride @p start_riding @e [type=isla:hook_intermediate] teleport_rider if_group_fits