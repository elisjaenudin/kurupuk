give @s mc:greengoblinjr
