give @s mc:daredevil
