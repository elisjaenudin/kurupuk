summon lightning_bolt
summon lightning_bolt
summon lightning_bolt
summon lightning_bolt

tag @e [type=mc:mjolnir] add throw