replaceitem entity @p slot.hotbar 1 mc:blastyf
replaceitem entity @p slot.hotbar 2 mc:icebreath
replaceitem entity @p slot.hotbar 3 nk:heatvijn
replaceitem entity @p slot.hotbar 4 mc:shmashes