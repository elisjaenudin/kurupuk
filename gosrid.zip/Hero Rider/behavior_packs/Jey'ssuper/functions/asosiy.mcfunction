kill @e [type=z:menu]
summon z:menu ~~~ opes
event entity @e opes 
scoreboard objectives add menu dummy menu
scoreboard objectives setdisplay belowname menu
scoreboard players set @p menu 10