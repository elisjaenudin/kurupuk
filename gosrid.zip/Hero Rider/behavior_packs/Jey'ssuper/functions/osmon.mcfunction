scoreboard objectives add hero dummy hero
scoreboard players add @p hero 1 
execute @p [scores={hero=1}] ~~~ playanimation @p animation.spiderman.salto
execute @p [scores={hero=2}] ~~~ playanimation @p animation.spiderman.salto2
execute @p [scores={hero=3}] ~~~ playanimation @p animation.spiderman.salto3
execute @p [scores={hero=4}] ~~~ playanimation @p animation.spiderman.salto4
execute @p [scores={hero=5}] ~~~ playanimation @p animation.spiderman.salto5
execute @p [scores={hero=6}] ~~~ playanimation @p animation.spider.osmon6
execute @p [scores={hero=7}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon7
execute @p [scores={hero=8}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon8
execute @p [scores={hero=9}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon 
execute @p [scores={hero=10}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon1
execute @p [scores={hero=11}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon2
execute @p [scores={hero=12}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon3
execute @p [scores={hero=13}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon4
execute @p [scores={hero=14}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon5
execute @p [scores={hero=15}] ~~~ detect ~~~ air 0 playanimation @p animation.spider.osmon6
execute @p [scores={hero=16}] ~~~ scoreboard players set @p hero 0
