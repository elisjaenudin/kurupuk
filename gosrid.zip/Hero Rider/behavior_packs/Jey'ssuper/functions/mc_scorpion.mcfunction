replaceitem entity @p slot.hotbar 1 mc:fireshoot
replaceitem entity @p slot.hotbar 2 mc:thunderclap
replaceitem entity @p slot.hotbar 3 mc:settinmenu
