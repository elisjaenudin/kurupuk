effect @p levitation 2 3 true
execute @p [scores={hero=1}] ~~~ playanimation @p animation.spidermen.webzip
execute @p [scores={hero=2}] ~~~ playanimation @p animation.orgimchak.zip4
execute @p [scores={hero=3}] ~~~ playanimation @p animation.orgimchak.zip3
execute @p [scores={hero=4}] ~~~ playanimation @p animation.orgimchak.zip2
execute @p [scores={hero=5}] ~~~ playanimation @p animation.spidermen.webzip
execute @p [scores={hero=6}] ~~~ playanimation @p animation.orgimchak.zip4
execute @p [scores={hero=7}] ~~~ playanimation @p animation.orgimchak.zip3
execute @p [scores={hero=8}] ~~~ playanimation @p animation.orgimchak.zip2
execute @p [scores={hero=9}] ~~~ playanimation @p animation.spidermen.webzip
execute @p [scores={hero=10}] ~~~ playanimation @p animation.orgimchak.zip4
execute @p [scores={hero=11}] ~~~ playanimation @p animation.orgimchak.zip3
execute @p [scores={hero=12}] ~~~ playanimation @p animation.orgimchak.zip2
execute @p [scores={hero=13}] ~~~ playanimation @p animation.spidermen.webzip
execute @p [scores={hero=14}] ~~~ playanimation @p animation.orgimchak.zip4
execute @p [scores={hero=15}] ~~~ playanimation @p animation.orgimchak.zip3
execute @p [scores={hero=16}] ~~~ playanimation @p animation.orgimchak.zip2