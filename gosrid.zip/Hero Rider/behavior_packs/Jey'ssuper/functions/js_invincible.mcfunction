replaceitem entity @p slot.hotbar 1 mc:thunderclap
replaceitem entity @p slot.hotbar 2 nk:lightningblue