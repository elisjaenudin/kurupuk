replaceitem entity @p slot.hotbar 2 mc:capshield
replaceitem entity @p slot.hotbar 3 mc:pistolgun
