playanimation @p animation.antman.toansform
replaceitem entity @p slot.hotbar 1 js:quantutl
replaceitem entity @p slot.hotbar 2 js:shrink
replaceitem entity @p slot.hotbar 3 mc:unmask
