replaceitem entity @p slot.hotbar 1 js:jarvis
tag @p add ironman