particle mc:smoq 
effect @p [r=2] invisibility 3 1 true