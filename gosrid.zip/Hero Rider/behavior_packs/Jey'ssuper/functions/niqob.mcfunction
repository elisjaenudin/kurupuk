scoreboard objectives add mask dummy mask 
scoreboard objectives setdisplay list mask 
scoreboard players add @p mask 10 
execute @e [scores={mask=20}] ~~~ scoreboard players set @p mask 0 