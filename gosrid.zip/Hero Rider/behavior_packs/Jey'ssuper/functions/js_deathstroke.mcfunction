
replaceitem entity @p slot.hotbar 2 mc:dpkatan
replaceitem entity @p slot.hotbar 3 mc:unmask
