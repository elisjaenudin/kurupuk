tag @p remove chaos
scoreboard players set @p menu 0