execute @e [family=monster,type=arrow,r=2] ~~~ function sense
execute @e [family=monster,type=trident,r=2] ~~~ function sense
execute @e [family=monster,type=tnt,r=2] ~~~ function sense
execute @e [type=arrow,r=2] ~~~ function sense
