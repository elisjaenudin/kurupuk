kill @e [type=z:menu]
summon z:menu ~~~ selectmorph
event entity @e colors
scoreboard objectives add menu dummy menu
scoreboard objectives setdisplay belowname menu
scoreboard players set @p menu 70