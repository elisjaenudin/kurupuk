replaceitem entity @p slot.hotbar 1 nk:lightningblast
replaceitem entity @p slot.hotbar 2 mc:unmask
