give @s mc:warmachine
