give @s mc:octopusps4
