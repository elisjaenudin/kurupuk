scoreboard players add @p comb 1

execute @s [scores={comb=10}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=20}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=30}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=40}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=50}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=60}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=70}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=80}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=90}] ~~~ summon mc:comb ~~~
execute @s [scores={comb=100}] ~~~ summon mc:comb ~~~


execute @s [scores={comb=10}] ~~~ playanimation @p animation.spidey.combo
execute @s [scores={comb=20}] ~~~ playanimation @p animation.spidey.combo2
execute @s [scores={comb=30}] ~~~ playanimation @p animation.spidey.combo3
execute @s [scores={comb=40}] ~~~ playanimation @p animation.spidey.combo4
execute @s [scores={comb=50}] ~~~ playanimation @p animation.spidey.combo5
execute @s [scores={comb=60}] ~~~ playanimation @p animation.spidey.combo6
execute @s [scores={comb=70}] ~~~ playanimation @p animation.spidey.combo7
execute @s [scores={comb=80}] ~~~ playanimation @p animation.spidey.combo8
execute @s [scores={comb=90}] ~~~ playanimation @p animation.spidey.combo9
execute @s [scores={comb=100}] ~~~ playanimation @p animation.spidey.combo10


execute @s [scores={comb=40}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=50}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=70}] ~~~ camerashake add @p 1 1
execute @s [scores={comb=30}] ~~~ camerashake add @p 1 1