give @s js:spidermanps4
