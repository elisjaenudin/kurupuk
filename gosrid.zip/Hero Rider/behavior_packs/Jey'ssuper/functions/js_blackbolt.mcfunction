replaceitem entity @p slot.hotbar 1 nk:lightningblue
replaceitem entity @p slot.hotbar 2 mc:unmask
replaceitem entity @p slot.armor.chest 0 elytra