scoreboard objectives add hero dummy hero
scoreboard players add @p hero 1 
execute @p [scores={hero=1}] ~~~ playanimation @p animation.falcon.trick
execute @p [scores={hero=2}] ~~~ playanimation @p animation.falcon.trick2
execute @p [scores={hero=3}] ~~~ playanimation @p animation.falcon.trick3
execute @p [scores={hero=4}] ~~~ playanimation @p animation.falcon.trick4
execute @p [scores={hero=5}] ~~~ playanimation @p animation.falcon.trick
execute @p [scores={hero=6}] ~~~ scoreboard players set @p hero 0
