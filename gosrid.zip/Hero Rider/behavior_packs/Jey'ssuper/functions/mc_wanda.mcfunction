replaceitem entity @p slot.hotbar 1 js:entitycatch
particle jeys:wandaground ~~~
