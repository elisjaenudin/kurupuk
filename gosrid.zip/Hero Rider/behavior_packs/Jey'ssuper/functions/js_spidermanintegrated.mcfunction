give @s js:spidermanintegrated
