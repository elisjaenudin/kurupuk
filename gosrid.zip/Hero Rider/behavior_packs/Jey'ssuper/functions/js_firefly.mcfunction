replaceitem entity @p slot.hotbar 1 mc:blastyf
replaceitem entity @p slot.hotbar 2 nk:lightningblast