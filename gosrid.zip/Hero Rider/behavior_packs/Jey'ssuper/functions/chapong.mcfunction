execute @p [scores={hero=1}] ~~~ playanimation @p animation.falcon.ong
execute @p [scores={hero=2}] ~~~ playanimation @p animation.falcon.chap
execute @p [scores={hero=3}] ~~~ playanimation @p animation.falcon.ong
execute @p [scores={hero=4}] ~~~ playanimation @p animation.falcon.chap
execute @p [scores={hero=5}] ~~~ playanimation @p animation.falcon.ong