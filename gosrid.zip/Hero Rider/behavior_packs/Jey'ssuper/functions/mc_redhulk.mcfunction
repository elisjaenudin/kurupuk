give @s mc:redhulk
