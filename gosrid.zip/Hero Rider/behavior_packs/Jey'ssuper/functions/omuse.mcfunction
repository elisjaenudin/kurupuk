scoreboard objectives add alien dummy alien
scoreboard players add @p alien 1
execute @p [scores={alien=9..100}] ~~~ scoreboard players set @p alien 0
playanimation @p animation.omnitriks.use
