summon mc:jumpiz ^^^-0.1
playanimation @p animation.light.fly
effect @p levitation 2 4 true