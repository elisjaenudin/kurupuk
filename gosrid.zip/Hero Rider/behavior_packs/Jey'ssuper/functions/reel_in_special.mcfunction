execute @e[type=isla:hook_intermediate] ~ ~ ~ scoreboard players set @s hook_id_check 0
execute @e[type=isla:hook_intermediate] ~ ~ ~ scoreboard players operation @s hook_id_check = @s hook_id
scoreboard players operation @e[type=isla:hook_intermediate] hook_id_check -= @s hook_id
event entity @e[scores={hook_id_check=0}] isla:landed