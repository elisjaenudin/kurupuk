kill @e [type=mc:grapplinghook]
tag @e remove grap
kill @e [type=mc:uchmoq]