replaceitem entity @p slot.hotbar 1 mc:heatvisionsiklop
replaceitem entity @p slot.hotbar 2 mc:trnsfrm