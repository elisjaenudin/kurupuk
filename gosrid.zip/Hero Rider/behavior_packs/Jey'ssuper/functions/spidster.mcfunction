scoreboard objectives add speed dummy speed
scoreboard players add @p speed 1