give @s mc:thanossuit
