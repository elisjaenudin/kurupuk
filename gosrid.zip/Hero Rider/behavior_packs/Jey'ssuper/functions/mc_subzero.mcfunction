replaceitem entity @p slot.hotbar 1 mc:icepower
replaceitem entity @p slot.hotbar 2 mc:sonicpunch