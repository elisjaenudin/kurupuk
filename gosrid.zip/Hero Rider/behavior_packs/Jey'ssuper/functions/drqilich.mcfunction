give @p mc:drqilich 
scoreboard players set @p menu 0