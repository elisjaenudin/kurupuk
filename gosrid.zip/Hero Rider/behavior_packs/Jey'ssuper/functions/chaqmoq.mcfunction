execute @e [r=3] ~~~ summon lightning_bolt 

tag @e [type=js:stormbreaker] add throw