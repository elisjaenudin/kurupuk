replaceitem entity @p slot.hotbar 1 mc:coldgun
replaceitem entity @p slot.hotbar 2 mc:unmask
