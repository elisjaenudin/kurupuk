execute @a ~ ~ ~ scoreboard players operation @s hook_id_check = @s hook_id
scoreboard players operation @s hook_id_check = @s hook_id
scoreboard players operation @a hook_id_check -= @s hook_id
scoreboard players operation @s hook_id_check -= @p[scores={hook_id_check=0}] hook_id
execute @s[scores={hook_id_check=!0}] ~ ~ ~ event entity @s isla:hook_timeout