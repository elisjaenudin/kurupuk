execute @a[r=2] ~~~ effect @e [type=vl:coin,r=2] invisibility 1 255 true
execute @a[r=2] ~~~ kill @e [type=vl:coin,r=2]
title @a[r=2] actionbar 1
